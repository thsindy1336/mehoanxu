export type UserRole = 'admin' | 'user';

export interface User {
  username: string;
  role: UserRole;
  availableBalance: number; // Số dư khả dụng (tiền có thể rút)
  pendingBalance: number;   // Tiền đang chờ duyệt
  totalCashback: number;    // Tổng tiền hoàn đã nhận
  referralCode: string;     // Mã giới thiệu
  referredBy?: string;      // Được giới thiệu bởi ai
  registeredAt: string;     // Ngày tham gia
}

export interface ShortLink {
  code: string;             // Ví dụ: aB2
  originalLink: string;     // Link Shopee gốc
  affiliateLink: string;    // Link affiliate đã sinh
  createdBy: string;        // Tên đăng nhập
  createdAt: string;
  clicks: number;           // Lượt click
  shopId?: string;
  itemId?: string;
}

export type OrderStatus = 'pending_record' | 'pending_approve' | 'approved' | 'cancelled';

export interface Order {
  orderId: string;          // Mã đơn hàng
  username: string;         // Người sở hữu đơn hàng (đã khai báo hoặc map lúc import)
  time: string;             // Thời gian đặt hàng
  rebateAmount: number;     // Số tiền hoàn người dùng nhận (Ví dụ: Hoa hồng Shopee * rebatePercent)
  rawCommission: number;    // Hoa hồng gốc Shopee trả
  status: OrderStatus;
  productName?: string;     // Tên sản phẩm (nếu có)
  imageUrl?: string;        // Ảnh sản phẩm (nếu có)
  syncedAt?: string;        // Thời gian đồng bộ từ file Excel
  isLostClaim?: boolean;    // Đánh dấu là đơn tìm thất lạc
  lostClaimNote?: string;   // Ghi chú tra soát thất lạc
  internalNote?: string;    // Ghi chú nội bộ cho quản trị viên
  platform?: string;        // Nền tảng (Shopee/TikTok Shop)
  appliedRate?: number;     // Tỷ lệ áp dụng (%)
  systemKeepAmount?: number; // Tiền hệ thống giữ lại
}

export interface WithdrawRequest {
  id: string;
  username: string;
  amount: number;
  bankName: string;
  accountHolder: string;
  accountNumber: string;
  status: 'pending' | 'completed' | 'rejected';
  createdAt: string;
  processedAt?: string;
}

export interface Voucher {
  id: string;
  title: string;            // Ví dụ: Voucher Shopee 20K/0Đ
  discountValue: number;    // Giá trị voucher (e.g. 20000)
  costPoints: number;       // Số điểm/tiền đổi (e.g. 20000)
  expiryDate: string;       // Hạn sử dụng: 01/10/2026
  code: string;             // Mã voucher (e.g. MHS20KXXXXX)
  redeemedBy?: string;      // Đã đổi bởi ai
  redeemedAt?: string;      // Ngày đổi
}

export interface Comment {
  id: string;
  username: string;
  content: string;
  rating: number;           // 1 -> 5 sao
  createdAt: string;
}

export interface AffiliateConfig {
  affiliateId: string;      // e.g. 17903619320
  subId: string;            // e.g. shpee_tthuy3326
  rebatePercent: number;    // e.g. 50 (cho tỷ lệ 50%)
  tiktokCommissionRate?: number; // Tỷ lệ chia hoa hồng TikTok Shop (%)
}

// Báo cáo thống kê
export interface DashboardStats {
  totalLinksCreated: number;
  totalClicks: number;
  totalOrders: number;
  totalSyncedRevenue: number; // Tổng hoa hồng Shopee trả
  totalCashbackPaid: number;  // Tổng tiền cashback hệ thống trả khách
}

export interface WalletTransaction {
  id: string;
  username: string;
  amount: number;             // Ví dụ: +5000, -15000
  type: 'cashback' | 'referral' | 'withdraw' | 'voucher';
  description: string;        // Ví dụ: "+5.000đ Cashback đơn SPX"
  createdAt: string;
}

export interface InternalNotification {
  id: string;
  username: string;
  title: string;
  content: string;
  isRead: boolean;
  createdAt: string;
}

export interface SupportTicket {
  id: string;
  username: string;
  title: string;
  content: string;
  category: 'lost_order' | 'withdraw' | 'other';
  status: 'pending' | 'replied' | 'closed';
  adminReply?: string;
  processedAt?: string;
  createdAt: string;
  platform?: 'shopee' | 'tiktok';
}

export interface ExcelUploadLog {
  id: string;
  filename: string;
  operator: string;
  matchedOrders: number;
  newOrders: number;
  createdAt: string;
}

export interface WebContent {
  bannerTitle: string;
  bannerDesc: string;
  bannerSub: string;
  showPopup: boolean;
  popupContent: string;
  step1_title: string;
  step1_desc: string;
  step2_title: string;
  step2_desc: string;
  step3_title: string;
  step3_desc: string;
  step4_title: string;
  step4_desc: string;
  tabCorrectTitle: string;
  tabCorrectContent: string;
  tabPolicyTitle: string;
  tabPolicyContent: string;
  tabTipsTitle: string;
  tabTipsContent: string;
  footerName: string;
  footerDesc: string;
  footerContact: string;
  footerCopyright: string;
  footerSocialLink: string;
  showHelp: boolean;
  showPrivacy: boolean;
  showTerms: boolean;
  helpContent: string;
  privacyContent: string;
  termsContent: string;
}

export interface AdminPasswordLog {
  id: string;
  adminUsername: string;
  targetUsername: string;
  changedAt: string;
}

export interface TikTokConfig {
  creator_username: string;
  has_key: boolean;
  masked_key: string;
}

export interface TikTokLink {
  original_link: string;
  affiliate_link: string;
  product_id: string;
  sub_id: string;
  created_at: string;
  orders_count: number;
  estimated_commission: number;
  approved_commission: number;
}

export interface TikTokOrder {
  order_id: string;
  product_name: string;
  sub_id: string;
  commission: number;
  status: string;
  time: string;
}

export interface TikTokSyncLog {
  id: string;
  syncedAt: string;
  newOrdersCount: number;
  updatedOrdersCount: number;
  error?: string;
}



