import React, { useState, useRef } from 'react';
import { Upload, FileDown, CheckCircle2, XCircle, AlertTriangle, Settings, RefreshCw, BarChart3, Database, MessageSquare, Tag, Users, ShieldAlert, Link as LinkIcon, Edit3, Key, Lock } from 'lucide-react';
import * as XLSX from 'xlsx';
import { User, ShortLink, Order, WithdrawRequest, Voucher, Comment, AffiliateConfig, OrderStatus, WalletTransaction, InternalNotification, ExcelUploadLog, SupportTicket, WebContent, AdminPasswordLog, TikTokSyncLog } from '../types';
import { 
  getDashboardStats, getConfig, saveConfig, getOrders, saveOrders, 
  getUsers, saveUsers, getWithdrawRequests, saveWithdrawRequests, 
  getShortLinks, saveShortLinks, getComments, saveComments, getVouchers, saveVouchers,
  getWalletTransactions, saveWalletTransactions, getInternalNotifications, saveInternalNotifications,
  getExcelUploadLogs, saveExcelUploadLogs, getSupportTickets, saveSupportTickets,
  getWebContent, saveWebContent, getPasswords, savePasswords, hashPassword, getAdminPasswordLogs, saveAdminPasswordLogs,
  getTikTokSyncLogs, syncTikTokOrders
} from '../data';
import TikTokView from './TikTokView';

interface AdminViewProps {
  onRefreshData: () => void;
  currentUser: User | null;
  initialSubTab?: 'stats' | 'excel' | 'withdrawals' | 'config' | 'items' | 'tickets' | 'content' | 'tiktok_shop' | 'declarations';
}

export default function AdminView({ onRefreshData, currentUser, initialSubTab }: AdminViewProps) {
  const [subTab, setSubTab] = useState<'stats' | 'excel' | 'withdrawals' | 'config' | 'items' | 'tickets' | 'content' | 'tiktok_shop' | 'declarations'>(initialSubTab || 'stats');

  React.useEffect(() => {
    if (initialSubTab) {
      setSubTab(initialSubTab);
    }
  }, [initialSubTab]);

  const [config, setConfig] = useState<AffiliateConfig>(getConfig());
  const [stats, setStats] = useState(getDashboardStats());
  const [orders, setOrders] = useState<Order[]>(getOrders());
  const [users, setUsers] = useState<User[]>(getUsers());
  const [withdraws, setWithdraws] = useState<WithdrawRequest[]>(getWithdrawRequests());
  const [links, setLinks] = useState<ShortLink[]>(getShortLinks());
  const [comments, setComments] = useState<Comment[]>(getComments());
  const [vouchers, setVouchers] = useState<Voucher[]>(getVouchers());
  const [webContent, setWebContentLocal] = useState<WebContent>(() => getWebContent());

  // Support Tickets & Excel upload log states
  const [allTickets, setAllTickets] = useState<SupportTicket[]>(getSupportTickets());
  const [excelLogs, setExcelLogs] = useState<ExcelUploadLog[]>(getExcelUploadLogs());
  const [ticketReplyText, setTicketReplyText] = useState<{ [id: string]: string }>({});
  const [ticketFilterCategory, setTicketFilterCategory] = useState<string>('all');
  const [ticketFilterStatus, setTicketFilterStatus] = useState<string>('all');
  const [ticketFilterPlatform, setTicketFilterPlatform] = useState<string>('all');

  // Excel upload feedback state
  const [excelSuccessMsg, setExcelSuccessMsg] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // States: tạo Voucher mới
  const [vouchTitle, setVouchTitle] = useState('');
  const [vouchValue, setVouchValue] = useState('');
  const [vouchCost, setVouchCost] = useState('');
  const [vouchExpiry, setVouchExpiry] = useState('2026-10-01');

  // States: Đổi mật khẩu thành viên
  const [targetUserForPasswordChange, setTargetUserForPasswordChange] = useState<string | null>(null);
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [passwordChangeLogs, setPasswordChangeLogs] = useState<AdminPasswordLog[]>(() => getAdminPasswordLogs());

  // TikTok Shop reconciliation states
  const [reconcileChannel, setReconcileChannel] = useState<'shopee' | 'tiktok'>('shopee');
  const [tiktokSyncLogs, setTiktokSyncLogs] = useState<TikTokSyncLog[]>(() => getTikTokSyncLogs());
  const [tiktokSyncing, setTiktokSyncing] = useState(false);
  const [tiktokSyncResult, setTiktokSyncResult] = useState<{ 
    success: boolean; 
    newOrders: number; 
    updatedOrders: number; 
    error?: string;
    status?: number;
    body?: string;
  } | null>(null);

  // States cho quản lý đơn hàng khai báo của Admin
  const [declSearchCode, setDeclSearchCode] = useState('');
  const [declFilterUser, setDeclFilterUser] = useState('all');
  const [declFilterStatus, setDeclFilterStatus] = useState<string>('all');
  const [declFilterPlatform, setDeclFilterPlatform] = useState<string>('all');
  const [declCommissionInputs, setDeclCommissionInputs] = useState<{ [orderId: string]: string }>({});
  const [declNoteInputs, setDeclNoteInputs] = useState<{ [orderId: string]: string }>({});

  const handleTikTokSync = async () => {
    setTiktokSyncing(true);
    setTiktokSyncResult(null);
    try {
      const res = await syncTikTokOrders();
      setTiktokSyncResult(res);
      const updatedLogs = getTikTokSyncLogs();
      setTiktokSyncLogs(updatedLogs);
      setOrders(getOrders());
      setStats(getDashboardStats());
      onRefreshData();
    } catch (e: any) {
      setTiktokSyncResult({ 
        success: false, 
        newOrders: 0, 
        updatedOrders: 0, 
        error: e.message || 'Lỗi bất ngờ khi gọi API.',
        status: e.status || 500,
        body: e.body || ''
      });
    } finally {
      setTiktokSyncing(false);
    }
  };

  // Sinh mật khẩu ngẫu nhiên an toàn cho thành viên
  const handleGenerateRandomPassword = () => {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#';
    let randPass = '';
    for (let i = 0; i < 10; i++) {
      randPass += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setNewPasswordInput(randPass);
  };

  // Tiến hành đổi mật khẩu cho tài khoản, bao gồm cả admin khác
  const handleConfirmPasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetUserForPasswordChange || !newPasswordInput.trim()) return;

    // 1. Kiểm tra bảo mật: xem người đang thực hiện thay đổi có phải Admin hay không
    const operatorUsername = localStorage.getItem('mhx_session_user') || 'admin';
    const allUsers = getUsers();
    const operatorUser = allUsers.find(u => u.username === operatorUsername);
    if (!operatorUser || operatorUser.role !== 'admin') {
      alert('⚠️ Bạn không có quyền Admin thực hiện thao tác đổi mật khẩu này!');
      return;
    }

    // 2. Cập nhật mật khẩu băm mới
    const dbPasswords = getPasswords();
    const isTargetExists = allUsers.some(u => u.username === targetUserForPasswordChange);
    if (!isTargetExists && targetUserForPasswordChange !== 'admin') {
      alert('⚠️ Tài khoản này không tồn tại trong hệ thống!');
      return;
    }

    dbPasswords[targetUserForPasswordChange] = hashPassword(newPasswordInput.trim());
    savePasswords(dbPasswords);

    // 3. Ghi nhật ký lịch sử đổi mật khẩu
    const dbPasswordLogs = getAdminPasswordLogs();
    const newLog: AdminPasswordLog = {
      id: 'pw_change_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
      adminUsername: operatorUsername,
      targetUsername: targetUserForPasswordChange,
      changedAt: new Date().toISOString()
    };

    dbPasswordLogs.unshift(newLog);
    saveAdminPasswordLogs(dbPasswordLogs);
    setPasswordChangeLogs(dbPasswordLogs);

    // 4. Tạo thông báo nội bộ cho tài khoản bị đổi mật khẩu để tăng tính minh bạch
    const dbNotifications = getInternalNotifications();
    dbNotifications.unshift({
      id: 'nt_pw_' + Date.now(),
      username: targetUserForPasswordChange,
      title: 'Mật khẩu đã được cập nhật khẩn cấp 🔐',
      content: `Mật khẩu đăng nhập của bạn vừa được Admin hệ thống cập nhật thay đổi thành công.`,
      isRead: false,
      createdAt: new Date().toISOString()
    });
    saveInternalNotifications(dbNotifications);

    alert(`🎉 Thành công! Đã thay đổi mật khẩu cho tài khoản @${targetUserForPasswordChange} thành "${newPasswordInput.trim()}" và ghi log hệ thống.`);
    setTargetUserForPasswordChange(null);
    setNewPasswordInput('');
    onRefreshData();
  };

  // Quản lý trạng thái, xóa đơn, điền ghi chú của đơn hàng tự khai báo:
  const handleUpdateDeclStatus = (orderId: string, newStatus: OrderStatus) => {
    const dbOrders = getOrders();
    const dbUsers = getUsers();
    const dbTransactions = getWalletTransactions();
    const dbNotifications = getInternalNotifications();

    const orderIdx = dbOrders.findIndex(o => o.orderId === orderId);
    if (orderIdx < 0) return;

    const order = dbOrders[orderIdx];
    const oldStatus = order.status;
    if (oldStatus === newStatus) return;

    // Lấy doanh thu/hoa hồng gán vào hoặc lấy từ thẻ input nếu admin điền nháp
    const rawCommStr = declCommissionInputs[orderId] || String(order.rawCommission || '0');
    const rawComm = parseFloat(rawCommStr) || 0;
    const systemRebatePercent = config.rebatePercent / 100;
    const rebateAmount = Math.round(rawComm * systemRebatePercent);

    // Lưu trạng thái & tính toán rebate
    order.status = newStatus;
    order.rawCommission = rawComm;
    order.rebateAmount = rebateAmount;
    order.time = order.time || new Date().toISOString(); // Đảm bảo luôn có timeline

    const userIdx = dbUsers.findIndex(u => u.username === order.username);

    if (userIdx >= 0) {
      const targetUser = dbUsers[userIdx];
      const isTikTok = orderId.toLowerCase().includes('tiktok') || 
                       !orderId.match(/^\d+$/) || 
                       (order.productName && order.productName.toLowerCase().includes('tiktok')) || 
                       (order as any).isTikTok;
      const platformLabel = isTikTok ? 'TikTok Shop' : 'Shopee';

      // Trường hợp 1: Chuyển sang thành công (approved) và trạng thái cũ khác approved
      if (newStatus === 'approved' && oldStatus !== 'approved') {
        targetUser.availableBalance += rebateAmount;
        targetUser.totalCashback += rebateAmount;

        // Nhật ký dòng tiền
        dbTransactions.unshift({
          id: 'tx_cb_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
          username: targetUser.username,
          amount: rebateAmount,
          type: 'cashback',
          description: `+${rebateAmount.toLocaleString('vi-VN')}đ Cashback đơn ${platformLabel} #${orderId}`,
          createdAt: new Date().toISOString()
        });

        // Thông báo cho thành viên nhận ngay lập tức theo yêu cầu chính xác của trạng thái duyệt & đối soát
        dbNotifications.unshift({
          id: 'nt_cb_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
          username: targetUser.username,
          title: 'Đơn hàng đã được duyệt 🟢',
          content: `Đơn hàng #${orderId} đã được duyệt thành công.`,
          isRead: false,
          createdAt: new Date().toISOString()
        });

        dbNotifications.unshift({
          id: 'nt_cb_ds_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
          username: targetUser.username,
          title: 'Đơn hàng đã được đối soát 💰',
          content: `Đơn hàng #${orderId} đã được đối soát. Tiền hoàn đã được cộng vào số dư khả dụng.`,
          isRead: false,
          createdAt: new Date().toISOString()
        });
      }
      // Trường hợp 2: Trả lại trạng thái từ approved sang trạng thái khác (hủy/kiểm tra lại) để trừ ví khả dụng
      else if (oldStatus === 'approved' && newStatus !== 'approved') {
        const prevRebate = order.rebateAmount || rebateAmount;
        targetUser.availableBalance = Math.max(0, targetUser.availableBalance - prevRebate);
        targetUser.totalCashback = Math.max(0, targetUser.totalCashback - prevRebate);

        dbTransactions.unshift({
          id: 'tx_cb_rev_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
          username: targetUser.username,
          amount: -prevRebate,
          type: 'cashback',
          description: `-${prevRebate.toLocaleString('vi-VN')}đ Điều chỉnh hoàn tiền đơn ${platformLabel} #${orderId}`,
          createdAt: new Date().toISOString()
        });

        dbNotifications.unshift({
          id: 'nt_cb_rev_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
          username: targetUser.username,
          title: `Thay đổi trạng thái đơn ${platformLabel} 🔴`,
          content: `Đơn hàng #${orderId} chuyển về trạng thái: ${
            newStatus === 'cancelled' ? 'Không tìm thấy tiền hoàn' : 'Chờ đối soát lại'
          }. Chúng tôi buộc điều chỉnh giảm số dư tương ứng.`,
          isRead: false,
          createdAt: new Date().toISOString()
        });
      }
    }

    saveOrders(dbOrders);
    saveUsers(dbUsers);
    saveWalletTransactions(dbTransactions);
    saveInternalNotifications(dbNotifications);

    // Cập nhật lên UI
    setOrders(getOrders());
    setUsers(getUsers());
    setStats(getDashboardStats());
    onRefreshData();
    alert(`Đã cập nhật trạng thái đơn #${orderId} thành công!`);
  };

  const handleSaveDeclNote = (orderId: string) => {
    const dbOrders = getOrders();
    const orderIdx = dbOrders.findIndex(o => o.orderId === orderId);
    if (orderIdx >= 0) {
      dbOrders[orderIdx].internalNote = declNoteInputs[orderId] || '';
      saveOrders(dbOrders);
      setOrders(getOrders());
      alert('Đã lưu ghi chú nội bộ thành công!');
    }
  };

  const handleDeleteDeclaration = (orderId: string) => {
    const dbOrders = getOrders();
    const orderIdx = dbOrders.findIndex(o => o.orderId === orderId);
    if (orderIdx >= 0) {
      const order = dbOrders[orderIdx];
      if (order.status === 'approved') {
        const dbUsers = getUsers();
        const dbTransactions = getWalletTransactions();
        const userIdx = dbUsers.findIndex(u => u.username === order.username);
        if (userIdx >= 0) {
          const prevRebate = order.rebateAmount || 0;
          dbUsers[userIdx].availableBalance = Math.max(0, dbUsers[userIdx].availableBalance - prevRebate);
          dbUsers[userIdx].totalCashback = Math.max(0, dbUsers[userIdx].totalCashback - prevRebate);
          
          dbTransactions.unshift({
            id: 'tx_cb_del_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
            username: order.username,
            amount: -prevRebate,
            type: 'cashback',
            description: `-${prevRebate.toLocaleString('vi-VN')}đ Hủy xóa đơn #${orderId}`,
            createdAt: new Date().toISOString()
          });
          saveUsers(dbUsers);
          saveWalletTransactions(dbTransactions);
        }
      }

      dbOrders.splice(orderIdx, 1);
      saveOrders(dbOrders);
      setOrders(getOrders());
      setUsers(getUsers());
      setStats(getDashboardStats());
      onRefreshData();
      if (typeof (window as any).showToast === 'function') {
        (window as any).showToast('✅ Xóa bỏ khai báo thành công', 'success');
      }
    }
  };

  // Cập nhật cấu hình hệ thống
  const handleConfigSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveConfig(config);
    alert('🎉 Đã cập nhật thành công Cấu hình Affiliate & Tỷ lệ Hoàn Tiền mặc định!');
    onRefreshData();
  };

  // Tạo & Tải File Excel Mẫu
  const handleDownloadTemplate = () => {
    const data = [
      { 
        "Mã đơn hàng": "849204892408", 
        "Hoa hồng gốc": 24000, 
        "Sub_ID": "shpee_tthuy3326_thuthuy", 
        "Trạng thái": "Đã duyệt", 
        "Tên sản phẩm": "Son Tint Bóng Romand Juicy Lasting Tint #23" 
      },
      { 
        "Mã đơn hàng": "951204812311", 
        "Hoa hồng gốc": 90000, 
        "Sub_ID": "shpee_tthuy3326_thuthuy", 
        "Trạng thái": "Chờ duyệt", 
        "Tên sản phẩm": "Kem Chống Nắng Anessa Tone Up Gel" 
      },
      { 
        "Mã đơn hàng": "741294829104", 
        "Hoa hồng gốc": 30000, 
        "Sub_ID": "shpee_tthuy3326_bongbong", 
        "Trạng thái": "Đã duyệt", 
        "Tên sản phẩm": "Kính gọng nơ Coquette" 
      },
      { 
        "Mã đơn hàng": "112233445566", 
        "Hoa hồng gốc": 50000, 
        "Sub_ID": "shpee_tthuy3326_thuthuy", 
        "Trạng thái": "Đã duyệt", 
        "Tên sản phẩm": "Kẹp tóc nơ thỏ ren trắng" 
      },
      { 
        "Mã đơn hàng": "998877665544", 
        "Hoa hồng gốc": 80000, 
        "Sub_ID": "shpee_tthuy3326_khach_vo_danh", 
        "Trạng thái": "Đã hủy", 
        "Tên sản phẩm": "Váy thiết kế bèo tầng pinky" 
      }
    ];

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Affiliate Report");
    XLSX.writeFile(wb, "Bao_Cao_Affiliate_Shopee.xlsx");
  };

  // Đồng bộ hóa dữ liệu từ Excel upload
  const syncOrdersFromExcel = (rows: any[], filename: string) => {
    try {
      const dbOrders = getOrders();
      const dbUsers = getUsers();
      const dbTransactions = getWalletTransactions();
      const dbNotifications = getInternalNotifications();
      const dbExcelLogs = getExcelUploadLogs();

      let countSynced = 0;
      let countNew = 0;

      rows.forEach((row) => {
        // Trích xuất linh động các trường
        const orderId = String(row["Mã đơn hàng"] || row["Order ID"] || row["Order Code"] || "").trim();
        const rawComm = parseFloat(row["Hoa hồng gốc"] || row["Commission"] || row["Share"] || row["Hoa hồng"] || "0");
        const subIdStr = String(row["Sub_ID"] || row["sub_id_1"] || row["Sub ID"] || row["Mã phụ"] || "").trim();
        const statusStr = String(row["Trạng thái"] || row["Status"] || "").trim().toLowerCase();
        const prodName = String(row["Tên sản phẩm"] || row["Product Name"] || "Sản phẩm Shopee hoàn tiền").trim();

        if (!orderId) return;

        // Trích xuất tên người dùng từ subIdStr (VD: 'shpee_tthuy3326_thuthuy' => 'thuthuy')
        let username = 'khach_vo_danh';
        const lastUnderscore = subIdStr.lastIndexOf('_');
        if (lastUnderscore >= 0) {
          username = subIdStr.slice(lastUnderscore + 1);
        }

        // Định dạng trạng thái đơn
        let status: OrderStatus = 'pending_approve';
        if (statusStr.includes('duyệt') || statusStr.includes('approved') || statusStr.includes('thành công')) {
          status = 'approved';
        } else if (statusStr.includes('hủy') || statusStr.includes('cancelled') || statusStr.includes('từ chối')) {
          status = 'cancelled';
        } else if (statusStr.includes('ghi nhận') || statusStr.includes('rec')) {
          status = 'pending_record';
        }

        // Tính tiền hoàn cho khách dựa theo tỷ lệ cấu hình Admin
        const systemRebatePercent = config.rebatePercent / 100;
        const rebateAmount = Math.round(rawComm * systemRebatePercent);

        // Kiểm tra xem đơn hàng đã bộc phát hay chưa
        const matchIndex = dbOrders.findIndex(o => o.orderId === orderId);

        if (matchIndex >= 0) {
          const matchedOrder = dbOrders[matchIndex];
          const oldStatus = matchedOrder.status;
          
          // Thực hiện cập nhật bổ sung dữ liệu
          // Nếu trạng thái đổi sang APPROVED, ta cộng tiền vào ví khả dụng người dùng
          if (status === 'approved' && oldStatus !== 'approved') {
            const userIdx = dbUsers.findIndex(u => u.username === matchedOrder.username);
            if (userIdx >= 0) {
              const targetUser = dbUsers[userIdx];
              targetUser.availableBalance += rebateAmount;
              targetUser.totalCashback += rebateAmount;

              // Ghi log giao dịch ví khả dụng
              dbTransactions.unshift({
                id: 'tx_cb_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
                username: targetUser.username,
                amount: rebateAmount,
                type: 'cashback',
                description: `+${rebateAmount.toLocaleString('vi-VN')}đ Hoàn tiền đơn Shopee #${orderId}`,
                createdAt: new Date().toISOString()
              });

              // Tạo thông báo nội bộ
              dbNotifications.unshift({
                id: 'nt_cb_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
                username: targetUser.username,
                title: 'Đơn hàng được duyệt! 🎉',
                content: `Ưu đãi hoàn tiền đơn hàng #${orderId} (${prodName}) trị giá +${rebateAmount.toLocaleString('vi-VN')}đ đã được cộng vào Ví khả dụng của bạn.`,
                isRead: false,
                createdAt: new Date().toISOString()
              });

              // Nếu người dùng có người giới thiệu, và người giới thiệu đủ 3 đơn APPROVED => thưởng 10%
              const referrer = targetUser.referredBy;
              if (referrer) {
                const referrerApprovedCount = dbOrders.filter(o => o.username === referrer && o.status === 'approved').length;
                const referrerIdx = dbUsers.findIndex(u => u.username === referrer);

                if (referrerIdx >= 0 && referrerApprovedCount >= 3) {
                  // Chỉ được hưởng hoa hồng giới thiệu trong vòng 3 tháng kể từ ngày Người được giới thiệu đăng ký
                  const regDateStr = targetUser.registeredAt || new Date().toISOString();
                  const refereeRegDate = new Date(regDateStr);
                  const daysDiff = Math.ceil(Math.abs(new Date().getTime() - refereeRegDate.getTime()) / (1000 * 60 * 60 * 24));
                  
                  if (daysDiff <= 92) {
                    const refGift = Math.round(rebateAmount * 0.1);
                    if (refGift > 0) {
                      dbUsers[referrerIdx].availableBalance += refGift;
                      dbUsers[referrerIdx].totalCashback += refGift;

                      // Ghi log ví cho referrer
                      dbTransactions.unshift({
                        id: 'tx_ref_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
                        username: referrer,
                        amount: refGift,
                        type: 'referral',
                        description: `+${refGift.toLocaleString('vi-VN')}đ Thưởng đại sứ: bạn bè @${targetUser.username} hoàn thành đơn #${orderId}`,
                        createdAt: new Date().toISOString()
                      });

                      // Thông báo cho referrer
                      dbNotifications.unshift({
                        id: 'nt_ref_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
                        username: referrer,
                        title: 'Thưởng giới thiệu bạn bè! 🎀',
                        content: `Bạn nhận được +${refGift.toLocaleString('vi-VN')}đ (10%) hoa hồng đại sứ từ đơn hàng #${orderId} của bạn bè @${targetUser.username} nhé.`,
                        isRead: false,
                        createdAt: new Date().toISOString()
                      });
                    }
                  }
                }
              }
            }
          }

          // Cập nhật thuộc tính của order đã có
          matchedOrder.rawCommission = rawComm;
          matchedOrder.rebateAmount = rebateAmount;
          matchedOrder.status = status;
          matchedOrder.productName = prodName;
          matchedOrder.platform = 'shopee';
          matchedOrder.syncedAt = new Date().toISOString();
          countSynced++;
        } else {
          // Tạo mới đơn do admin import trực tiếp
          const newOrder: Order = {
            orderId,
            username,
            time: new Date().toISOString(),
            rebateAmount,
            rawCommission: rawComm,
            status,
            productName: prodName,
            platform: 'shopee',
            syncedAt: new Date().toISOString()
          };

          // Nếu đơn hàng IMPORT mới đã là APPROVED, cộng tiền luôn
          if (status === 'approved') {
            const userIdx = dbUsers.findIndex(u => u.username === username);
            if (userIdx >= 0) {
              const targetUser = dbUsers[userIdx];
              targetUser.availableBalance += rebateAmount;
              targetUser.totalCashback += rebateAmount;

              // Ghi log giao dịch ví khả dụng
              dbTransactions.unshift({
                id: 'tx_cb_new_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
                username: targetUser.username,
                amount: rebateAmount,
                type: 'cashback',
                description: `+${rebateAmount.toLocaleString('vi-VN')}đ Hoàn tiền đơn Shopee #${orderId}`,
                createdAt: new Date().toISOString()
              });

              // Tạo thông báo nội bộ
              dbNotifications.unshift({
                id: 'nt_cb_new_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
                username: targetUser.username,
                title: 'Đơn mới được duyệt từ hệ thống! 🎉',
                content: `Đơn hàng #${orderId} (${prodName}) vừa được đồng bộ hoàn thành. Ví của bạn đã được cộng +${rebateAmount.toLocaleString('vi-VN')}đ.`,
                isRead: false,
                createdAt: new Date().toISOString()
              });
            }
          }

          dbOrders.unshift(newOrder);
          countNew++;
        }
      });

      // Tạo lịch sử đối soát Excel
      const newSyncLog: ExcelUploadLog = {
        id: 'el_' + Date.now(),
        filename: filename || 'Báo cáo tải lên',
        operator: 'Admin',
        matchedOrders: countSynced,
        newOrders: countNew,
        createdAt: new Date().toISOString()
      };
      dbExcelLogs.unshift(newSyncLog);

      // Lưu lại vào DB
      saveOrders(dbOrders);
      saveUsers(dbUsers);
      saveWalletTransactions(dbTransactions);
      saveInternalNotifications(dbNotifications);
      saveExcelUploadLogs(dbExcelLogs);

      // Cập nhật state cục bộ
      setOrders(getOrders());
      setUsers(getUsers());
      setExcelLogs(getExcelUploadLogs());
      setStats(getDashboardStats());

      setExcelSuccessMsg(`🎉 Đồng bộ thành công: Đã nạp mới ${countNew} đơn và cập nhật đối soát ${countSynced} đơn hàng từ tệp "${filename}"! Tiền hoàn và thông báo đã tự động gửi đến thành viên.`);
      onRefreshData();
    } catch (e) {
      alert('⚠️ Định dạng File lỗi. Vui lòng tải file mẫu để xem tiêu đề cột chuẩn xác.');
    }
  };

  const handleExcelUploadChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const filename = file.name;
    const reader = new FileReader();
    reader.onload = (evt) => {
      const bstr = evt.target?.result;
      const wb = XLSX.read(bstr, { type: 'binary' });
      const wsname = wb.SheetNames[0];
      const ws = wb.Sheets[wsname];
      const parsed: any[] = XLSX.utils.sheet_to_json(ws);
      syncOrdersFromExcel(parsed, filename);
    };
    reader.readAsBinaryString(file);
  };

  // Duyệt/Từ chối rút tiền của người dùng
  const handleProcessWithdraw = (id: string, action: 'completed' | 'rejected') => {
    const requests = getWithdrawRequests();
    const dbUsers = getUsers();
    const dbTransactions = getWalletTransactions();
    const dbNotifications = getInternalNotifications();
    
    const reqIdx = requests.findIndex(r => r.id === id);

    if (reqIdx >= 0) {
      const req = requests[reqIdx];
      req.status = action;
      req.processedAt = new Date().toISOString();

      // Nếu từ chối, trả lại tiền khả dụng cho user
      if (action === 'rejected') {
        const uIdx = dbUsers.findIndex(u => u.username === req.username);
        if (uIdx >= 0) {
          dbUsers[uIdx].availableBalance += req.amount;
          dbUsers[uIdx].pendingBalance -= req.amount; // Giảm tiền chờ duyệt
          saveUsers(dbUsers);

          // Tạo thông báo hoàn trả
          dbNotifications.unshift({
            id: 'nt_wd_rej_' + Date.now(),
            username: req.username,
            title: 'Yêu cầu rút tiền bị từ chối ⚠️',
            content: `Yêu cầu rút ${req.amount.toLocaleString('vi-VN')}đ đã bị từ chối. Số tiền đã được hoàn trả lại vào Ví khả dụng của bạn.`,
            isRead: false,
            createdAt: new Date().toISOString()
          });
        }
      } else if (action === 'completed') {
        // Nếu duyệt rút, trừ đi số tiền chờ duyệt
        const uIdx = dbUsers.findIndex(u => u.username === req.username);
        if (uIdx >= 0) {
          dbUsers[uIdx].pendingBalance -= req.amount;
          saveUsers(dbUsers);

          // Ghi nợ giao dịch WalletTransaction
          dbTransactions.unshift({
            id: 'tx_wd_' + Date.now(),
            username: req.username,
            amount: -req.amount,
            type: 'withdraw',
            description: `Rút tiền mặt về tài khoản ngân hàng ${req.bankName}`,
            createdAt: new Date().toISOString()
          });

          // Tạo thông báo hoàn thành theo yêu cầu chính xác của trạng thái rút tiền thành công
          dbNotifications.unshift({
            id: 'nt_wd_ok_' + Date.now(),
            username: req.username,
            title: 'Rút tiền thành công 🏦',
            content: `Yêu cầu rút tiền #${id} đã được xử lý thành công.`,
            isRead: false,
            createdAt: new Date().toISOString()
          });
        }
      }

      saveWithdrawRequests(requests);
      saveWalletTransactions(dbTransactions);
      saveInternalNotifications(dbNotifications);

      setWithdraws(getWithdrawRequests());
      setUsers(getUsers());
      setStats(getDashboardStats());
      onRefreshData();
      if (typeof (window as any).showToast === 'function') {
        (window as any).showToast(`✅ Đã ${action === 'completed' ? 'duyệt chi' : 'từ chối'} yêu cầu rút tiền thành công`, 'success');
      }
    }
  };

  // Quản lý bình luận (Xóa bình luận tiêu cực)
  const handleDeleteComment = (id: string) => {
    const confirmDel = window.confirm('Bạn có đồng ý xóa bình luận này từ bảng tin không?');
    if (!confirmDel) return;

    const left = comments.filter(c => c.id !== id);
    saveComments(left);
    setComments(left);
    onRefreshData();
  };

  // Tạo voucher mới
  const handleAddNewVoucher = (e: React.FormEvent) => {
    e.preventDefault();
    if (!vouchTitle || !vouchValue || !vouchCost) return;

    const listVouchers = getVouchers();
    const newV: Voucher = {
      id: 'v' + (listVouchers.length + 101),
      title: vouchTitle,
      discountValue: parseInt(vouchValue, 10),
      costPoints: parseInt(vouchCost, 10),
      expiryDate: vouchExpiry,
      code: 'MHS' + Math.random().toString(36).substring(2, 7).toUpperCase()
    };

    listVouchers.unshift(newV);
    saveVouchers(listVouchers);
    setVouchers(listVouchers);
    
    setVouchTitle('');
    setVouchValue('');
    setVouchCost('');
    alert('Thêm voucher quà tặng mới thành công 🎉');
  };

  return (
    <div className="space-y-6">
      
      {/* Title Header (Gradient Admin Header) */}
      <div className="bg-gradient-to-r from-[#FF8A47] to-[#FF6B9D] p-6 rounded-3xl text-white space-y-1 shadow-lg text-left relative overflow-hidden">
        <div className="absolute right-4 top-1/2 -translate-y-1/2 text-5xl opacity-15 select-none pointer-events-none">👑</div>
        <h2 className="font-serif text-2xl font-black flex items-center gap-1.5 text-white">
          <span>Hệ Thống Quản Trị Mê Hoàn Xu</span>
          <span className="text-xl">🛡️</span>
        </h2>
        <p className="text-xs text-stone-100 font-semibold max-w-2xl">Quản lý thành viên đại sứ, kiểm tra click logs, tra soát đơn thất lạc, duyệt chi tiền mặt và cập nhật tin tức cashback</p>
      </div>

      {/* Admin tabs selector */}
      <div className="flex flex-wrap border-b border-gray-100 p-0.5 bg-coquette-cream rounded-2xl gap-0.5">
        <button
          onClick={() => setSubTab('stats')}
          className={`flex-1 text-center py-2 rounded-xl text-[10.5px] font-bold cursor-pointer transition-all ${
            subTab === 'stats' ? 'bg-coquette-accent text-white shadow-xs' : 'text-gray-500 hover:text-coquette-accent'
          }`}
        >
          📈 Thống Kê
        </button>
        
        <button
          onClick={() => setSubTab('excel')}
          className={`flex-1 text-center py-2 rounded-xl text-[10.5px] font-bold cursor-pointer transition-all ${
            subTab === 'excel' ? 'bg-coquette-accent text-white shadow-xs' : 'text-gray-500 hover:text-coquette-accent'
          }`}
        >
          📥 Đối Soát
        </button>

        <button
          onClick={() => setSubTab('declarations')}
          className={`flex-1 text-center py-2 rounded-xl text-[10.5px] font-bold cursor-pointer transition-all relative ${
            subTab === 'declarations' ? 'bg-coquette-accent text-white shadow-xs' : 'text-gray-500 hover:text-coquette-accent'
          }`}
        >
          📦 Đơn Khai Báo
          {orders.some(o => o.status === 'pending_record') && (
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-rose-500 rounded-full animate-ping" />
          )}
        </button>

        <button
          onClick={() => setSubTab('withdrawals')}
          className={`flex-1 text-center py-2 rounded-xl text-[10.5px] font-bold cursor-pointer transition-all relative ${
            subTab === 'withdrawals' ? 'bg-coquette-accent text-white shadow-xs' : 'text-gray-500 hover:text-coquette-accent'
          }`}
        >
          💸 Rút Ví
          {withdraws.some(w => w.status === 'pending') && (
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full animate-ping" />
          )}
        </button>

        <button
          onClick={() => setSubTab('tickets')}
          className={`flex-1 text-center py-2 rounded-xl text-[10.5px] font-bold cursor-pointer transition-all relative ${
            subTab === 'tickets' ? 'bg-coquette-accent text-white shadow-xs' : 'text-gray-500 hover:text-coquette-accent'
          }`}
        >
          💬 Tickets
          {allTickets.some(t => t.status === 'pending') && (
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-orange-500 rounded-full animate-ping" />
          )}
        </button>

        <button
          onClick={() => setSubTab('items')}
          className={`flex-1 text-center py-2 rounded-xl text-[10.5px] font-bold cursor-pointer transition-all ${
            subTab === 'items' ? 'bg-coquette-accent text-white shadow-xs' : 'text-gray-500 hover:text-coquette-accent'
          }`}
        >
          🎀 Shop & Tin
        </button>

        <button
          onClick={() => setSubTab('config')}
          className={`flex-1 text-center py-2 rounded-xl text-[10.5px] font-bold cursor-pointer transition-all ${
            subTab === 'config' ? 'bg-coquette-accent text-white shadow-xs' : 'text-gray-500 hover:text-coquette-accent'
          }`}
        >
          ⚙️ Tỷ Lệ
        </button>

        <button
          onClick={() => setSubTab('content')}
          className={`flex-1 text-center py-2 rounded-xl text-[10.5px] font-bold cursor-pointer transition-all ${
            subTab === 'content' ? 'bg-coquette-accent text-white shadow-xs' : 'text-gray-500 hover:text-coquette-accent'
          }`}
        >
          🌸 Nội Dung
        </button>

        <button
          onClick={() => setSubTab('tiktok_shop')}
          className={`flex-1 text-center py-2 rounded-xl text-[10.5px] font-bold cursor-pointer transition-all ${
            subTab === 'tiktok_shop' ? 'bg-coquette-accent text-white shadow-xs' : 'text-gray-500 hover:text-coquette-accent'
          }`}
        >
          🖤 TikTok Shop
        </button>
      </div>

      {/* STATS SUB VIEW */}
      {subTab === 'stats' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl p-6 border-2 border-slate-700 shadow-md space-y-5">
            <h3 className="font-serif text-sm font-black text-slate-800 flex items-center justify-between pb-3 border-b-2 border-dashed border-slate-200">
              <div className="flex items-center gap-1.5 uppercase tracking-wider">
                <BarChart3 className="w-5 h-5 text-indigo-600 animate-pulse" />
                <span>Báo Cáo Tổng Quan Hệ Thống (Real-time)</span>
              </div>
              <span className="text-[9px] bg-slate-900 text-white font-mono px-2.5 py-1 rounded-full uppercase tracking-widest font-black border border-slate-800">
                ADMIN WORKSPACE 🛡️
              </span>
            </h3>

            {/* Grid stats cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-gradient-to-br from-[#FFF2EB] to-[#FFE0CC] p-5 rounded-2xl border-2 border-[#FFA87D] shadow-md space-y-1.5 hover:scale-[1.02] transition-all duration-250">
                <span className="text-[10px] text-[#C2410C] font-black uppercase tracking-wider block">Tổng đơn hàng</span>
                <p className="text-xl font-black text-[#9A3412] font-mono tracking-tight">{stats.totalOrders} đơn</p>
              </div>

              <div className="bg-gradient-to-br from-[#ECFDF5] to-[#D1FAE5] p-5 rounded-2xl border-2 border-[#10B981] shadow-md space-y-1.5 hover:scale-[1.02] transition-all duration-250">
                <span className="text-[10px] text-[#047857] font-black uppercase tracking-wider block">Tổng hoa hồng</span>
                <p className="text-xl font-black text-[#065F46] font-mono tracking-tight">{stats.totalCashbackPaid.toLocaleString('vi-VN')}đ</p>
              </div>

              <div className="bg-gradient-to-br from-[#FAF5FF] to-[#E9D5FF] p-5 rounded-2xl border-2 border-[#A855F7] shadow-md space-y-1.5 hover:scale-[1.02] transition-all duration-250">
                <span className="text-[10px] text-[#6B21A8] font-black uppercase tracking-wider block">Tổng thành viên</span>
                <p className="text-xl font-black text-[#581C87] font-mono tracking-tight">{users.length} tài khoản</p>
              </div>

              <div className="bg-gradient-to-br from-[#FFFBEB] to-[#FEF3C7] p-5 rounded-2xl border-2 border-[#F59E0B] shadow-md space-y-1.5 hover:scale-[1.02] transition-all duration-250">
                <span className="text-[10px] text-[#B45309] font-black uppercase tracking-wider block">Tổng link đã tạo</span>
                <p className="text-xl font-black text-[#92400E] font-mono tracking-tight">{stats.totalLinksCreated} liên kết</p>
              </div>
            </div>
          </div>

          {/* User management list detail */}
          <div className="bg-white rounded-3xl p-5 border border-coquette-deep/40 shadow-xs space-y-3">
            <h3 className="font-serif text-sm font-bold text-gray-800 flex items-center gap-1.5 pb-2 border-b border-dashed border-coquette-deep/30">
              <Users className="w-4 h-4 text-coquette-accent" />
              <span>Danh Sách Người Dùng ({users.length})</span>
            </h3>

            <div className="max-h-52 overflow-y-auto pr-1">
              {users.map((u) => (
                <div key={u.username} className="py-2.5 flex justify-between items-center text-xs bg-white border-b border-gray-300 hover:bg-gray-50/50 px-1 transition-all">
                  <div className="space-y-0.5">
                    <span className="font-bold text-[#1F2937] block flex items-center gap-1">
                      <span>@{u.username}</span>
                      {u.role === 'admin' ? (
                        <span className="text-[9px] bg-amber-50 text-amber-700 border border-amber-200 px-1 py-0.2 rounded font-sans shrink-0">Admin 👑</span>
                      ) : (
                        <span className="text-[9px] bg-gray-50 text-gray-500 border border-gray-150 px-1 py-0.2 rounded font-sans shrink-0">Thành viên 🎀</span>
                      )}
                    </span>
                    <span className="text-[9px] text-[#6B7280] font-mono">Đăng ký: {new Date(u.registeredAt).toLocaleDateString('vi-VN')}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <span className="font-bold text-[#F97316] block">{u.availableBalance.toLocaleString('vi-VN')}đ khả dụng</span>
                      <span className="text-[9px] text-gray-405 block">Chờ: {u.pendingBalance.toLocaleString('vi-VN')}đ</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => { setTargetUserForPasswordChange(u.username); setNewPasswordInput(''); }}
                      className="bg-coquette-pink hover:bg-coquette-pink/85 text-coquette-deep font-bold py-1 px-2.5 rounded-lg text-[10px] cursor-pointer transition-all flex items-center gap-1 shadow-3xs"
                    >
                      <Key className="w-3 h-3 text-coquette-accent" />
                      <span>Đổi mật khẩu</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Audit log of Admin password changes */}
            {passwordChangeLogs.length > 0 && (
              <div className="mt-4 pt-3 border-t border-dashed border-coquette-deep/25">
                <span className="font-bold text-[11px] text-gray-600 block mb-1.5 flex items-center gap-1">
                  <Lock className="w-3.5 h-3.5 text-coquette-accent" />
                  <span>Nhật Ký Quản Trị Mật Khẩu ({passwordChangeLogs.length})</span>
                </span>
                <div className="max-h-24 overflow-y-auto space-y-1.5 pr-1 font-mono text-[10px] text-gray-450">
                  {passwordChangeLogs.map((log) => (
                    <div key={log.id} className="py-1 flex justify-between items-start gap-2 border-b border-gray-50 border-dashed">
                      <span>
                        Admin <strong className="text-gray-700 font-sans">@{log.adminUsername}</strong> đã đặt lại mật khẩu cho <strong className="text-gray-700 font-sans">@{log.targetUsername}</strong>
                      </span>
                      <span className="text-gray-400 shrink-0 text-[9px]">
                        {new Date(log.changedAt).toLocaleString('vi-VN')}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Modal Đổi mật khẩu của Admin */}
          {targetUserForPasswordChange && (
            <div className="fixed inset-0 bg-black/40 z-[150] flex items-center justify-center p-4 backdrop-blur-xs animate-in fade-in duration-200">
              <div className="bg-white w-[90%] md:w-full md:max-w-xl rounded-[24px] border-2 border-coquette-deep shadow-2xl overflow-hidden p-6 space-y-4 animate-in zoom-in-95 duration-200">
                <div className="text-center space-y-1">
                  <div className="w-10 h-10 rounded-full bg-coquette-pink/30 flex items-center justify-center mx-auto text-coquette-accent">
                    <Lock className="w-5 h-5" />
                  </div>
                  <h3 className="font-serif text-sm font-bold text-gray-800">
                    Đổi mật khẩu: <span className="text-coquette-accent">@{targetUserForPasswordChange}</span>
                  </h3>
                  <p className="text-[10px] text-gray-450 leading-relaxed">
                    Đặt mật khẩu mới thay thế mật khẩu cũ ngay lập tức. Theo cơ chế bảo mật tối cao, bạn không xem được mật khẩu hiện tại của thành viên.
                  </p>
                </div>

                <form onSubmit={handleConfirmPasswordChange} className="space-y-3">
                  <div className="space-y-1">
                    <span className="text-[10.5px] font-bold text-gray-600 block">Mật khẩu mới:</span>
                    <div className="flex gap-1.5">
                      <input
                        type="text"
                        required
                        value={newPasswordInput}
                        placeholder="Tối thiểu 6 ký tự..."
                        onChange={(e) => setNewPasswordInput(e.target.value)}
                        className="flex-1 text-xs px-3 py-2 bg-coquette-cream/30 border border-coquette-deep/40 rounded-xl font-mono text-gray-700 focus:outline-none focus:border-coquette-accent"
                      />
                      <button
                        type="button"
                        onClick={handleGenerateRandomPassword}
                        className="bg-coquette-cream hover:bg-coquette-pink hover:text-coquette-accent border border-coquette-deep text-gray-650 px-2.5 py-1.5 rounded-xl text-[10px] font-bold cursor-pointer transition-all shrink-0 shadow-3xs"
                      >
                        Ngẫu nhiên 🎲
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => { setTargetUserForPasswordChange(null); setNewPasswordInput(''); }}
                      className="w-full bg-gray-100 hover:bg-gray-200 text-gray-600 font-bold py-2 rounded-xl text-xs cursor-pointer transition-all"
                    >
                      Hủy bỏ
                    </button>
                    <button
                      type="submit"
                      disabled={!newPasswordInput.trim()}
                      className="w-full bg-coquette-accent hover:bg-coquette-accent/90 disabled:bg-gray-200 text-white font-bold py-2 rounded-xl text-xs cursor-pointer transition-all shadow-3xs"
                    >
                      Xác nhận đổi ✓
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* EXCEL IMPORT SUB VIEW */}
      {subTab === 'excel' && (
        <div className="bg-white rounded-3xl p-5 border border-coquette-deep/40 shadow-xs space-y-5 animate-in fade-in duration-200 text-left">
          <div className="pb-2 border-b border-dashed border-coquette-deep/30 flex justify-between items-center flex-wrap gap-2">
            <div>
              <h3 className="font-serif text-sm font-bold text-gray-800 flex items-center gap-1.5 animate-in duration-150 uppercase tracking-wide">
                <Database className="w-4 h-4 text-coquette-accent" />
                <span>QUẢN LÝ ĐỐI SOÁT</span>
              </h3>
              <p className="text-[10.5px] text-gray-400">Chọn kênh đối soát Shopee hoặc TikTok Shop để hạch toán thưởng cho thành viên.</p>
            </div>
            
            {/* Integrated Sub-Tab Switcher */}
            <div className="flex bg-coquette-cream p-1 rounded-xl border border-coquette-deep/20 gap-1 text-[11px] font-bold">
              <button
                onClick={() => setReconcileChannel('shopee')}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                  reconcileChannel === 'shopee'
                    ? 'bg-coquette-accent text-white shadow-3xs'
                    : 'text-gray-500 hover:text-coquette-accent'
                }`}
              >
                🛍️ Shopee
              </button>
              <button
                onClick={() => setReconcileChannel('tiktok')}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                  reconcileChannel === 'tiktok'
                    ? 'bg-coquette-accent text-white shadow-3xs'
                    : 'text-gray-500 hover:text-coquette-accent'
                }`}
              >
                🖤 TikTok Shop
              </button>
            </div>
          </div>

          {reconcileChannel === 'shopee' ? (
            <div className="space-y-5 animate-in fade-in duration-150">
              <div>
                <h4 className="text-xs font-bold text-gray-750">Upload Báo Cáo Shopee Excel</h4>
                <p className="text-[10.5px] text-gray-400">Hệ thống phân tích mã đơn hàng trùng khớp với Sub ID đặt mua trên Shopee và cộng tiền ví tự động.</p>
              </div>

              {/* Action to download template to test the flow */}
              <div className="bg-coquette-pink/30 p-4 rounded-2xl border border-coquette-deep/30 space-y-3">
                <div>
                  <span className="text-xs font-bold text-coquette-accent block">💡 Bạn chưa có báo cáo Shopee Excel?</span>
                  <p className="text-[10.5px] text-gray-500 leading-relaxed">
                    Hãy ấn nút dưới đây để tải về tệp Excel mẫu đối soát hoàn chỉnh do Mê Hoàn Xu tạo. Bạn có thể thay đổi hoặc giữ nguyên rồi dán upload trở lại để chứng kiến dòng tiền cộng thẳng vào tài khoản của khách cực kỳ linh diệu!
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleDownloadTemplate}
                  className="bg-white hover:bg-coquette-pink text-coquette-accent border border-coquette-deep font-bold text-xs py-2 px-4 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-3xs"
                >
                  <FileDown className="w-4 h-4" />
                  <span>Tải Excel Mẫu Đối Soát (.xlsx) 📥</span>
                </button>
              </div>

              {/* Real upload drop area */}
              <div className="space-y-3">
                <div className="border-2 border-dashed border-coquette-deep/60 rounded-2xl p-6 text-center hover:bg-coquette-pink/15 transition-all cursor-pointer relative">
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept=".xlsx, .xls, .csv"
                    onChange={handleExcelUploadChange}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                  <Upload className="w-8 h-8 text-coquette-accent mx-auto mb-2" />
                  <div className="space-y-1">
                    <span className="text-xs font-bold text-gray-700 block">Kéo thả hoặc nhấp để chọn tệp báo cáo Shopee</span>
                    <p className="text-[10px] text-gray-400">Chấp nhận tệp định dạng .xlsx, .xls hoặc .csv</p>
                  </div>
                </div>

                {excelSuccessMsg && (
                  <div className="p-3.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-xl text-xs leading-relaxed flex gap-2">
                    <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-600" />
                    <span>{excelSuccessMsg}</span>
                  </div>
                )}

                {/* Excel Sync History Trail display */}
                <div className="space-y-2.5 pt-2 border-t border-dashed border-coquette-deep/20 text-xs">
                  <span className="font-bold text-gray-750 block flex items-center gap-1.5">
                    <span>📊 Lịch Sử Đồng Bộ Báo Cáo Affiliate ({excelLogs.length})</span>
                  </span>
                  
                  {excelLogs.length === 0 ? (
                    <p className="text-[10px] text-gray-400 text-center py-3 bg-gray-50/50 rounded-xl border border-dashed border-gray-200">Chưa ghi nhận phiên đối soát dữ liệu nào.</p>
                  ) : (
                    <div className="divide-y divide-gray-100 max-h-56 overflow-y-auto pr-1">
                      {excelLogs.map((log) => (
                        <div key={log.id} className="py-2.5 space-y-1 hover:bg-gray-50/30 p-1 rounded-lg">
                          <div className="flex justify-between items-start text-[11px]">
                            <span className="font-bold text-gray-700 max-w-[200px] truncate">📁 {log.filename}</span>
                            <span className="text-[10px] text-gray-400">{new Date(log.createdAt).toLocaleDateString('vi-VN')} {new Date(log.createdAt).toLocaleTimeString('vi-VN', {hour: '2-digit', minute: '2-digit'})}</span>
                          </div>
                          <div className="flex gap-4 text-[10.5px] text-gray-500">
                            <span>Đã khớp: <strong className="font-bold text-emerald-600">+{log.matchedOrders} đơn</strong></span>
                            <span>Nhập mới: <strong className="font-bold text-indigo-600">+{log.newOrders} đơn</strong></span>
                            <span>Cán bộ: <strong className="text-gray-600">{log.operator}</strong></span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-5 animate-in fade-in duration-150">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 text-white p-5 rounded-2xl border-2 border-coquette-deep shadow-sm">
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 bg-emerald-400 rounded-full animate-pulse" />
                    <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider block">Cấu hình đồng bộ TikTok Shop API</h4>
                  </div>
                  <p className="text-[10.5px] text-slate-400 max-w-lg leading-relaxed">
                    Hệ thống tự động liên hệ tới API đối tác của RioHub, lọc các đơn hàng có ghi nhận mã <strong className="text-coquette-pink font-bold">sub_id = username</strong> để ghi nhận tiền và thông báo thưởng lập tức.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleTikTokSync}
                  disabled={tiktokSyncing}
                  className="bg-coquette-accent hover:bg-opacity-95 text-white active:scale-95 disabled:scale-100 disabled:opacity-50 font-bold text-xs py-3 px-5 rounded-xl transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer shadow-sm font-sans uppercase"
                >
                  <RefreshCw className={`w-4 h-4 ${tiktokSyncing ? 'animate-spin' : ''}`} />
                  <span>{tiktokSyncing ? 'Đang gọi máy chủ...' : 'ĐỒNG BỘ ĐƠN HÀNG 🔄'}</span>
                </button>
              </div>

              {/* Dynamic Stats display */}
              {(() => {
                const isTikTokOrder = (o: Order) => {
                  const idLower = o.orderId.toLowerCase();
                  return idLower.includes('tiktok') || 
                         o.orderId.startsWith('1234') || 
                         (o.productName && o.productName.toLowerCase().includes('tiktok')) ||
                         (o as any).isTikTok ||
                         !o.orderId.match(/^\d+$/);
                };

                const tiktokOrdersList = orders.filter(isTikTokOrder);
                const totalTikTok = tiktokOrdersList.length;
                const donMoi = tiktokOrdersList.filter(o => o.status === 'pending_record').length;
                const choDuyet = tiktokOrdersList.filter(o => o.status === 'pending_approve').length;
                const daDuyet = tiktokOrdersList.filter(o => o.status === 'approved').length;
                const hoanTien = tiktokOrdersList.filter(o => o.status === 'cancelled').length;

                return (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
                      <div className="bg-slate-900 text-white p-3.5 rounded-xl border border-coquette-deep/20 space-y-1">
                        <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">Tổng đơn TikTok</span>
                        <p className="text-base font-black font-mono">{totalTikTok} đơn</p>
                      </div>
                      <div className="bg-blue-50/70 p-3.5 rounded-xl border border-blue-100 space-y-1 text-left">
                        <span className="text-[9px] font-bold text-blue-800 uppercase tracking-wider block">Đớn mới</span>
                        <p className="text-base font-black text-blue-700 font-mono">{donMoi} đơn</p>
                      </div>
                      <div className="bg-amber-50/70 p-3.5 rounded-xl border border-amber-100 space-y-1 text-left">
                        <span className="text-[9px] font-bold text-amber-800 uppercase tracking-wider block">Đớn chờ duyệt</span>
                        <p className="text-base font-black text-amber-700 font-mono">{choDuyet} đơn</p>
                      </div>
                      <div className="bg-emerald-50/70 p-3.5 rounded-xl border border-emerald-100 space-y-1 text-left">
                        <span className="text-[9px] font-bold text-emerald-800 uppercase tracking-wider block">Đớn đã duyệt</span>
                        <p className="text-base font-black text-emerald-700 font-mono">{daDuyet} đơn</p>
                      </div>
                      <div className="bg-rose-50/70 p-3.5 rounded-xl border border-rose-100 space-y-1 text-left">
                        <span className="text-[9px] font-bold text-rose-800 uppercase tracking-wider block">Đơn hoàn tiền (Hủy)</span>
                        <p className="text-base font-black text-rose-700 font-mono">{hoanTien} đơn</p>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {tiktokSyncResult && (
                <div className="space-y-2.5">
                  <div className={`p-4 border rounded-xl text-xs flex gap-2 animate-in slide-in-from-top-2 text-left ${
                    tiktokSyncResult.success 
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-200' 
                      : 'bg-rose-50 text-rose-800 border-rose-200'
                  }`}>
                    {tiktokSyncResult.success ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                    ) : (
                      <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
                    )}
                    <div>
                      <h5 className="font-bold">{tiktokSyncResult.success ? 'Đối soát TikTok Shop kết thúc thành công!' : 'Lỗi kết nối API'}</h5>
                      <p className="text-[10.5px] opacity-90 mt-0.5">
                        {tiktokSyncResult.success ? (
                          `Tìm thấy thành công ${tiktokSyncResult.newOrders} đơn hàng hoàn toàn mới để nạp xu và thông báo tự động. Đã sửa đổi cập nhật ${tiktokSyncResult.updatedOrders} đơn hàng khác.`
                        ) : tiktokSyncResult.status === 422 ? (
                          '⚠️ RioHub từ chối yêu cầu đồng bộ đơn hàng do dữ liệu gửi lên không hợp lệ. Vui lòng kiểm tra endpoint, creator_username và tham số truy vấn.'
                        ) : tiktokSyncResult.status === 401 ? (
                          '❌ API Key không hợp lệ'
                        ) : tiktokSyncResult.status === 403 ? (
                          '❌ Creator không thuộc API Key hiện tại'
                        ) : tiktokSyncResult.status === 404 ? (
                          '❌ Creator chưa được kết nối RioHub'
                        ) : (
                          tiktokSyncResult.error || 'Đã xảy ra sự cố không mong muốn khi tiến hành đối soát đơn hàng.'
                        )}
                      </p>
                    </div>
                  </div>

                  {tiktokSyncResult && (
                    <div className="bg-slate-900 border border-slate-700 p-4 rounded-2xl font-mono text-[10.5px] text-slate-300 text-left space-y-2.5 select-all animate-in fade-in duration-250">
                      <p className="text-cyan-400 font-bold flex items-center gap-1.5 uppercase">
                        <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse"></span>
                        <span>📋 THÔNG TIN DEBUG ĐỒNG BỘ ĐƠN HÀNG (TIKTOK SHOP):</span>
                      </p>
                      <div className="space-y-1.5">
                        <div>
                          <span className="text-purple-400 font-bold">Creator Username đọc từ Settings:</span>{' '}
                          <span className="text-amber-300 font-bold">
                            {tiktokSyncResult.debugInfo?.creatorUsernameFromSettings || 'N/A'}
                          </span>
                        </div>
                        <div>
                          <span className="text-purple-400 font-bold">Creator Username gửi lên API:</span>{' '}
                          <span className="text-amber-300 font-bold">
                            {tiktokSyncResult.debugInfo?.creatorUsernameSentToApi || 'N/A'}
                          </span>
                        </div>
                        <div>
                          <span className="text-purple-400 font-bold">URL cuối cùng:</span>{' '}
                          <span className="text-cyan-300 select-all underline break-all font-semibold">
                            {tiktokSyncResult.debugInfo?.finalApiUrl || 'N/A'}
                          </span>
                        </div>
                        <div className="border-t border-slate-800 my-1 pt-1 flex justify-between items-center">
                          <div>
                            <span className="text-purple-400 font-bold">Trạng thái phản hồi:</span>{' '}
                            <span className={tiktokSyncResult.success ? "text-emerald-400 font-bold" : "text-rose-400 font-bold"}>
                              {tiktokSyncResult.status || (tiktokSyncResult.success ? 200 : 500)}
                            </span>
                          </div>
                        </div>
                        {!tiktokSyncResult.success && (
                          <div className="pt-1">
                            <span className="text-purple-400 font-bold">Nội dung phản hồi lỗi:</span>
                            <pre className="mt-1 p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-slate-400 overflow-x-auto text-[10px] max-h-36 whitespace-pre-wrap select-all font-mono">
                              {tiktokSyncResult.body || tiktokSyncResult.error || 'N/A'}
                            </pre>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* TikTok orders table */}
              <div className="space-y-2.5">
                <div className="flex justify-between items-center pb-1 border-b border-dashed border-coquette-deep/15">
                  <h4 className="text-xs font-serif font-bold text-gray-800 flex items-center gap-1">
                    <span>📋 Bảng Đối Soát TikTok Shop</span>
                    <span className="bg-slate-100 text-slate-800 text-[9px] font-mono px-1.5 py-0.5 rounded font-black">Ủy thác RioHub</span>
                  </h4>
                  <span className="text-[9.5px] text-gray-400 font-medium italic">Tự động tính hoàn tiền 60%</span>
                </div>

                {(() => {
                  const isTikTokOrder = (o: Order) => {
                    const idLower = o.orderId.toLowerCase();
                    return idLower.includes('tiktok') || 
                           o.orderId.startsWith('1234') || 
                           (o.productName && o.productName.toLowerCase().includes('tiktok')) ||
                           (o as any).isTikTok ||
                           !o.orderId.match(/^\d+$/);
                  };

                  const list = orders.filter(isTikTokOrder);

                  if (list.length === 0) {
                    return (
                      <div className="text-center py-10 bg-gray-50/50 rounded-2xl border border-dashed border-gray-200">
                        <p className="text-xs text-gray-400">Không tìm thấy đơn hàng TikTok Shop nào trong cơ sở dữ liệu hiện tại.</p>
                        <p className="text-[10px] text-gray-300 mt-1">Bấm nút "Đồng bộ đơn hàng" phía trên để nạp các đơn hàng thử nghiệm nhanh chóng!</p>
                      </div>
                    );
                  }

                  return (
                    <div className="overflow-x-auto border border-coquette-deep/20 rounded-2xl shadow-3xs bg-white text-left">
                      <table className="w-full text-xs text-left border-collapse table-auto">
                        <thead>
                          <tr className="bg-coquette-cream text-gray-700 font-bold border-b border-coquette-deep/30">
                            <th className="py-3 px-4 font-serif">Order ID</th>
                            <th className="py-3 px-3 font-serif">Username</th>
                            <th className="py-3 px-3 font-serif">Sản phẩm</th>
                            <th className="py-3 px-3 text-right font-serif">Hoa hồng gốc</th>
                            <th className="py-3 px-3 text-right font-serif text-coquette-accent">Cashback</th>
                            <th className="py-3 px-3 text-center font-serif">Trạng thái</th>
                            <th className="py-3 px-4 text-right font-serif">Thao tác</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                          {list.map((o) => (
                            <tr key={o.orderId} className="hover:bg-coquette-pink/5 transition-colors">
                              {/* Order ID */}
                              <td className="py-3 px-4 font-mono font-bold text-gray-800 select-all">
                                #{o.orderId}
                              </td>

                              {/* Username */}
                              <td className="py-3 px-3">
                                <span className="bg-coquette-pink/30 text-coquette-accent font-bold px-2.5 py-0.5 rounded-full text-[10px] tracking-wider">
                                  {o.username || 'khach_vo_danh'}
                                </span>
                              </td>

                              {/* Sản phẩm */}
                              <td className="py-3 px-3 max-w-[180px] truncate" title={o.productName}>
                                <span className="text-[11px] text-gray-600 font-sans">
                                  {o.productName || 'Sản phẩm TikTok Shop hoàn tiền'}
                                </span>
                              </td>

                              {/* Hoa hồng gốc */}
                              <td className="py-3 px-3 text-right font-mono text-gray-500 font-bold whitespace-nowrap">
                                {o.rawCommission.toLocaleString('vi-VN')}đ
                              </td>

                              {/* Cashback */}
                              <td className="py-3 px-3 text-right font-black font-mono text-coquette-accent whitespace-nowrap bg-coquette-pink/30">
                                {o.rebateAmount.toLocaleString('vi-VN')}đ
                              </td>

                              {/* Trạng thái */}
                              <td className="py-3 px-3 text-center whitespace-nowrap">
                                {o.status === 'approved' && (
                                  <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                                    🟢 Đã đối soát
                                  </span>
                                )}
                                {(o.status === 'pending_record' || o.status === 'pending_approve') && (
                                  <span className="bg-amber-100 text-amber-800 text-[10px] font-bold px-2 py-0.5 rounded-full animate-pulse">
                                    🟡 Chờ đối soát
                                  </span>
                                )}
                                {o.status === 'cancelled' && (
                                  <span className="bg-rose-100 text-rose-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                                    🔴 Đơn hoàn trả/Hủy
                                  </span>
                                )}
                              </td>

                              {/* Thao tác */}
                              <td className="py-3 px-4 text-right whitespace-nowrap space-x-1.5">
                                <button
                                  onClick={() => handleUpdateDeclStatus(o.orderId, 'approved')}
                                  disabled={o.status === 'approved'}
                                  className={`text-[9.5px] font-black uppercase px-2.5 py-1.5 rounded-lg transition-all cursor-pointer shadow-3xs ${
                                    o.status === 'approved'
                                      ? 'bg-gray-150 text-gray-400 cursor-not-allowed'
                                      : 'btn-admin-duyet hover:scale-105'
                                  }`}
                                  title="Duyệt hoàn tiền cho đơn hàng TikTok này"
                                >
                                  Duyệt ✓
                                </button>
                                <button
                                  onClick={() => handleUpdateDeclStatus(o.orderId, 'cancelled')}
                                  disabled={o.status === 'cancelled'}
                                  className={`text-[9.5px] font-black uppercase px-2.5 py-1.5 rounded-lg transition-all cursor-pointer shadow-3xs ${
                                    o.status === 'cancelled'
                                      ? 'bg-gray-150 text-gray-400 cursor-not-allowed'
                                      : 'btn-admin-khongthay hover:scale-105'
                                  }`}
                                  title="Đơn TikTok bị hoàn chuyển/hủy"
                                >
                                  Hủy ✖
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  );
                })()}
              </div>
            </div>
          )}
        </div>
      )}

      {/* WITHDRAWALS LIST MANAGING SUB VIEW */}
      {subTab === 'withdrawals' && (
        <div className="bg-white rounded-3xl p-5 border border-coquette-deep/40 shadow-xs space-y-4 animate-in fade-in duration-200">
          <div className="pb-2 border-b border-dashed border-coquette-deep/30">
            <h3 className="font-serif text-sm font-bold text-gray-800 flex items-center gap-1.5">
              <span>Xét Duyệt Rút Tiền Ví Chi Trả</span>
              <span className="text-coquette-accent">💸</span>
            </h3>
            <p className="text-[10px] text-gray-400">Danh sách đề xuất rút tiền nội bộ đang chờ Admin xử lý và giải ngân chuyển khoản.</p>
          </div>

          {withdraws.length === 0 ? (
            <p className="text-xs text-center py-8 text-gray-400">Hiện không có giao dịch rút tiền nào phát sinh.</p>
          ) : (
            <div className="divide-y divide-gray-100 max-h-80 overflow-y-auto pr-1 space-y-1.5">
              {withdraws.map((w) => (
                <div key={w.id} className="py-3 text-xs space-y-2 hover:bg-gray-50/50 p-1.5 rounded-xl transition-all">
                  <div className="flex justify-between items-start">
                    <div className="space-y-0.5">
                      <p className="font-bold text-gray-800">@{w.username} đề xuất rút:</p>
                      <span className="text-lg font-black text-coquette-accent font-sans">{w.amount.toLocaleString('vi-VN')}đ</span>
                    </div>

                    <span className={`inline-block px-2 py-0.5 rounded text-[9px] font-bold ${
                      w.status === 'completed'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : w.status === 'rejected'
                        ? 'bg-rose-50 text-rose-700 border border-rose-200'
                        : 'bg-amber-50 text-amber-700 border border-amber-200 animate-pulse'
                    }`}>
                      {w.status === 'completed' ? 'Đã chi tiền' : w.status === 'rejected' ? 'Bị từ chối' : 'Đang Đợi Duyệt'}
                    </span>
                  </div>

                  {/* Bank info details */}
                  <div className="bg-coquette-cream/50 p-2.5 rounded-lg border border-coquette-deep/20 font-mono text-[10px] text-gray-500 leading-relaxed">
                    <p>ATM: <strong className="font-bold text-gray-700">{w.bankName}</strong></p>
                    <p>Số tài khoản: <strong className="font-bold text-gray-700">{w.accountNumber}</strong></p>
                    <p>Mã chủ thẻ: <strong className="font-bold text-gray-700 uppercase">{w.accountHolder}</strong></p>
                    <p className="text-[9px] text-gray-350">Khởi tạo lúc: {new Date(w.createdAt).toLocaleDateString('vi-VN')} {new Date(w.createdAt).toLocaleTimeString('vi-VN', {hour: '2-digit', minute:'2-digit'})}</p>
                  </div>

                  {/* Conditional Actions for process */}
                  {w.status === 'pending' && (
                    <div className="flex gap-2 justify-end">
                      <button
                        onClick={() => handleProcessWithdraw(w.id, 'rejected')}
                        className="bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-[10px] px-3.5 py-1.5 rounded-lg border border-rose-200 transition-all cursor-pointer"
                      >
                        Từ Chối
                      </button>
                      <button
                        onClick={() => handleProcessWithdraw(w.id, 'completed')}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] px-3.5 py-1.5 rounded-lg transition-all cursor-pointer shadow-3xs"
                      >
                        Xác Nhận Đã Chuyển Tiền ✓
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* CONFIGS SYSTEM SUB VIEW */}
      {subTab === 'config' && (
        <div className="bg-white rounded-3xl p-5 border border-coquette-deep/40 shadow-xs space-y-4 animate-in fade-in duration-200">
          <div className="pb-2 border-b border-dashed border-coquette-deep/30">
            <h3 className="font-serif text-sm font-bold text-gray-800 flex items-center gap-1.5">
              <Settings className="w-4 h-4 text-coquette-accent" />
              <span>Cấu Hình Tham Số Shopee Affiliate</span>
            </h3>
            <p className="text-[10px] text-gray-400">Tham số cấu hình để sinh link tracking riêng định hướng cho s.shopee.vn rút gọn.</p>
          </div>

          <form onSubmit={handleConfigSubmit} className="space-y-4">
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-gray-700">Affiliate ID mặc định (Shopee Partner)</label>
              <input
                type="text"
                required
                value={config.affiliateId}
                onChange={(e) => setConfig({ ...config, affiliateId: e.target.value })}
                className="w-full text-xs px-3.5 py-2.5 bg-coquette-cream/30 border border-coquette-deep/40 rounded-xl font-mono text-gray-700"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-bold text-gray-700">Sub ID trung gian cơ cấu</label>
              <input
                type="text"
                required
                value={config.subId}
                onChange={(e) => setConfig({ ...config, subId: e.target.value })}
                className="w-full text-xs px-3.5 py-2.5 bg-coquette-cream/30 border border-coquette-deep/40 rounded-xl font-mono text-gray-700"
              />
            </div>

            <div className="space-y-2 bg-pink-50/25 p-4 rounded-2xl border border-coquette-deep/30">
              <span className="text-coquette-primary font-bold block text-xs">⚙️ Tỷ Lệ Hoàn Tiền (Shopee & TikTok Shop)</span>
              <p className="text-[10px] text-gray-500 leading-relaxed">Hoàn tiền lên tới 60% hoa hồng affiliate từ Shopee và TikTok Shop. Thay đổi này tự động áp dụng khi có đơn đồng bộ tự động hoặc tự khai báo mới.</p>

              <div className="space-y-1 mt-2">
                <label className="text-[11px] font-bold text-gray-700 block">Tỷ lệ chia sẻ tiền hoàn lại cho Khách (%)</label>
                <select
                  value={config.rebatePercent}
                  onChange={(e) => setConfig({ ...config, rebatePercent: parseInt(e.target.value, 10) })}
                  className="w-full text-xs px-3.5 py-2.5 bg-white border border-[#FFA6B7] rounded-xl text-gray-700 font-bold outline-hidden"
                >
                  <option value="30">30% (Hệ thống giữ 70% - Khách nhận 30%)</option>
                  <option value="40">40% (Hệ thống giữ 60% - Khách nhận 40%)</option>
                  <option value="50">50% (Hệ thống chia đều 50% - 50%)</option>
                  <option value="60">60% (Ưu tiên: Hệ thống giữ 40% - Khách nhận 60%)</option>
                  <option value="70">70% (Hệ thống giữ 30% - Khách nhận 70%)</option>
                </select>
              </div>

              <div className="space-y-2 pt-2 border-t border-dashed border-[#FFA6B7]/35">
                <label className="text-[10px] font-bold text-gray-500 uppercase block">Hộp lựa chọn & Đối tác được kích hoạt:</label>
                <div className="flex gap-4 text-[11px] text-gray-700 font-bold">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input type="checkbox" defaultChecked disabled className="accent-rose-500" />
                    <span>🛍️ Shopee Affiliate</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input type="checkbox" defaultChecked disabled className="accent-rose-500" />
                    <span>🎵 TikTok Shop Affiliate</span>
                  </label>
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-coquette-accent hover:bg-coquette-accent/90 text-white font-bold text-xs py-2.5 rounded-xl transition-all cursor-pointer shadow-sm text-center"
            >
              Lưu Cấu Hình Mặc Định 🔐
            </button>
          </form>
        </div>
      )}

      {/* ITEMS AND DISCUSSIONS REVIEW TAB */}
      {subTab === 'items' && (
        <div className="space-y-4 animate-in fade-in duration-200">
          
          {/* Create new Voucher Form */}
          <div className="bg-white rounded-3xl p-5 border border-coquette-deep/40 shadow-xs space-y-3.5">
            <h3 className="font-serif text-sm font-bold text-gray-800 flex items-center gap-1.5 pb-2 border-b border-dashed border-coquette-deep/30">
              <Tag className="w-4 h-4 text-coquette-accent" />
              <span>Phát Hành Voucher Đổi Quà Mới</span>
            </h3>

            <form onSubmit={handleAddNewVoucher} className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-gray-600 block">Tên voucher:</span>
                  <input
                    type="text"
                    required
                    placeholder="VD: Voucher Shopee 100K"
                    value={vouchTitle}
                    onChange={(e) => setVouchTitle(e.target.value)}
                    className="w-full text-xs px-2.5 py-1.5 bg-coquette-cream/30 border border-coquette-deep/40 rounded-lg"
                  />
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-gray-600 block">Số điểm đổi (VNĐ):</span>
                  <input
                    type="number"
                    required
                    placeholder="VD: 100000"
                    value={vouchCost}
                    onChange={(e) => setVouchCost(e.target.value)}
                    className="w-full text-xs px-2.5 py-1.5 bg-coquette-cream/30 border border-coquette-deep/40 rounded-lg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-gray-600 block">Giá trị giảm giá (VNĐ):</span>
                  <input
                    type="number"
                    required
                    placeholder="VD: 100000"
                    value={vouchValue}
                    onChange={(e) => setVouchValue(e.target.value)}
                    className="w-full text-xs px-2.5 py-1.5 bg-coquette-cream/30 border border-coquette-deep/40 rounded-lg"
                  />
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-gray-600 block">Ngày hết hạn:</span>
                  <input
                    type="date"
                    required
                    value={vouchExpiry}
                    onChange={(e) => setVouchExpiry(e.target.value)}
                    className="w-full text-xs px-2.5 py-1.5 bg-coquette-cream/30 border border-coquette-deep/40 rounded-lg text-gray-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-coquette-accent hover:bg-coquette-accent/90 text-white font-bold text-[10.5px] py-2 rounded-lg cursor-pointer"
              >
                Kích Hoạt Mã Giftcode Mới 🎫
              </button>
            </form>
          </div>

          {/* Delete comments feed logs */}
          <div className="bg-white rounded-3xl p-5 border border-coquette-deep/40 shadow-xs space-y-3">
            <h3 className="font-serif text-sm font-bold text-gray-800 flex items-center gap-1.5 pb-2 border-b border-dashed border-coquette-deep/30">
              <MessageSquare className="w-4 h-4 text-coquette-accent" />
              <span>Kiểm Duyệt Thảo Luận Bảng Tin ({comments.length})</span>
            </h3>

            <div className="divide-y divide-gray-100 max-h-56 overflow-y-auto pr-1 space-y-1.5">
              {comments.map((c) => (
                <div key={c.id} className="py-2 text-xs flex justify-between items-start gap-2">
                  <div className="space-y-0.5">
                    <span className="font-bold text-gray-700">@{c.username}:</span>
                    <p className="text-[11px] text-gray-500 line-clamp-2">{c.content}</p>
                  </div>
                  <button
                    onClick={() => handleDeleteComment(c.id)}
                    className="bg-red-50 hover:bg-red-100 text-red-700 text-[10px] font-bold px-2 py-1 rounded-sm shrink-0 border border-red-200 cursor-pointer"
                  >
                    Xóa tin
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SUPPORT TICKETS REPYING VIEW FOR ADMIN */}
      {subTab === 'tickets' && (
        <div className="bg-white rounded-3xl p-5 border border-coquette-deep/40 shadow-xs space-y-4 animate-in fade-in duration-200 text-xs">
          <div className="pb-2 border-b border-dashed border-coquette-deep/30">
            <h3 className="font-serif text-sm font-bold text-gray-800 flex items-center gap-1.5">
              <span>Hộp Thư Phản Hồi Ticket Yêu Cầu ({allTickets.length})</span>
              <span className="text-coquette-accent">💬</span>
            </h3>
            <p className="text-[10px] text-gray-400">Danh sách các câu hỏi, thắc mắc, phản hồi hoặc đơn tra soát mất đơn từ tất cả khách hàng gửi lên hệ thống.</p>
          </div>

          {/* Filters controls */}
          <div className="flex gap-2">
            <div className="flex-1 space-y-0.5">
              <label className="text-[9px] font-bold text-gray-400 uppercase">Phân loại:</label>
              <select
                value={ticketFilterCategory}
                onChange={(e) => setTicketFilterCategory(e.target.value)}
                className="w-full text-[10px] px-2 py-1 bg-coquette-cream rounded-md border border-coquette-deep/20 text-gray-700"
              >
                <option value="all">Tất cả Phân Loại</option>
                <option value="lost_order">🔎 Tra soát Mất đơn</option>
                <option value="withdraw">💸 Thừa/Thiếu rút tiền</option>
                <option value="other">💬 Ý kiến đóng góp khác</option>
              </select>
            </div>

            <div className="flex-1 space-y-0.5">
              <label className="text-[9px] font-bold text-gray-400 uppercase">Trạng thái:</label>
              <select
                value={ticketFilterStatus}
                onChange={(e) => setTicketFilterStatus(e.target.value)}
                className="w-full text-[10px] px-2 py-1 bg-coquette-cream rounded-md border border-coquette-deep/20 text-gray-700"
              >
                <option value="all">Tất cả Trạng Thái</option>
                <option value="pending">⏳ Đang Chờ Trả Lời</option>
                <option value="replied">✅ Đã Phản Hồi</option>
                <option value="closed">🔒 Đã Đóng Lịch Sử</option>
              </select>
            </div>

            <div className="flex-1 space-y-0.5">
              <label className="text-[9px] font-bold text-gray-400 uppercase">Nền tảng:</label>
              <select
                value={ticketFilterPlatform}
                onChange={(e) => setTicketFilterPlatform(e.target.value)}
                className="w-full text-[10px] px-2 py-1 bg-coquette-cream rounded-md border border-coquette-deep/20 text-gray-700 font-bold"
              >
                <option value="all">Tất cả Nền tảng</option>
                <option value="shopee">🛍️ Shopee Affiliate</option>
                <option value="tiktok">🎵 TikTok Shop</option>
              </select>
            </div>
          </div>

          {allTickets.filter(tk => {
            const matchesCat = ticketFilterCategory === 'all' || tk.category === ticketFilterCategory;
            const matchesSt = ticketFilterStatus === 'all' || tk.status === ticketFilterStatus;
            const matchesPlatform = ticketFilterPlatform === 'all' || 
              (tk.platform === ticketFilterPlatform) ||
              (!tk.platform && ticketFilterPlatform === 'shopee');
            return matchesCat && matchesSt && matchesPlatform;
          }).length === 0 ? (
            <p className="text-xs text-center py-8 text-gray-400 border border-dashed border-coquette-deep/20 rounded-2xl bg-gray-50/50">Không tìm thấy yêu cầu hỗ trợ nào phù hợp bộ lọc.</p>
          ) : (
            <div className="space-y-4 max-h-[480px] overflow-y-auto pr-1">
              {allTickets
                .filter(tk => {
                  const matchesCat = ticketFilterCategory === 'all' || tk.category === ticketFilterCategory;
                  const matchesSt = ticketFilterStatus === 'all' || tk.status === ticketFilterStatus;
                  const matchesPlatform = ticketFilterPlatform === 'all' || 
                    (tk.platform === ticketFilterPlatform) ||
                    (!tk.platform && ticketFilterPlatform === 'shopee');
                  return matchesCat && matchesSt && matchesPlatform;
                })
                .map((tk) => (
                  <div key={tk.id} className="p-4 bg-coquette-cream/25 rounded-2xl border border-coquette-deep/20 space-y-2.5">
                    <div className="flex justify-between items-start">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[10px] text-coquette-accent font-mono font-bold">#{tk.id}</span>
                          <span className="text-[10px] text-gray-400">gửi bởi: <strong className="text-gray-700">@{tk.username}</strong></span>
                          <span className="bg-rose-50 text-[10px] text-coquette-primary font-bold px-1.5 py-0.5 rounded-md border border-coquette-deep/50 uppercase">
                            {tk.platform === 'tiktok' ? '🎵 TikTok Shop' : '🛍️ Shopee'}
                          </span>
                        </div>
                        <h4 className="font-bold text-gray-800 text-[11.5px]">{tk.title}</h4>
                      </div>

                      <span className={`px-2 py-0.5 rounded text-[8.5px] font-bold ${
                        tk.status === 'replied'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : tk.status === 'closed'
                          ? 'bg-gray-100 text-gray-400 border border-gray-200'
                          : 'bg-amber-50 text-amber-700 border border-amber-200 animate-pulse'
                      }`}>
                        {tk.status === 'replied' ? 'Đã phản hồi' : tk.status === 'closed' ? 'Đã đóng' : 'Chờ xử lý'}
                      </span>
                    </div>

                    <div className="bg-white p-3 rounded-xl border border-gray-100 text-[11px] text-gray-600 whitespace-pre-line leading-relaxed">
                      {tk.content}
                    </div>

                    {tk.adminReply && (
                      <div className="bg-emerald-50/30 p-3 rounded-xl border border-emerald-100/80 space-y-1">
                        <span className="text-[10px] font-bold text-emerald-700">💝 Phản hồi của Thụy Vy Admin:</span>
                        <p className="text-[11px] text-gray-750 font-medium whitespace-pre-line leading-relaxed">{tk.adminReply}</p>
                        {tk.processedAt && (
                          <p className="text-[8.5px] text-gray-350 text-right">Lúc: {new Date(tk.processedAt).toLocaleString('vi-VN')}</p>
                        )}
                      </div>
                    )}

                    {tk.status === 'pending' && (
                      <div className="space-y-1.5 pt-1">
                        <label className="text-[10px] font-bold text-emerald-800">✍️ Nhập câu trả lời phản hồi cho khách:</label>
                        <textarea
                          rows={2}
                          value={ticketReplyText[tk.id] || ''}
                          onChange={(e) => setTicketReplyText(prev => ({ ...prev, [tk.id]: e.target.value }))}
                          placeholder="Viết hướng dẫn hoặc thông điệp phản hồi cụ thể cho khách..."
                          className="w-full text-[11px] p-2 bg-white border border-coquette-deep/30 rounded-xl"
                        />
                        <div className="flex gap-2 justify-end">
                          <button
                            onClick={() => {
                              // Đóng Ticket luôn không cần giải trình nhiều
                              const tks = getSupportTickets();
                              const tkIdx = tks.findIndex(t => t.id === tk.id);
                              if (tkIdx >= 0) {
                                tks[tkIdx].status = 'closed';
                                saveSupportTickets(tks);
                                setAllTickets(getSupportTickets());
                              }
                            }}
                            className="bg-gray-50 hover:bg-gray-100 text-gray-500 font-bold px-3 py-1.5 rounded-lg border border-gray-200 transition-all cursor-pointer"
                          >
                            Đóng Ticket 🔒
                          </button>
                          
                          <button
                            onClick={() => {
                              const text = ticketReplyText[tk.id];
                              if (!text || !text.trim()) {
                                alert('⚠️ Vui lòng nhập nội dung phản hồi.');
                                return;
                              }

                              const tks = getSupportTickets();
                              const tkIdx = tks.findIndex(t => t.id === tk.id);
                              if (tkIdx >= 0) {
                                tks[tkIdx].adminReply = text.trim();
                                tks[tkIdx].status = 'replied';
                                tks[tkIdx].processedAt = new Date().toISOString();

                                saveSupportTickets(tks);

                                // Gửi thông báo nội bộ
                                const dbNotifications = getInternalNotifications();
                                dbNotifications.unshift({
                                  id: 'nt_reply_' + Date.now(),
                                  username: tks[tkIdx].username,
                                  title: 'Bạn có phản hồi hỗ trợ mới! 💝',
                                  content: `Đại diện Admin Thụy Vy đã phản hồi yêu cầu hỗ trợ #${tk.id} của bạn. Vui lòng bấm Hộp Hỗ trợ để xem chi tiết.`,
                                  isRead: false,
                                  createdAt: new Date().toISOString()
                                });
                                saveInternalNotifications(dbNotifications);

                                // Clear reply text
                                setTicketReplyText(prev => ({ ...prev, [tk.id]: '' }));
                                setAllTickets(getSupportTickets());
                                alert('🎉 Gửi phản hồi Ticket thành công! Bạn đã thông báo cho khách hàng thành công.');
                              }
                            }}
                            className="bg-coquette-accent hover:bg-coquette-accent/90 text-white font-bold px-4 py-1.5 rounded-lg transition-all cursor-pointer"
                          >
                            Gửi Trả Lời 💝
                          </button>
                        </div>
                      </div>
                    )}

                    <div className="text-[9px] text-gray-350 flex justify-between items-center text-right pt-1">
                      <span>Loại: {tk.category === 'lost_order' ? '🔎 Tra soát đơn' : tk.category === 'withdraw' ? '💸 Ví rút' : '💬 Phản hồi'}</span>
                      <span>Ngày tạo: {new Date(tk.createdAt).toLocaleDateString('vi-VN')}</span>
                    </div>

                  </div>
                ))}
            </div>
          )}

        </div>
      )}

      {/* CONTENT MANAGEMENT SYSTEM (CMS) SUB VIEW */}
      {subTab === 'content' && (
        <div className="bg-white rounded-3xl p-5 border border-coquette-deep/40 shadow-xs space-y-5 animate-in fade-in duration-200 text-xs text-left">
          <div className="pb-2 border-b border-dashed border-coquette-deep/30">
            <h3 className="font-serif text-sm font-bold text-gray-800 flex items-center gap-1.5">
              <span>Hệ Thống Quản Lý Nội Dung Toàn Diện</span>
              <span className="text-coquette-accent">🌸</span>
            </h3>
            <p className="text-[10.5px] text-gray-400">Tự do chỉnh sửa mọi từ ngữ, thông báo, quy định và ẩn hiện trang hướng dẫn mà không cần sửa code.</p>
          </div>

          <form onSubmit={(e) => {
            e.preventDefault();
            saveWebContent(webContent);
            alert('🎉 Đã cập nhật thành công toàn bộ Nội dung Website! Mọi trang và banner đã đồng bộ hoá ngay lập tức 💝');
            onRefreshData();
          }} className="space-y-5 text-left">
            
            {/* Banner Section */}
            <div className="space-y-3 bg-coquette-cream/30 p-4 rounded-2xl border border-coquette-deep/20 text-left">
              <span className="font-serif font-bold text-gray-750 block text-[12px] pb-1 border-b border-coquette-deep/15">🎀 Banner Trang Chủ</span>
              
              <div className="space-y-2">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-600 block">Dòng Nhãn Highlight Nhỏ:</label>
                  <input
                    type="text"
                    value={webContent.bannerSub}
                    onChange={(e) => setWebContentLocal({ ...webContent, bannerSub: e.target.value })}
                    className="w-full text-xs px-2.5 py-2 bg-white border border-coquette-deep/30 rounded-xl"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-600 block">Mục Tiêu Đề Chính Banner:</label>
                  <input
                    type="text"
                    value={webContent.bannerTitle}
                    onChange={(e) => setWebContentLocal({ ...webContent, bannerTitle: e.target.value })}
                    className="w-full text-xs px-2.5 py-2 bg-white border border-coquette-deep/30 rounded-xl font-bold text-gray-850"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-600 block">Đoạn Mô Tả Chi Tiết Banner:</label>
                  <textarea
                    rows={2}
                    value={webContent.bannerDesc}
                    onChange={(e) => setWebContentLocal({ ...webContent, bannerDesc: e.target.value })}
                    className="w-full text-xs p-2.5 bg-white border border-coquette-deep/30 rounded-xl"
                  />
                </div>
              </div>
            </div>

            {/* Popup Announcement Section */}
            <div className="space-y-3 bg-coquette-cream/30 p-4 rounded-2xl border border-coquette-deep/20 text-left">
              <div className="flex justify-between items-center pb-1 border-b border-coquette-deep/15">
                <span className="font-serif font-bold text-gray-750 block text-[12px]">📢 Popup Thông Báo Trang Chủ</span>
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={webContent.showPopup}
                    onChange={(e) => setWebContentLocal({ ...webContent, showPopup: e.target.checked })}
                    className="w-3.5 h-3.5 accent-coquette-accent"
                  />
                  <span className="text-[10px] font-bold text-coquette-accent">Kích hoạt Popup</span>
                </label>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-600 block">Nội dung thông báo (Hiển thị ngay khi vào trang):</label>
                <textarea
                  rows={3}
                  value={webContent.popupContent}
                  onChange={(e) => setWebContentLocal({ ...webContent, popupContent: e.target.value })}
                  className="w-full text-xs p-2.5 bg-white border border-coquette-deep/30 rounded-xl leading-relaxed whitespace-pre-wrap"
                />
              </div>
            </div>

            {/* Steps Tutorial Guide Customizer */}
            <div className="space-y-3 bg-coquette-cream/30 p-4 rounded-2xl border border-coquette-deep/20 text-left">
              <span className="font-serif font-bold text-gray-750 block text-[12px] pb-1 border-b border-coquette-deep/15">💁‍♀️ Quy Trình 4 Bước Sử Dụng</span>
              
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-2 text-left">
                  <div className="bg-white p-2.5 rounded-xl border border-coquette-deep/25 space-y-1.5">
                    <span className="text-[10px] font-bold text-coquette-accent block">Bước 1: Tiêu đề</span>
                    <input
                      type="text"
                      value={webContent.step1_title}
                      onChange={(e) => setWebContentLocal({ ...webContent, step1_title: e.target.value })}
                      className="w-full text-[10.5px] px-2 py-1 bg-gray-50 border border-gray-200 rounded-lg"
                    />
                    <span className="text-[9px] text-gray-400 block pt-0.5">Mô tả:</span>
                    <textarea
                      rows={2}
                      value={webContent.step1_desc}
                      onChange={(e) => setWebContentLocal({ ...webContent, step1_desc: e.target.value })}
                      className="w-full text-[10px] p-1.5 bg-gray-50 border border-gray-200 rounded-lg"
                    />
                  </div>

                  <div className="bg-white p-2.5 rounded-xl border border-coquette-deep/25 space-y-1.5">
                    <span className="text-[10px] font-bold text-coquette-accent block">Bước 2: Tiêu đề</span>
                    <input
                      type="text"
                      value={webContent.step2_title}
                      onChange={(e) => setWebContentLocal({ ...webContent, step2_title: e.target.value })}
                      className="w-full text-[10.5px] px-2 py-1 bg-gray-50 border border-gray-200 rounded-lg"
                    />
                    <span className="text-[9px] text-gray-400 block pt-0.5">Mô tả:</span>
                    <textarea
                      rows={2}
                      value={webContent.step2_desc}
                      onChange={(e) => setWebContentLocal({ ...webContent, step2_desc: e.target.value })}
                      className="w-full text-[10px] p-1.5 bg-gray-50 border border-gray-200 rounded-lg"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-left">
                  <div className="bg-white p-2.5 rounded-xl border border-coquette-deep/25 space-y-1.5">
                    <span className="text-[10px] font-bold text-coquette-accent block">Bước 3: Tiêu đề</span>
                    <input
                      type="text"
                      value={webContent.step3_title}
                      onChange={(e) => setWebContentLocal({ ...webContent, step3_title: e.target.value })}
                      className="w-full text-[10.5px] px-2 py-1 bg-gray-50 border border-gray-200 rounded-lg"
                    />
                    <span className="text-[9px] text-gray-400 block pt-0.5">Mô tả:</span>
                    <textarea
                      rows={2}
                      value={webContent.step3_desc}
                      onChange={(e) => setWebContentLocal({ ...webContent, step3_desc: e.target.value })}
                      className="w-full text-[10px] p-1.5 bg-gray-50 border border-gray-200 rounded-lg"
                    />
                  </div>

                  <div className="bg-white p-2.5 rounded-xl border border-coquette-deep/25 space-y-1.5">
                    <span className="text-[10px] font-bold text-coquette-accent block">Bước 4: Tiêu đề</span>
                    <input
                      type="text"
                      value={webContent.step4_title}
                      onChange={(e) => setWebContentLocal({ ...webContent, step4_title: e.target.value })}
                      className="w-full text-[10.5px] px-2 py-1 bg-gray-50 border border-gray-200 rounded-lg"
                    />
                    <span className="text-[9px] text-gray-400 block pt-0.5">Mô tả:</span>
                    <textarea
                      rows={2}
                      value={webContent.step4_desc}
                      onChange={(e) => setWebContentLocal({ ...webContent, step4_desc: e.target.value })}
                      className="w-full text-[10px] p-1.5 bg-gray-50 border border-gray-200 rounded-lg"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Information tabs */}
            <div className="space-y-4 bg-coquette-cream/30 p-4 rounded-2xl border border-coquette-deep/20 text-left">
              <span className="font-serif font-bold text-gray-750 block text-[12px] pb-1 border-b border-coquette-deep/15">📋 3 Tab Thông Tin Hướng Dẫn Quy Định</span>
              
              <div className="space-y-3">
                {/* Tab 1 */}
                <div className="space-y-1.5 bg-white p-3 rounded-xl border border-gray-150">
                  <div className="flex gap-2">
                    <span className="text-[10px] font-bold text-gray-600 block shrink-0 pt-1">Tab 1:</span>
                    <input
                      type="text"
                      value={webContent.tabCorrectTitle}
                      onChange={(e) => setWebContentLocal({ ...webContent, tabCorrectTitle: e.target.value })}
                      className="w-full text-xs font-bold px-2 py-1 bg-gray-50 border border-gray-200 rounded-lg"
                    />
                  </div>
                  <textarea
                    rows={3}
                    value={webContent.tabCorrectContent}
                    onChange={(e) => setWebContentLocal({ ...webContent, tabCorrectContent: e.target.value })}
                    className="w-full text-[11px] p-2 bg-gray-50 border border-gray-200 rounded-lg font-mono leading-relaxed"
                  />
                </div>

                {/* Tab 2 */}
                <div className="space-y-1.5 bg-white p-3 rounded-xl border border-gray-150">
                  <div className="flex gap-2">
                    <span className="text-[10px] font-bold text-gray-600 block shrink-0 pt-1">Tab 2:</span>
                    <input
                      type="text"
                      value={webContent.tabPolicyTitle}
                      onChange={(e) => setWebContentLocal({ ...webContent, tabPolicyTitle: e.target.value })}
                      className="w-full text-xs font-bold px-2 py-1 bg-gray-50 border border-gray-200 rounded-lg"
                    />
                  </div>
                  <textarea
                    rows={3}
                    value={webContent.tabPolicyContent}
                    onChange={(e) => setWebContentLocal({ ...webContent, tabPolicyContent: e.target.value })}
                    className="w-full text-[11px] p-2 bg-gray-50 border border-gray-200 rounded-lg font-mono leading-relaxed"
                  />
                </div>

                {/* Tab 3 */}
                <div className="space-y-1.5 bg-white p-3 rounded-xl border border-gray-150">
                  <div className="flex gap-2">
                    <span className="text-[10px] font-bold text-gray-600 block shrink-0 pt-1">Tab 3:</span>
                    <input
                      type="text"
                      value={webContent.tabTipsTitle}
                      onChange={(e) => setWebContentLocal({ ...webContent, tabTipsTitle: e.target.value })}
                      className="w-full text-xs font-bold px-2 py-1 bg-gray-50 border border-gray-200 rounded-lg"
                    />
                  </div>
                  <textarea
                    rows={3}
                    value={webContent.tabTipsContent}
                    onChange={(e) => setWebContentLocal({ ...webContent, tabTipsContent: e.target.value })}
                    className="w-full text-[11px] p-2 bg-gray-50 border border-gray-200 rounded-lg font-mono leading-relaxed"
                  />
                </div>
              </div>
            </div>

            {/* Custom Footer */}
            <div className="space-y-3 bg-coquette-cream/30 p-4 rounded-2xl border border-coquette-deep/20 text-left">
              <span className="font-serif font-bold text-gray-750 block text-[12px] pb-1 border-b border-coquette-deep/15">🎀 Chân Trang (Footer)</span>
              
              <div className="space-y-2">
                <div className="grid grid-cols-2 gap-2 text-left">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-600 block">Tên hiển thị thương hiệu:</label>
                    <input
                      type="text"
                      value={webContent.footerName}
                      onChange={(e) => setWebContentLocal({ ...webContent, footerName: e.target.value })}
                      className="w-full text-xs px-2.5 py-1.5 bg-white border border-coquette-deep/30 rounded-xl"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-600 block">Liên kết mạng xã hội (Instagram/FB):</label>
                    <input
                      type="text"
                      value={webContent.footerSocialLink}
                      onChange={(e) => setWebContentLocal({ ...webContent, footerSocialLink: e.target.value })}
                      className="w-full text-[10.5px] px-2.5 py-1.5 bg-white border border-coquette-deep/30 rounded-xl font-mono text-gray-500"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-600 block">Mô tả ngắn thương hiệu chân trang:</label>
                  <textarea
                    rows={2}
                    value={webContent.footerDesc}
                    onChange={(e) => setWebContentLocal({ ...webContent, footerDesc: e.target.value })}
                    className="w-full text-xs p-2.5 bg-white border border-coquette-deep/30 rounded-xl"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2 text-left">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-600 block">Ghi chú liên hệ support:</label>
                    <input
                      type="text"
                      value={webContent.footerContact}
                      onChange={(e) => setWebContentLocal({ ...webContent, footerContact: e.target.value })}
                      className="w-full text-xs px-2.5 py-1.5 bg-white border border-coquette-deep/30 rounded-xl"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-600 block">Copyright:</label>
                    <input
                      type="text"
                      value={webContent.footerCopyright}
                      onChange={(e) => setWebContentLocal({ ...webContent, footerCopyright: e.target.value })}
                      className="w-full text-xs px-2.5 py-1.5 bg-white border border-coquette-deep/30 rounded-xl"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Subpages Visibility toggles */}
            <div className="space-y-3 bg-coquette-cream/30 p-4 rounded-2xl border border-coquette-deep/20 text-left">
              <span className="font-serif font-bold text-gray-750 block text-[12px] pb-1 border-b border-coquette-deep/15">🔗 Ẩn/Hiện & Soạn Thảo Các Bộ Trang Thông Tin Trợ Giúp</span>
              
              <div className="bg-white p-3 rounded-xl border border-gray-150 space-y-3">
                <div className="flex gap-4 border-b border-gray-100 pb-2">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={webContent.showHelp}
                      onChange={(e) => setWebContentLocal({ ...webContent, showHelp: e.target.checked })}
                      className="w-3.5 h-3.5 accent-coquette-accent"
                    />
                    <span className="text-[11px] font-bold text-gray-700">Hiện "Trợ Giúp"</span>
                  </label>

                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={webContent.showPrivacy}
                      onChange={(e) => setWebContentLocal({ ...webContent, showPrivacy: e.target.checked })}
                      className="w-3.5 h-3.5 accent-coquette-accent"
                    />
                    <span className="text-[11px] font-bold text-gray-700">Hiện "Bảo Mật"</span>
                  </label>

                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={webContent.showTerms}
                      onChange={(e) => setWebContentLocal({ ...webContent, showTerms: e.target.checked })}
                      className="w-3.5 h-3.5 accent-coquette-accent"
                    />
                    <span className="text-[11px] font-bold text-gray-700">Hiện "Điều Khoản"</span>
                  </label>
                </div>

                <div className="space-y-3.5 text-xs text-left">
                  {/* Help Content */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-600 block">Nội dung Soạn Thảo Trang TRỢ GIÚP:</label>
                    <textarea
                      rows={5}
                      value={webContent.helpContent}
                      onChange={(e) => setWebContentLocal({ ...webContent, helpContent: e.target.value })}
                      className="w-full text-[10.5px] p-2.5 bg-gray-50 border border-gray-200 rounded-xl font-mono leading-relaxed"
                    />
                  </div>

                  {/* Privacy Content */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-600 block">Nội dung Soạn Thảo TRANG CHÍNH SÁCH BẢO MẬT:</label>
                    <textarea
                      rows={5}
                      value={webContent.privacyContent}
                      onChange={(e) => setWebContentLocal({ ...webContent, privacyContent: e.target.value })}
                      className="w-full text-[10.5px] p-2.5 bg-gray-50 border border-gray-200 rounded-xl font-mono leading-relaxed"
                    />
                  </div>

                  {/* Terms Content */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-600 block">Nội dung Soạn Thảo TRANG ĐIỀU KHOẢN SỬ DỤNG:</label>
                    <textarea
                      rows={5}
                      value={webContent.termsContent}
                      onChange={(e) => setWebContentLocal({ ...webContent, termsContent: e.target.value })}
                      className="w-full text-[10.5px] p-2.5 bg-gray-50 border border-gray-200 rounded-xl font-mono leading-relaxed"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Save Buttons */}
            <div className="sticky bottom-0 bg-white py-3 border-t border-dashed border-coquette-deep/40 z-10 flex gap-2">
              <button
                type="button"
                onClick={() => {
                  if (confirm('Bạn có đồng ý khôi phục nội dung về mặc định không?')) {
                    localStorage.removeItem('mhx_web_content');
                    setWebContentLocal(getWebContent());
                    alert('Khôi phục nội dung gốc tối giản thành công! Khởi động lại phiên làm việc ngay 🎀');
                    onRefreshData();
                  }
                }}
                className="flex-1 bg-gray-50 hover:bg-gray-100 text-gray-500 font-bold py-3 rounded-2xl cursor-pointer text-center text-xs border border-gray-200 transition-all active:scale-98"
              >
                Khôi phục Gốc 🎀
              </button>

              <button
                type="submit"
                className="flex-[2] bg-coquette-accent hover:bg-coquette-accent/90 text-white font-bold py-3 rounded-2xl cursor-pointer text-center text-xs transition-all active:scale-98 shadow-sm flex items-center justify-center gap-2"
              >
                <Edit3 className="w-4 h-4" />
                <span>Cập Nhật Website Mê Hoàn Xu 🎀</span>
              </button>
            </div>

          </form>
        </div>
      )}

      {/* TIKTOK SHOP MANAGEMENT SUB VIEW */}
      {subTab === 'tiktok_shop' && (
        <div className="animate-in fade-in duration-200 text-left">
          <TikTokView 
            currentUser={currentUser}
            onOpenAuthModal={() => {}}
          />
        </div>
      )}

      {/* ORDER DECLARATIONS SUB VIEW */}
      {subTab === 'declarations' && (
        <div className="space-y-4 animate-in fade-in duration-200 text-left">
          
          {/* Header Indicators */}
          <div className="bg-white rounded-3xl p-5 border border-coquette-deep/40 shadow-xs space-y-4">
            <h3 className="font-serif text-sm font-bold text-gray-800 flex items-center gap-1.5 pb-2 border-b border-dashed border-coquette-deep/30">
              <Database className="w-4 h-4 text-coquette-accent" />
              <span>Đối Soát Đơn Hàng Tự Khai Báo</span>
            </h3>

            {/* Grid metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="bg-rose-50/50 p-4 rounded-2xl border border-rose-100 flex flex-col justify-center">
                <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Tổng đơn</span>
                <span className="text-xl font-bold text-gray-800 font-mono mt-0.5">{orders.length}</span>
              </div>
              <div className="bg-amber-50/50 p-4 rounded-2xl border border-amber-100 flex flex-col justify-center">
                <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">🟡 Chờ đối soát</span>
                <span className="text-xl font-bold text-amber-600 font-mono mt-0.5">
                  {orders.filter(o => o.status === 'pending_record' || o.status === 'pending_approve').length}
                </span>
              </div>
              <div className="bg-emerald-50/50 p-4 rounded-2xl border border-emerald-100 flex flex-col justify-center">
                <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">🟢 Đã đối soát</span>
                <span className="text-xl font-bold text-emerald-600 font-mono mt-0.5">
                  {orders.filter(o => o.status === 'approved').length}
                </span>
              </div>
              <div className="bg-rose-50 p-4 rounded-2xl border border-rose-150 flex flex-col justify-center">
                <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">🔴 Không tìm thấy đơn</span>
                <span className="text-xl font-bold text-rose-600 font-mono mt-0.5">
                  {orders.filter(o => o.status === 'cancelled').length}
                </span>
              </div>
            </div>
          </div>

          {/* Filters shelf */}
          <div className="bg-white rounded-3xl p-4 border border-coquette-deep/30 shadow-2xs space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              
              {/* Search bar */}
              <div className="space-y-1">
                <label className="text-[10.5px] font-bold text-gray-500 block">Tìm kiếm mã đơn:</label>
                <input
                  type="text"
                  value={declSearchCode}
                  onChange={(e) => setDeclSearchCode(e.target.value)}
                  placeholder="Nhập mã đơn hàng..."
                  className="w-full text-xs px-3 py-2 bg-gray-50 border border-gray-200 focus:border-coquette-accent rounded-xl outline-hidden text-gray-750 font-mono"
                />
              </div>

              {/* Filter user dropdown */}
              <div className="space-y-1">
                <label className="text-[10.5px] font-bold text-gray-500 block">Lọc theo thành viên:</label>
                <select
                  value={declFilterUser}
                  onChange={(e) => setDeclFilterUser(e.target.value)}
                  className="w-full text-xs px-2 py-2 bg-gray-50 border border-gray-200 focus:border-coquette-accent rounded-xl"
                >
                  <option value="all">-- Tất cả thành viên --</option>
                  {Array.from(new Set(orders.map(o => o.username))).filter(Boolean).map(u => (
                    <option key={u} value={u}>@{u}</option>
                  ))}
                </select>
              </div>

              {/* Filter status dropdown */}
              <div className="space-y-1">
                <label className="text-[10.5px] font-bold text-gray-500 block">Trạng thái đối soát:</label>
                <select
                  value={declFilterStatus}
                  onChange={(e) => setDeclFilterStatus(e.target.value)}
                  className="w-full text-xs px-2 py-2 bg-gray-50 border border-gray-200 focus:border-coquette-accent rounded-xl"
                >
                  <option value="all">-- Tất cả trạng thái --</option>
                  <option value="pending_record">🟡 Chờ đối soát</option>
                  <option value="approved">🟢 Đã đối soát</option>
                  <option value="cancelled">🔴 Không tìm thấy đơn</option>
                </select>
              </div>

              {/* Filter platform dropdown */}
              <div className="space-y-1">
                <label className="text-[10.5px] font-bold text-gray-500 block">Lọc theo nền tảng:</label>
                <select
                  value={declFilterPlatform}
                  onChange={(e) => setDeclFilterPlatform(e.target.value)}
                  className="w-full text-xs px-2 py-2 bg-gray-50 border border-gray-200 focus:border-coquette-accent rounded-xl"
                >
                  <option value="all">-- Tất cả nền tảng --</option>
                  <option value="shopee">Shopee 🛍️</option>
                  <option value="tiktok">TikTok Shop 🖤</option>
                </select>
              </div>

            </div>
          </div>

          {/* Declarations List Table */}
          <div className="bg-white rounded-3xl border border-coquette-deep/40 shadow-xs overflow-hidden">
            <div className="p-4 bg-gray-50 border-b border-gray-150 flex justify-between items-center flex-wrap gap-2">
              <span className="text-[12px] text-gray-700 font-bold block">
                Danh Sách Khai Báo Khảo Sát ({
                  orders.filter(order => {
                    const matchesSearch = order.orderId.toLowerCase().includes(declSearchCode.trim().toLowerCase());
                    const matchesUser = declFilterUser === 'all' || order.username === declFilterUser;
                    const matchesStatus = declFilterStatus === 'all' || order.status === declFilterStatus;
                    const isTikTok = order.orderId.toLowerCase().includes('tiktok') || 
                                     !order.orderId.match(/^\d+$/) || 
                                     (order.productName && order.productName.toLowerCase().includes('tiktok')) || 
                                     (order as any).isTikTok;
                    const matchesPlatform = declFilterPlatform === 'all' || 
                      (declFilterPlatform === 'tiktok' && isTikTok) ||
                      (declFilterPlatform === 'shopee' && !isTikTok);
                    return matchesSearch && matchesUser && matchesStatus && matchesPlatform;
                  }).length
                } kết quả)
              </span>
              <span className="text-[10.5px] text-gray-400">
                Lưu ý: Điền Hoa hồng gốc và bấm Duyệt để hệ thống tính thưởng hoàn tiền tự động cho ví thành viên.
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full table-auto border-collapse text-left">
                <thead>
                  <tr className="bg-coquette-cream/40 border-b border-coquette-deep/15 text-[10.5px] text-gray-500 font-bold uppercase tracking-wider">
                    <th className="px-4 py-3">Thời gian</th>
                    <th className="px-4 py-3">Người dùng</th>
                    <th className="px-4 py-3">Thông tin đơn hàng</th>
                    <th className="px-4 py-3">Nền tảng</th>
                    <th className="px-4 py-3 w-44">Hoa hồng gốc (VNĐ)</th>
                    <th className="px-4 py-3 w-48">Ghi chú QC nội bộ</th>
                    <th className="px-4 py-3 text-center">Trạng thái</th>
                    <th className="px-4 py-3 text-right">Thao tác xử lý</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 text-xs text-gray-700">
                  {orders
                    .filter(order => {
                      const matchesSearch = order.orderId.toLowerCase().includes(declSearchCode.trim().toLowerCase());
                      const matchesUser = declFilterUser === 'all' || order.username === declFilterUser;
                      const matchesStatus = declFilterStatus === 'all' || order.status === declFilterStatus;
                      const isTikTok = order.orderId.toLowerCase().includes('tiktok') || 
                                       !order.orderId.match(/^\d+$/) || 
                                       (order.productName && order.productName.toLowerCase().includes('tiktok')) || 
                                       (order as any).isTikTok;
                      const matchesPlatform = declFilterPlatform === 'all' || 
                        (declFilterPlatform === 'tiktok' && isTikTok) ||
                        (declFilterPlatform === 'shopee' && !isTikTok);
                      return matchesSearch && matchesUser && matchesStatus && matchesPlatform;
                    })
                    .map((order) => {
                      const systemRebatePercent = config.rebatePercent / 100;
                      const currentRawCommInput = declCommissionInputs[order.orderId] ?? String(order.rawCommission || '');
                      const calcRebateAmount = Math.round((parseFloat(currentRawCommInput) || 0) * systemRebatePercent);

                      const isTikTok = order.orderId.toLowerCase().includes('tiktok') || 
                                       !order.orderId.match(/^\d+$/) || 
                                       (order.productName && order.productName.toLowerCase().includes('tiktok')) || 
                                       (order as any).isTikTok;

                      return (
                        <tr key={order.orderId} className="hover:bg-rose-50/10 transition-colors">
                          
                          {/* Time */}
                          <td className="px-4 py-3 font-mono text-[10px] whitespace-nowrap text-gray-500">
                            {order.time ? new Date(order.time).toLocaleString('vi-VN', {
                              hour: '2-digit', minute: '2-digit',
                              day: '2-digit', month: '2-digit'
                            }) : 'N/A'}
                          </td>

                          {/* User */}
                          <td className="px-4 py-3 font-bold whitespace-nowrap text-coquette-accent">
                            @{order.username}
                          </td>

                          {/* Order ID */}
                          <td className="px-4 py-3 space-y-1">
                            <span className="font-mono font-black text-gray-800 block select-all">
                              {order.orderId}
                            </span>
                            <span className="text-[9.5px] text-gray-400 block truncate max-w-[150px]">
                              {order.productName || (isTikTok ? 'Sản phẩm TikTok Shop' : 'Sản phẩm hoàn Shopee')}
                            </span>
                          </td>

                          {/* Platform */}
                          <td className="px-4 py-3 whitespace-nowrap">
                            {isTikTok ? (
                              <span className="bg-slate-900 text-white text-[10px] font-bold px-2 py-0.5 rounded-full inline-flex items-center gap-1">
                                🖤 TikTok
                              </span>
                            ) : (
                              <span className="bg-orange-100 text-orange-700 text-[10px] font-bold px-2 py-0.5 rounded-full inline-flex items-center gap-1">
                                Shopee 🛍️
                              </span>
                            )}
                          </td>

                          {/* Commission set */}
                          <td className="px-4 py-3 space-y-1">
                            <div className="flex items-center gap-1">
                              <input
                                type="number"
                                placeholder="0"
                                value={currentRawCommInput}
                                onChange={(e) => setDeclCommissionInputs({
                                  ...declCommissionInputs,
                                  [order.orderId]: e.target.value
                                })}
                                className="w-24 text-xs px-2 py-1 bg-white border border-gray-300 rounded font-mono font-bold text-gray-700 focus:outline-coquette-accent"
                              />
                              <span className="text-[10px] text-gray-400 font-bold font-mono">đ</span>
                            </div>
                            {calcRebateAmount > 0 && (
                              <span className="text-[9px] text-emerald-600 block">
                                Khách nhận: <strong>+{calcRebateAmount.toLocaleString('vi-VN')}đ</strong> ({config.rebatePercent}%)
                              </span>
                            )}
                          </td>

                          {/* Ghi chú nội bộ */}
                          <td className="px-4 py-3">
                            <div className="flex gap-1.5 items-center">
                              <input
                                type="text"
                                placeholder="Admin ghi chú..."
                                value={declNoteInputs[order.orderId] ?? (order.internalNote || '')}
                                onChange={(e) => setDeclNoteInputs({
                                  ...declNoteInputs,
                                  [order.orderId]: e.target.value
                                })}
                                className="flex-1 text-[10.5px] px-2 py-1 bg-white border border-gray-200 rounded text-gray-600 focus:outline-coquette-accent"
                              />
                              <button
                                onClick={() => handleSaveDeclNote(order.orderId)}
                                className="bg-coquette-pink hover:bg-coquette-accent text-coquette-accent hover:text-white p-1 rounded transition-all text-[10px] font-bold cursor-pointer"
                                title="Lưu ghi chú"
                              >
                                Lưu
                              </button>
                            </div>
                          </td>

                          {/* Status Badge */}
                          <td className="px-4 py-3 text-center whitespace-nowrap">
                            {order.status === 'approved' && (
                              <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-1 rounded-full">
                                🟢 Đã đối soát
                              </span>
                            )}
                            {(order.status === 'pending_record' || order.status === 'pending_approve') && (
                              <span className="bg-amber-100 text-amber-800 text-[10px] font-bold px-2 py-1 rounded-full animate-pulse">
                                🟡 Chờ đối soát
                              </span>
                            )}
                            {order.status === 'cancelled' && (
                              <span className="bg-rose-100 text-rose-800 text-[10px] font-bold px-2 py-1 rounded-full">
                                🔴 Không tìm thấy đơn
                              </span>
                            )}
                          </td>

                          {/* Actions */}
                          <td className="px-4 py-3 text-right whitespace-nowrap space-x-1.5">
                            
                            {/* Approve Button */}
                            <button
                              onClick={() => handleUpdateDeclStatus(order.orderId, 'approved')}
                              disabled={order.status === 'approved'}
                              className={`text-[10px] font-black uppercase px-2.5 py-1.5 rounded-lg transition-all cursor-pointer shadow-3xs ${
                                order.status === 'approved'
                                  ? 'bg-gray-150 text-gray-400 cursor-not-allowed'
                                  : 'btn-admin-duyet hover:scale-105 active:scale-95'
                              }`}
                              title="Duyệt đơn hoàn"
                            >
                              Duyệt 🟢
                            </button>

                            {/* Refuse / Cancel Button */}
                            <button
                              onClick={() => handleUpdateDeclStatus(order.orderId, 'cancelled')}
                              disabled={order.status === 'cancelled'}
                              className={`text-[10px] font-black uppercase px-2.5 py-1.5 rounded-lg transition-all cursor-pointer shadow-3xs ${
                                order.status === 'cancelled'
                                  ? 'bg-gray-150 text-gray-400 cursor-not-allowed'
                                  : 'btn-admin-khongthay hover:scale-105 active:scale-95'
                              }`}
                              title="Không tìm thấy đơn"
                            >
                              Không Thấy 🔴
                            </button>

                            {/* Reset status to raw */}
                            {(order.status === 'approved' || order.status === 'cancelled') && (
                              <button
                                onClick={() => handleUpdateDeclStatus(order.orderId, 'pending_record')}
                                className="text-[10px] font-black uppercase px-2.5 py-1.5 rounded-lg transition-all cursor-pointer btn-admin-cho shadow-3xs hover:scale-105 active:scale-95"
                                title="Khôi phục trạng thái chờ đối soát"
                              >
                                Chờ 🟡
                              </button>
                            )}

                            {/* Delete declaration */}
                            <button
                              onClick={() => handleDeleteDeclaration(order.orderId)}
                              className="text-[10px] font-black uppercase px-2.5 py-1.5 rounded-lg transition-all cursor-pointer btn-admin-xoa shadow-3xs hover:scale-105 active:scale-95"
                              title="Xóa vĩnh viễn khai báo"
                            >
                              Xóa 🗑️
                            </button>

                          </td>

                        </tr>
                      );
                    })}

                  {orders.filter(order => {
                    const matchesSearch = order.orderId.toLowerCase().includes(declSearchCode.trim().toLowerCase());
                    const matchesUser = declFilterUser === 'all' || order.username === declFilterUser;
                    const matchesStatus = declFilterStatus === 'all' || order.status === declFilterStatus;
                    return matchesSearch && matchesUser && matchesStatus;
                  }).length === 0 && (
                    <tr>
                      <td colSpan={8} className="px-4 py-8 text-center text-gray-400 font-medium">
                        🌸 Không tìm thấy đơn hàng tự khai báo nào phù hợp với bộ lọc.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
