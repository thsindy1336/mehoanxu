import React, { useState, useEffect } from 'react';
import { 
  Lock, Settings, RefreshCw, BarChart3, Database, Link as LinkIcon, 
  Calendar, Filter, ChevronLeft, ChevronRight, AlertTriangle, 
  CheckCircle2, Clock, XCircle, Sparkles, Server, Check, Play 
} from 'lucide-react';
import { User, TikTokLink, TikTokOrder } from '../types';

interface TikTokViewProps {
  currentUser: User | null;
  onOpenAuthModal: () => void;
}

export default function TikTokView({ currentUser, onOpenAuthModal }: TikTokViewProps) {
  // Use 'admin' as fallback username if no user logged in to safeguard rendering
  const targetUsername = currentUser?.username || 'admin';

  // Config States
  const [creatorUsername, setCreatorUsername] = useState('');
  const [riohubApiKey, setRiohubApiKey] = useState('');
  const [configLoading, setConfigLoading] = useState(false);
  const [configSaving, setConfigSaving] = useState(false);
  const [maskedKey, setMaskedKey] = useState('');
  const [hasApiKey, setHasApiKey] = useState(false);
  const [configSuccessMsg, setConfigSuccessMsg] = useState('');
  const [isEditingConfig, setIsEditingConfig] = useState(false);
  const [webhookUrl, setWebhookUrl] = useState('https://cashback.thuydeal.site/api/riohub/webhook');

  // Diagnostic states
  const [diagnosticLoading, setDiagnosticLoading] = useState(false);
  const [diagnosticResult, setDiagnosticResult] = useState<{
    success: boolean;
    message: string;
    statusText?: string;
    creator?: string;
    apiKeyValid?: boolean;
    rioHubActive?: boolean;
    errorType?: '401' | '403' | '404' | 'other';
  } | null>(null);

  // Link Test states
  const [testProductUrl, setTestProductUrl] = useState('https://vt.tiktok.com/ZS23aBcDe/');
  const [linkTestLoading, setLinkTestLoading] = useState(false);
  const [linkTestResult, setLinkTestResult] = useState<{
    success: boolean;
    message: string;
    affiliate_link?: string;
  } | null>(null);

  // Persistent Status widget states (loaded from localStorage or evaluated defaults)
  const [statusApiKey, setStatusApiKey] = useState<'idle' | 'success' | 'error'>(() => {
    return (localStorage.getItem('tt_status_api_key') as any) || 'idle';
  });
  const [statusCreator, setStatusCreator] = useState<'idle' | 'success' | 'error'>(() => {
    return (localStorage.getItem('tt_status_creator') as any) || 'idle';
  });
  const [statusLinkGen, setStatusLinkGen] = useState<'idle' | 'success' | 'error'>(() => {
    return (localStorage.getItem('tt_status_link_gen') as any) || 'idle';
  });
  const [statusOrdersSync, setStatusOrdersSync] = useState<'idle' | 'success' | 'error'>(() => {
    return (localStorage.getItem('tt_status_orders_sync') as any) || 'idle';
  });
  const [lastCheckedTime, setLastCheckedTime] = useState<string | null>(() => {
    return localStorage.getItem('tt_last_checked_time') || null;
  });

  // Tab reports inside view
  const [reportTab, setReportTab] = useState<'links' | 'orders' | 'webhook'>('links');
  const [linksList, setLinksList] = useState<TikTokLink[]>([]);
  const [linksLoading, setLinksLoading] = useState(false);
  const [ordersList, setOrdersList] = useState<TikTokOrder[]>([]);
  const [ordersLoading, setOrdersLoading] = useState(false);
  const [orderCount, setOrderCount] = useState(0);

  // Webhook states
  const [webhookStats, setWebhookStats] = useState<{
    success: boolean;
    webhookUrl: string;
    lastReceivedAt: string;
    receivedCount: number;
    status: string;
    totalOrdersStored: number;
    logs: any[];
  } | null>(null);
  const [webhookLoading, setWebhookLoading] = useState(false);

  // Fetch function for Webhook statistics
  const fetchWebhookStats = async () => {
    setWebhookLoading(true);
    try {
      const response = await fetch('/api/riohub/webhook/stats');
      const data = await response.json();
      if (data && data.success) {
        setWebhookStats(data);
      }
    } catch (e) {
      console.error('Không thể nạp thống kê Webhook:', e);
    } finally {
      setWebhookLoading(false);
    }
  };

  // Filters for orders
  const [subIdFilter, setSubIdFilter] = useState('');
  const [orderPage, setOrderPage] = useState(1);
  const [orderLimit, setOrderLimit] = useState(5);

  // Error general
  const [errorMessage, setErrorMessage] = useState('');

  // States for Webhook Configuration and Signing Secret
  const [signingSecret, setSigningSecret] = useState('');
  const [isSecretVisible, setIsSecretVisible] = useState(false);
  const [isSavingSecret, setIsSavingSecret] = useState(false);
  const [saveSecretSuccess, setSaveSecretSuccess] = useState('');
  const [hasSigningSecret, setHasSigningSecret] = useState(false);
  const [isCopiedWebhookUrl, setIsCopiedWebhookUrl] = useState(false);
  const [isCopiedSecret, setIsCopiedSecret] = useState(false);

  // Tải Signing Secret khi mount
  useEffect(() => {
    const loadSigningSecret = async () => {
      if (currentUser?.username !== 'admin') return;
      try {
        const response = await fetch(`/api/riohub/signing-secret?username=${currentUser.username}`);
        if (response.ok) {
          const data = await response.json();
          if (data && data.success) {
            setSigningSecret(data.signingSecret || '');
            if (data.signingSecret) {
              setHasSigningSecret(true);
            }
          }
        }
      } catch (err) {
        console.warn('Không thể nạp Signing Secret:', err);
      }
    };
    
    loadSigningSecret();
  }, [currentUser]);

  // Đồng bộ trạng thái hasSigningSecret khi tải webhookStats
  useEffect(() => {
    if (webhookStats) {
      setHasSigningSecret(!!webhookStats.hasSigningSecret);
    }
  }, [webhookStats]);

  const handleSaveSecret = async () => {
    if (currentUser?.username !== 'admin') return;
    setIsSavingSecret(true);
    setSaveSecretSuccess('');
    try {
      const response = await fetch('/api/riohub/signing-secret', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: currentUser?.username,
          signingSecret
        })
      });
      const data = await response.json();
      if (data && data.success) {
        setSaveSecretSuccess('Đã lưu Signing Secret thành công! 💾');
        setHasSigningSecret(!!signingSecret);
        fetchWebhookStats();
        setTimeout(() => setSaveSecretSuccess(''), 3000);
      } else {
        alert(data.error || 'Có lỗi xảy ra');
      }
    } catch (err) {
      console.error('Lỗi khi lưu signing secret:', err);
      alert('Không thể lưu Signing Secret');
    } finally {
      setIsSavingSecret(false);
    }
  };

  // States for diagnostic logs and testing API Orders
  const [testOrdersLoading, setTestOrdersLoading] = useState(false);
  const [testOrdersResult, setTestOrdersResult] = useState<any>(null);
  const [diagnosticLogs, setDiagnosticLogs] = useState<any[]>([]);
  const [diagLogsLoading, setDiagLogsLoading] = useState(false);

  const fetchDiagnosticLogs = async () => {
    setDiagLogsLoading(true);
    try {
      const res = await fetch('/api/tiktok/diagnostic-logs');
      if (res.ok) {
        setDiagnosticLogs(await res.json());
      }
    } catch (e) {
      console.error(e);
    } finally {
      setDiagLogsLoading(false);
    }
  };

  // Save specific status items helper
  const saveWidgetStates = (
    apiKey: 'idle' | 'success' | 'error',
    creator: 'idle' | 'success' | 'error',
    linkGen: 'idle' | 'success' | 'error',
    orders: 'idle' | 'success' | 'error',
    time: string | null
  ) => {
    setStatusApiKey(apiKey);
    setStatusCreator(creator);
    setStatusLinkGen(linkGen);
    setStatusOrdersSync(orders);
    setLastCheckedTime(time);
    
    localStorage.setItem('tt_status_api_key', apiKey);
    localStorage.setItem('tt_status_creator', creator);
    localStorage.setItem('tt_status_link_gen', linkGen);
    localStorage.setItem('tt_status_orders_sync', orders);
    if (time) localStorage.setItem('tt_last_checked_time', time);
  };

  // Format date DD/MM/YYYY HH:mm
  const formatVietnameseDateTime = () => {
    const now = new Date();
    const day = String(now.getDate()).padStart(2, '0');
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const year = now.getFullYear();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    return `${day}/${month}/${year} ${hours}:${minutes}`;
  };

  // Load config on mount
  useEffect(() => {
    fetchUserConfig();
    fetchDiagnosticLogs();
  }, [targetUsername]);

  // Load report data on tab changes or pagination
  useEffect(() => {
    if (reportTab === 'links') {
      fetchTikTokLinks();
    } else if (reportTab === 'orders') {
      fetchTikTokOrders();
    } else if (reportTab === 'webhook') {
      fetchWebhookStats();
    }
  }, [reportTab, orderPage, orderLimit, subIdFilter]);

  const fetchUserConfig = async () => {
    setConfigLoading(true);
    setErrorMessage('');
    try {
      const response = await fetch(`/api/tiktok/config/${targetUsername}`);
      const data = await response.json();
      setCreatorUsername(data.creator_username || '');
      setHasApiKey(data.has_key);
      setMaskedKey(data.masked_key || '');
      setWebhookUrl(data.webhook_url || 'https://cashback.thuydeal.site/api/riohub/webhook');
      if (data.has_key) {
        setIsEditingConfig(false);
      } else {
        setIsEditingConfig(true);
      }
    } catch (err) {
      console.error('Lỗi tải cấu hình TikTok Shop:', err);
    } finally {
      setConfigLoading(false);
    }
  };

  // Save standard Config
  const handleSaveConfig = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!creatorUsername.trim()) {
      setErrorMessage('⚠️ Vui lòng nhập Creator Username TikTok.');
      return;
    }

    setConfigSaving(true);
    setErrorMessage('');
    setConfigSuccessMsg('');

    try {
      const response = await fetch(`/api/tiktok/config/${targetUsername}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          creator_username: creatorUsername.trim(),
          api_key: riohubApiKey.trim() || undefined,
          webhook_url: webhookUrl.trim()
        })
      });

      const data = await response.json();
      if (response.ok) {
        setConfigSuccessMsg('🎉 ' + data.message);
        setRiohubApiKey('');
        await fetchUserConfig();
      } else {
        setErrorMessage(data.message || '⚠️ Không thể lưu cấu hình TikTok Shop.');
      }
    } catch (err: any) {
      setErrorMessage('⚠️ Kết nối máy chủ lưu cấu hình thất bại.');
    } finally {
      setConfigSaving(false);
    }
  };

  // TEST CONNECTION (KHÔNG làm mất thông tin đã lưu, đọc trực tiếp từ server nếu không nhập API Key)
  const handleTestConnection = async () => {
    if (!creatorUsername.trim()) {
      setErrorMessage('⚠️ Nhập Creator Username trước khi kiểm tra kết nối.');
      return;
    }

    const testApiKey = riohubApiKey.trim() || (hasApiKey ? 'rhk_placeholder_existing' : '');
    if (!testApiKey) {
      setErrorMessage('⚠️ Vui lòng nhập RioHub API Key để thực hiện kiểm tra.');
      return;
    }

    setDiagnosticLoading(true);
    setDiagnosticResult(null);
    setErrorMessage('');

    const queryParams = new URLSearchParams({
      creator_username: creatorUsername.trim(),
      api_key: riohubApiKey.trim() || 'mock_use_saved_key_or_placeholder',
      username: targetUsername
    });

    // If using the masked key (existed on server but not re-typed)
    // pass temporary string to use server's saved key
    if (!riohubApiKey.trim() && hasApiKey) {
      queryParams.set('api_key', 'rhk_placeholder_saved');
    }

    try {
      // Custom endpoint for checking connection: /api/tiktok/test-connection
      const url = `/api/tiktok/test-connection?creator_username=${encodeURIComponent(creatorUsername.trim())}&api_key=${encodeURIComponent(queryParams.get('api_key') || '')}&username=${encodeURIComponent(targetUsername)}`;
      const response = await fetch(url);
      const data = await response.json();

      const timeString = formatVietnameseDateTime();

      if (response.status === 200) {
        setDiagnosticResult({
          success: true,
          message: '🟢 Kết nối thành công',
          creator: creatorUsername.trim(),
          apiKeyValid: true,
          rioHubActive: true
        });

        // Set status indicators to green
        saveWidgetStates(
          'success', // API Key hợp lệ
          'success', // Creator kết nối
          statusLinkGen, // Giữ nguyên trạng thái tạo link trước đó
          'success', // Đồng bộ đơn hàng hoạt động ( vì kết nối 200 OK được đồng bộ đơn )
          timeString
        );
      } else {
        // Evaluate specific errors requested
        let errorType: string = 'other';
        let diagMsg = data.message || '🔴 Lỗi không xác định';

        if (response.status === 401) {
          errorType = '401';
          diagMsg = '❌ API Key không hợp lệ';
          saveWidgetStates('error', 'error', statusLinkGen, 'error', timeString);
        } else if (response.status === 403) {
          errorType = '403';
          diagMsg = '❌ Creator không thuộc API Key hiện tại';
          saveWidgetStates('success', 'error', statusLinkGen, 'error', timeString);
        } else if (response.status === 404) {
          errorType = '404';
          diagMsg = '❌ Creator chưa được kết nối RioHub';
          saveWidgetStates('success', 'error', statusLinkGen, 'error', timeString);
        } else if (response.status === 422) {
          errorType = '422';
          diagMsg = '⚠️ RioHub từ chối yêu cầu do dữ liệu gửi lên không hợp lệ';
          saveWidgetStates('success', 'success', statusLinkGen, 'error', timeString);
        } else {
          saveWidgetStates('error', 'error', statusLinkGen, 'error', timeString);
        }

        setDiagnosticResult({
          success: false,
          message: diagMsg,
          errorType,
          body: data.body || ''
        });
      }
    } catch (err: any) {
      setDiagnosticResult({
        success: false,
        message: `🔴 Lỗi kết nối mạng máy chủ: ${err.message || 'Thử lại sau'}`
      });
    } finally {
      setDiagnosticLoading(false);
      fetchDiagnosticLogs();
    }
  };

  // TEST API ORDERS (Kiểm Tra API Orders)
  const handleTestOrdersApi = async () => {
    if (!creatorUsername.trim()) {
      setErrorMessage('⚠️ Nhập Creator Username trước khi kiểm tra.');
      return;
    }

    setTestOrdersLoading(true);
    setTestOrdersResult(null);
    setErrorMessage('');

    const apiKeyParam = riohubApiKey.trim() || (hasApiKey ? 'rhk_placeholder_saved' : 'mock_use_saved_key_or_placeholder');

    try {
      const url = `/api/tiktok/test-orders-api?creator_username=${encodeURIComponent(creatorUsername.trim())}&api_key=${encodeURIComponent(apiKeyParam)}&username=${encodeURIComponent(targetUsername)}`;
      const response = await fetch(url);
      const data = await response.json();

      if (response.ok) {
        setTestOrdersResult({
          success: true,
          status: response.status,
          message: data.message || '🟢 Gọi API Orders thành công',
          body: data.body
        });
      } else {
        setTestOrdersResult({
          success: false,
          status: response.status,
          message: data.message || '🔴 Gọi API Orders thất bại',
          body: data.body
        });
      }
    } catch (err: any) {
      setTestOrdersResult({
        success: false,
        message: `🔴 Lỗi mạng: ${err.message}`
      });
    } finally {
      setTestOrdersLoading(false);
      fetchDiagnosticLogs();
    }
  };

  // TEST GENERATING LINK
  const handleTestCreateLink = async () => {
    if (!creatorUsername.trim()) {
      setErrorMessage('⚠️ Vui lòng điền Creator Username trước.');
      return;
    }
    if (!testProductUrl.trim()) {
      setErrorMessage('⚠️ Vui lòng nhập link sản phẩm cần test.');
      return;
    }

    setLinkTestLoading(true);
    setLinkTestResult(null);

    const queryParams = new URLSearchParams({
      creator_username: creatorUsername.trim(),
      api_key: riohubApiKey.trim() || 'mock_test_link',
      product_url: testProductUrl.trim(),
      username: targetUsername
    });

    if (!riohubApiKey.trim() && hasApiKey) {
      queryParams.set('api_key', 'rhk_placeholder_saved');
    }

    try {
      const url = `/api/tiktok/test-link?creator_username=${encodeURIComponent(creatorUsername.trim())}&api_key=${encodeURIComponent(queryParams.get('api_key') || '')}&product_url=${encodeURIComponent(testProductUrl.trim())}&username=${encodeURIComponent(targetUsername)}`;
      const response = await fetch(url);
      const data = await response.json();

      const timeString = formatVietnameseDateTime();

      if (response.status === 200 && data.affiliate_link) {
        setLinkTestResult({
          success: true,
          message: '🟢 Tạo link thành công',
          affiliate_link: data.affiliate_link
        });

        // Set link generation status to Success
        saveWidgetStates(
          statusApiKey === 'idle' ? 'success' : statusApiKey,
          statusCreator === 'idle' ? 'success' : statusCreator,
          'success', // Tạo link thành công
          statusOrdersSync === 'idle' ? 'success' : statusOrdersSync,
          timeString
        );

        // Refresh links history list
        fetchTikTokLinks();
      } else {
        setLinkTestResult({
          success: false,
          message: data.message || '🔴 Tạo link không thành công. Hãy kiểm tra kết nối API.'
        });

        saveWidgetStates(
          statusApiKey,
          statusCreator,
          'error', // Tạo link thất bại
          statusOrdersSync,
          timeString
        );
      }
    } catch (err: any) {
      setLinkTestResult({
        success: false,
        message: `🔴 Lỗi máy chủ: ${err.message || 'Không kết nối được'}`
      });
    } finally {
      setLinkTestLoading(false);
      fetchDiagnosticLogs();
    }
  };

  const fetchTikTokLinks = async () => {
    setLinksLoading(true);
    try {
      const response = await fetch(`/api/v1/partner/tiktok/affiliate/links?username=${targetUsername}`);
      const data = await response.json();
      if (Array.isArray(data)) {
        setLinksList(data);
      } else {
        setLinksList([]);
      }
    } catch (e) {
      console.error('Cannot sync links list:', e);
    } finally {
      setLinksLoading(false);
    }
  };

  const fetchTikTokOrders = async () => {
    setOrdersLoading(true);
    try {
      const queryParams = new URLSearchParams({
        username: targetUsername,
        page: orderPage.toString(),
        limit: orderLimit.toString()
      });
      if (subIdFilter.trim()) {
        queryParams.append('sub_id', subIdFilter.trim());
      }
      const response = await fetch(`/api/v1/partner/tiktok/affiliate/orders?${queryParams.toString()}`);
      const data = await response.json();
      if (data && Array.isArray(data.orders)) {
        setOrdersList(data.orders);
        setOrderCount(data.total || data.orders.length);
      } else {
        setOrdersList([]);
        setOrderCount(0);
      }
    } catch (e) {
      console.error('Cannot sync orders:', e);
    } finally {
      setOrdersLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Visual Header */}
      <div className="bg-gradient-to-r from-gray-900 to-slate-800 p-6 rounded-3xl text-white space-y-2 relative overflow-hidden shadow-md">
        <div className="absolute right-[-20px] top-[-20px] text-gray-800 opacity-20 pointer-events-none">
          <Settings size={140} />
        </div>
        
        <div className="flex items-center gap-2">
          <span className="text-xl">🖤</span>
          <h2 className="font-serif text-xl font-bold tracking-tight">Khu Vực Quản Trị: Kết Nối TikTok Shop</h2>
          <span className="text-[10px] bg-coquette-accent/30 text-coquette-accent px-2 py-0.5 rounded-full border border-coquette-accent/50 font-sans">
            Admin Dedicated Only
          </span>
        </div>
        <p className="text-xs text-gray-300 max-w-xl leading-relaxed">
          Phục vụ kiểm toán, chẩn đoán API trực tiếp tới máy chủ đối tác <span className="text-red-300 font-mono underline">riohub.vn</span>. Theo dõi sức khỏe kết nối, phân tách chính xác các mã lỗi 401, 403, 440 và thử nghiệm chuyển đổi liên kết thực tế.
        </p>
      </div>

      {/* Grid Layout containing Main Controls & Status Widget */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        
        {/* LEFT COLUMN: Configurations & Live Testing Diagnostic Blocks (8 Cols) */}
        <div className="lg:col-span-7 space-y-5">
          
          {/* Card 1: Configuration Fields */}
          <div className="bg-white rounded-[24px] p-5 border border-coquette-deep shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-2.5 border-b border-dashed border-coquette-deep/40">
              <Settings className="w-4.5 h-4.5 text-coquette-accent" />
              <h3 className="font-serif text-sm font-black text-gray-800">Cấu Hình RioHub API & Creator ID</h3>
            </div>

            {configLoading ? (
              <div className="py-6 text-center space-y-1">
                <RefreshCw className="w-5 h-5 text-coquette-accent animate-spin mx-auto" />
                <span className="text-[10px] text-gray-400 font-mono">Đang nạp dữ liệu server...</span>
              </div>
            ) : (
              <div className="space-y-4 text-xs">
                {configSuccessMsg && (
                  <div className="p-3 bg-emerald-50 text-emerald-800 border border-emerald-200/50 rounded-xl font-medium">
                    {configSuccessMsg}
                  </div>
                )}

                {!isEditingConfig ? (
                  // CHẾ ĐỘ VIEW-MODE (XEM CẤU HÌNH ĐÃ LƯU)
                  <div className="space-y-4 animate-in fade-in duration-200 text-left">
                    <div className="bg-coquette-cream/30 p-4 rounded-2xl border border-coquette-deep/50 space-y-3">
                      <div className="flex justify-between items-center py-2 border-b border-gray-100/60">
                        <span className="font-bold text-gray-500 font-sans">Creator Username:</span>
                        <span className="font-mono text-xs font-extrabold text-gray-800 bg-white px-2.5 py-1 rounded-lg border border-gray-200 shadow-3xs">
                          {creatorUsername || 'Chưa thiết lập'}
                        </span>
                      </div>
                      <div className="flex justify-between items-center py-2 border-b border-gray-100/60">
                        <span className="font-bold text-gray-500 font-sans">API Key:</span>
                        <code className="font-mono text-[11px] text-rose-600 bg-white px-2.5 py-1 rounded-lg border border-gray-200 shadow-3xs select-all">
                          {maskedKey || 'rhk_xxxxxxxxxxxxxx1234'}
                        </code>
                      </div>
                      <div className="flex justify-between items-center py-2">
                        <span className="font-bold text-gray-500 font-sans">Webhook URL:</span>
                        <code className="font-mono text-[10px] text-cyan-700 bg-white px-2.5 py-1 rounded-lg border border-gray-200 shadow-3xs truncate max-w-[200px]" title={webhookUrl}>
                          {webhookUrl}
                        </code>
                      </div>
                    </div>

                    {/* Các nút ở View-Mode */}
                    <div className="space-y-2 pt-2">
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          onClick={() => setIsEditingConfig(true)}
                          style={{ cursor: 'pointer' }}
                          className="py-2.5 bg-gray-150 hover:bg-gray-200 text-gray-700 rounded-xl font-bold flex items-center justify-center gap-1 border border-gray-250 shadow-3xs transition-all font-sans"
                        >
                          <Settings className="w-3.5 h-3.5" />
                          <span>Cập Nhật</span>
                        </button>
                        
                        <button
                          onClick={handleTestConnection}
                          disabled={diagnosticLoading}
                          style={{ cursor: 'pointer' }}
                          className="py-2.5 bg-coquette-accent text-white hover:bg-coquette-accent/95 disabled:bg-gray-200 rounded-xl font-bold flex items-center justify-center gap-1 shadow-xs transition-all font-sans"
                        >
                          {diagnosticLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5 fill-white text-coquette-accent" />}
                          <span>Kiểm tra kết nối</span>
                        </button>
                      </div>

                      <button
                        onClick={handleTestOrdersApi}
                        disabled={testOrdersLoading}
                        style={{ cursor: 'pointer' }}
                        className="w-full py-2.5 bg-slate-800 text-slate-100 hover:bg-slate-900 disabled:bg-gray-200 rounded-xl font-bold flex items-center justify-center gap-1.5 shadow-xs transition-all font-sans"
                      >
                        {testOrdersLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Server className="w-3.5 h-3.5 text-cyan-400" />}
                        <span>Kiểm Tra API Orders (Chẩn Đoán API)</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  // CHẾ ĐỘ EDIT-MODE (SỬA ĐỔI HOẶC CHƯA CÓ CẤU HÌNH)
                  <div className="space-y-4 animate-in fade-in duration-200 text-left">
                    <div className="space-y-1.5">
                      <label className="font-bold text-gray-600 block font-sans">Creator Username TikTok:</label>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 font-mono">@</span>
                        <input
                          type="text"
                          value={creatorUsername}
                          placeholder="Nhập ID TikTok chính xác (ví dụ: tthuy3326)"
                          onChange={(e) => setCreatorUsername(e.target.value)}
                          className="w-full pl-7 pr-4 py-2 bg-coquette-cream/20 border border-coquette-deep rounded-xl outline-hidden focus:border-coquette-accent font-sans text-gray-800"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="font-bold text-gray-600 block font-sans">RioHub API Key (Bảo mật tối đa):</label>
                      <input
                        type="password"
                        value={riohubApiKey}
                        placeholder={hasApiKey ? 'Bỏ trống để giữ lại key cũ đã lưu...' : 'Nhập RioHub API Key (rhk_...)'}
                        onChange={(e) => setRiohubApiKey(e.target.value)}
                        className="w-full px-3 py-2 bg-coquette-cream/20 border border-coquette-deep rounded-xl outline-hidden focus:border-coquette-accent font-mono placeholder-gray-400"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="font-bold text-gray-600 block font-sans">Webhook URL (Dùng nhận đơn tự động):</label>
                      <input
                        type="text"
                        value={webhookUrl}
                        onChange={(e) => setWebhookUrl(e.target.value)}
                        className="w-full px-3 py-2 bg-gray-50 border border-gray-200 text-gray-400 rounded-xl outline-hidden font-mono"
                        placeholder="https://cashback.thuydeal.site/api/riohub/webhook"
                      />
                    </div>

                    {/* Các nút ở Edit-Mode */}
                    <div className="grid grid-cols-2 gap-2 pt-2">
                      {hasApiKey ? (
                        <>
                          <button
                            type="button"
                            onClick={() => {
                              setIsEditingConfig(false);
                              fetchUserConfig();
                            }}
                            style={{ cursor: 'pointer' }}
                            className="py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-xl font-bold flex items-center justify-center gap-1 border border-gray-200 transition-all font-sans"
                          >
                            <span>Hủy</span>
                          </button>
                          <button
                            onClick={() => handleSaveConfig()}
                            disabled={configSaving}
                            style={{ cursor: 'pointer' }}
                            className="py-2.5 bg-coquette-accent text-white hover:bg-coquette-accent/90 disabled:bg-gray-50 rounded-xl font-bold flex items-center justify-center gap-1 border border-transparent shadow-xs transition-all font-sans"
                          >
                            {configSaving ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                            <span>Lưu Cấu Hình</span>
                          </button>
                        </>
                      ) : (
                        <button
                          onClick={() => handleSaveConfig()}
                          disabled={configSaving}
                          style={{ cursor: 'pointer' }}
                          className="col-span-2 py-2.5 bg-coquette-accent text-white hover:bg-coquette-accent/90 disabled:bg-gray-50 rounded-xl font-bold flex items-center justify-center gap-1 border border-transparent shadow-xs transition-all font-sans"
                        >
                          {configSaving ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                          <span>Lưu Cấu Hình</span>
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {/* General errors box */}
                {errorMessage && (
                  <div className="flex gap-2 p-3 bg-rose-50 text-rose-700 border border-rose-100 rounded-xl font-sans text-[11px] leading-relaxed text-left">
                    <AlertTriangle className="w-4 h-4 shrink-0 text-rose-500 mt-0.5" />
                    <span>{errorMessage}</span>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Webhook Configuration Widget Card */}
          <div className="bg-white rounded-[24px] p-5 border border-coquette-deep shadow-xs space-y-4 text-left">
            <div className="flex items-center justify-between pb-2.5 border-b border-dashed border-coquette-deep/40">
              <div className="flex items-center gap-2">
                <Database className="w-4.5 h-4.5 text-coquette-accent" />
                <h3 className="font-serif text-sm font-black text-gray-800">TikTok Shop ➔ Webhook Cấu Hình</h3>
              </div>
              <span className="text-[10px] bg-pink-100 text-coquette-accent px-2.5 py-0.5 rounded-full border border-pink-200 font-sans font-bold">
                RioHub Webhook
              </span>
            </div>

            <div className="space-y-4 text-xs">
              {/* Trạng thái quy định */}
              <div className="flex justify-between items-center bg-gray-50/70 p-3 rounded-xl border border-gray-150">
                <span className="font-bold text-gray-500 font-sans">Trạng thái:</span>
                <span className={`text-[10px] md:text-[11px] font-extrabold px-2.5 py-0.5 rounded-full border ${
                  hasSigningSecret 
                    ? 'bg-emerald-100 text-emerald-800 border-emerald-200' 
                    : 'bg-rose-100 text-rose-800 border-rose-250/60'
                }`}>
                  {hasSigningSecret ? '🟢 Webhook đã cấu hình' : '🔴 Chưa cấu hình Signing Secret'}
                </span>
              </div>

              {/* Webhook URL */}
              <div className="space-y-1.5">
                <label className="font-bold text-gray-650 block font-sans">Webhook URL:</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    readOnly
                    value="https://cashback.thuydeal.site/api/riohub/webhook"
                    className="flex-1 px-3 py-2 bg-gray-50 border border-gray-200 text-gray-500 rounded-xl outline-none font-mono font-medium text-[11px]"
                  />
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText('https://cashback.thuydeal.site/api/riohub/webhook');
                      setIsCopiedWebhookUrl(true);
                      setTimeout(() => setIsCopiedWebhookUrl(false), 2000);
                    }}
                    className="px-3 bg-coquette-cream border border-coquette-deep hover:bg-coquette-pink font-bold rounded-xl text-xs transition-style flex items-center gap-1 cursor-pointer shrink-0 text-coquette-accent"
                  >
                    {isCopiedWebhookUrl ? <Check className="w-3.5 h-3.5 text-green-600" /> : '📋 Sao chép'}
                  </button>
                </div>
              </div>

              {/* Signing Secret */}
              <div className="space-y-1.5">
                <label className="font-bold text-gray-650 block font-sans">Signing Secret:</label>
                {currentUser?.username === 'admin' ? (
                  <div className="space-y-2">
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <input
                          type={isSecretVisible ? 'text' : 'password'}
                          value={signingSecret}
                          onChange={(e) => setSigningSecret(e.target.value)}
                          placeholder="rhsec_xxxxxxxxxxxxxxxxx"
                          className="w-full pl-3 pr-10 py-2 bg-coquette-cream/20 border border-coquette-deep rounded-xl outline-none focus:border-coquette-accent font-mono text-gray-800 font-bold leading-normal"
                        />
                        <button
                          type="button"
                          onClick={() => setIsSecretVisible(!isSecretVisible)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 font-bold transition-all text-sm border-none bg-transparent cursor-pointer"
                        >
                          {isSecretVisible ? '👁' : '🙈'}
                        </button>
                      </div>
                      <button
                        onClick={() => {
                          if (!signingSecret) return;
                          navigator.clipboard.writeText(signingSecret);
                          setIsCopiedSecret(true);
                          setTimeout(() => setIsCopiedSecret(false), 2000);
                        }}
                        disabled={!signingSecret}
                        className="px-3 bg-coquette-cream border border-coquette-deep hover:bg-coquette-pink font-bold rounded-xl text-xs transition-style disabled:opacity-45 flex items-center gap-1 cursor-pointer shrink-0 text-coquette-accent"
                      >
                        {isCopiedSecret ? <Check className="w-3.5 h-3.5 text-green-600" /> : '📋 Sao chép'}
                      </button>
                      <button
                        onClick={handleSaveSecret}
                        disabled={isSavingSecret}
                        className="px-3 bg-coquette-accent hover:bg-opacity-95 text-white font-bold rounded-xl text-xs transition-style flex items-center gap-1 cursor-pointer shrink-0 border-none"
                      >
                        {isSavingSecret ? <RefreshCw className="w-3.5 h-3.5 animate-spin mx-auto" /> : '💾 Lưu'}
                      </button>
                    </div>
                    {saveSecretSuccess && (
                      <div className="p-2 bg-emerald-50 text-emerald-800 border border-emerald-200/50 rounded-lg text-[10.5px] font-bold text-center animate-in zoom-in duration-200 font-sans">
                        {saveSecretSuccess}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="space-y-2">
                    <input
                      type="password"
                      disabled
                      value="xxxxxxxxxxxxxxxx"
                      className="w-full px-3 py-2 bg-gray-150 border border-gray-200 text-gray-400 rounded-xl outline-none font-mono"
                    />
                    <div className="p-2.5 bg-rose-50 border border-rose-100/50 rounded-xl text-rose-700 text-[10.5px] font-bold flex items-center gap-1.5 leading-relaxed font-sans">
                      <Lock className="w-3.5 h-3.5 shrink-0 text-rose-500 font-bold" />
                      <span>Bạn không có quyền quản lý Signing Secret (Chỉ Super Admin mới có quyền xem và sửa)</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Card 2: LIVE Diagnostic Connection Terminal */}
          {diagnosticLoading || diagnosticResult ? (
            <div className="bg-slate-900 rounded-[24px] p-5 border border-slate-700 text-slate-200 shadow-md space-y-3 font-mono text-xs">
              <div className="flex justify-between items-center pb-2 border-b border-slate-800 text-slate-400">
                <span className="flex items-center gap-1.5 font-bold">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
                  <span>Console Kiểm Tra Kết Nối TikTok Shop</span>
                </span>
                <span className="text-[10px] bg-slate-800 px-1.5 py-0.2 rounded text-slate-400">RioHub</span>
              </div>

              {diagnosticLoading ? (
                <div className="py-4 space-y-1.5">
                  <div className="flex items-center gap-2">
                    <RefreshCw className="w-3.5 h-3.5 text-coquette-accent animate-spin" />
                    <span className="text-slate-400">Đang khởi tạo phiên kiểm toán...</span>
                  </div>
                  <p className="text-slate-500 select-all">$ GET https://riohub.vn/api/v1/partner/tiktok/affiliate/links?creator_username={creatorUsername}&page=1&page_size=1</p>
                </div>
              ) : (
                <div className="space-y-3.5 leading-relaxed">
                  {diagnosticResult?.success ? (
                    <div className="space-y-2">
                      <div className="text-emerald-400 font-bold flex items-center gap-1.5 text-sm">
                        <span>🟢 Kết nối thành công</span>
                      </div>
                      <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 space-y-1 text-[11px] text-slate-350">
                        <p>👤 Creator: <span className="text-slate-200 font-bold">{diagnosticResult.creator}</span></p>
                        <p>🔑 API Key: <span className="text-emerald-400 font-bold">Hợp lệ</span></p>
                        <p>🌐 RioHub API: <span className="text-emerald-400 font-bold">Hoạt động</span></p>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="text-rose-400 font-bold flex items-center gap-1 text-sm">
                        <span>{diagnosticResult?.message}</span>
                      </div>
                      <div className="bg-slate-950 p-3 rounded-xl border border-red-900/30 text-[10.5px] text-slate-400 space-y-1">
                        <p>🔎 Trạng thái lỗi phân tích:</p>
                        {diagnosticResult?.errorType === '401' && (
                          <p className="text-red-300">401 Unauthorized: API Key sai hoặc bị khoá từ phía tài khoản RioHub.</p>
                        )}
                        {diagnosticResult?.errorType === '403' && (
                          <p className="text-red-300">403 Forbidden: Creator này đang thuộc API Key của một tài khoản khác.</p>
                        )}
                        {diagnosticResult?.errorType === '404' && (
                          <p className="text-red-300">404 Not Found: Bạn chưa thêm hoặc đồng bộ hóa Creator này trong ứng dụng RioHub.</p>
                        )}
                        {diagnosticResult?.errorType === '422' && (
                          <div className="space-y-1">
                            <p className="text-red-300 font-bold">422 Unprocessable Entity: Yêu cầu bị RioHub từ chối do dữ liệu đầu vào không hợp lệ hoặc sản phẩm không đủ điều kiện affiliate.</p>
                            {diagnosticResult?.body && (
                              <div className="mt-1.5 p-2 bg-slate-900 rounded border border-slate-800 text-[10px] text-slate-300 overflow-x-auto max-h-24 select-all">
                                <strong>Chi tiết phản hồi:</strong> {diagnosticResult.body}
                              </div>
                            )}
                          </div>
                        )}
                        {diagnosticResult?.errorType === 'other' && (
                          <div className="space-y-1">
                            <p className="text-slate-350">Vui lòng rà soát lại thông tin nhập.</p>
                            {diagnosticResult?.body && (
                              <div className="mt-1.5 p-2 bg-slate-900 rounded border border-slate-800 text-[10px] text-slate-300 overflow-x-auto max-h-24 select-all">
                                <strong>Chi tiết phản hồi:</strong> {diagnosticResult.body}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : (
            <div className="bg-coquette-pink/30 rounded-[24px] p-4 text-center border border-dashed border-coquette-accent/40 text-xs text-gray-500">
              Chưa có phiên kiểm tra kết nối nào chạy. Nhập thông tin & bấm <strong>"Kiểm tra kết nối"</strong> bên trên nhé!
            </div>
          )}

          {/* Console Kiểm Tra API Orders TikTok Shop */}
          {testOrdersLoading || testOrdersResult ? (
            <div className="bg-slate-900 rounded-[24px] p-5 border border-slate-700 text-slate-200 shadow-md space-y-3 font-mono text-xs text-left animate-in fade-in duration-200">
              <div className="flex justify-between items-center pb-2 border-b border-slate-800 text-slate-400">
                <span className="flex items-center gap-1.5 font-bold text-cyan-400">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
                  <span>Console Kiểm Tra API Orders TikTok Shop</span>
                </span>
                <span className="text-[10px] bg-slate-850 px-1.5 py-0.5 rounded text-cyan-400">GET Orders</span>
              </div>

              {testOrdersLoading ? (
                <div className="py-4 space-y-1.5">
                  <div className="flex items-center gap-2">
                    <RefreshCw className="w-3.5 h-3.5 text-coquette-accent animate-spin" />
                    <span className="text-slate-400">Đang thực hiện chẩn đoán API Orders từ RioHub...</span>
                  </div>
                  <p className="text-slate-500 select-all font-mono text-[9px] break-all">
                    $ GET https://riohub.vn/api/v1/partner/tiktok/affiliate/orders?creator_username={creatorUsername}&page=1&limit=2
                  </p>
                </div>
              ) : (
                <div className="space-y-3 leading-relaxed">
                  {testOrdersResult?.success ? (
                    <div className="space-y-2">
                      <div className="text-emerald-400 font-bold flex items-center gap-1.5 text-sm">
                        <span>🟢 Kết nối API Orders thành công (HTTP {testOrdersResult.status})</span>
                      </div>
                      <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-[10.5px] text-slate-300">
                        <p className="text-slate-400 font-bold mb-1">Dữ liệu thô từ RioHub:</p>
                        <pre className="font-mono text-[9px] text-cyan-300 whitespace-pre overflow-x-auto max-h-[160px] p-2 bg-slate-900 rounded border border-slate-800">
                          {JSON.stringify(testOrdersResult.body, null, 2)}
                        </pre>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="text-rose-400 font-bold flex items-center gap-1 text-sm">
                        <span>🔴 Lỗi kết xuất API ({testOrdersResult?.status || 500})</span>
                      </div>
                      <div className="bg-slate-950 p-3 rounded-xl border border-rose-950 text-[10.5px] text-slate-350">
                        <p className="text-rose-300 font-bold mb-1">Mã lỗi & Tin nhắn chi tiết:</p>
                        <p className="text-rose-400 font-semibold mb-2">{testOrdersResult?.message}</p>
                        <pre className="font-mono text-[9px] text-rose-300 whitespace-pre overflow-x-auto max-h-[160px] p-2 bg-slate-900 rounded border border-rose-950">
                          {JSON.stringify(testOrdersResult?.body, null, 2)}
                        </pre>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : null}

          {/* Card 3: Test Tạo Link Thực Tế */}
          <div className="bg-white rounded-[24px] p-5 border border-coquette-deep shadow-xs space-y-3.5">
            <div className="flex justify-between items-center pb-2 border-b border-dashed border-coquette-deep/40">
              <h3 className="font-serif text-sm font-black text-gray-800 flex items-center gap-1.5">
                <LinkIcon className="w-4 h-4 text-coquette-accent" />
                <span>Test Tạo Link Thực Tế</span>
              </h3>
              <span className="text-[9px] bg-emerald-50 text-emerald-700 font-bold px-1.5 py-0.2 rounded border border-emerald-100">POST /partner/tiktok</span>
            </div>

            <div className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-gray-600 block">Link sản phẩm cần chuyển đổi:</label>
                <div className="flex gap-2">
                  <input
                    type="url"
                    value={testProductUrl}
                    onChange={(e) => setTestProductUrl(e.target.value)}
                    placeholder="Dán link TikTok (https://vt.tiktok.com/xxxx)"
                    className="flex-1 px-3 py-2 bg-coquette-cream/20 border border-coquette-deep rounded-xl outline-hidden focus:border-coquette-accent font-mono text-[11px]"
                  />
                  <button
                    onClick={handleTestCreateLink}
                    disabled={linkTestLoading}
                    style={{ cursor: 'pointer' }}
                    className="px-4 bg-emerald-600 text-white hover:bg-emerald-700 disabled:bg-gray-200 rounded-xl font-bold transition-all shadow-3xs shrink-0"
                  >
                    {linkTestLoading ? 'Đang tạo...' : 'Test tạo link'}
                  </button>
                </div>
              </div>

              {/* link test results output */}
              {linkTestResult && (
                <div className="p-3.5 rounded-xl text-[11.5px] border font-sans animate-in fade-in duration-200">
                  {linkTestResult.success ? (
                    <div className="space-y-2 text-emerald-800 bg-emerald-50/70 border-emerald-250">
                      <p className="font-bold">🟢 Tạo link thành công</p>
                      {linkTestResult.affiliate_link && (
                        <div className="p-2 bg-white rounded-lg border border-emerald-200/50 flex justify-between items-center gap-2">
                          <span className="font-mono text-emerald-800 truncate font-semibold select-all break-all">{linkTestResult.affiliate_link}</span>
                          <a
                            href={linkTestResult.affiliate_link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[10px] bg-emerald-600 text-white px-2 py-0.5 rounded-md shrink-0 font-bold hover:bg-emerald-700"
                          >
                            Mở
                          </a>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="p-2.5 rounded-lg bg-rose-50/70 border-rose-200 text-rose-800 font-medium">
                      {linkTestResult.message}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Card 4: LOG CHẨN ĐOÁN LỖI RIOHUB CHO ADMIN */}
          <div className="bg-white rounded-[24px] p-5 border border-coquette-deep shadow-xs space-y-3.5">
            <div className="flex justify-between items-center pb-2 border-b border-dashed border-coquette-deep/40 animate-in fade-in">
              <h3 className="font-serif text-sm font-black text-gray-800 flex items-center gap-1.5 text-left">
                <Database className="w-4 h-4 text-slate-700" />
                <span>Log Chẩn Đoán Lỗi RioHub cho Admin</span>
              </h3>
              <button
                onClick={fetchDiagnosticLogs}
                disabled={diagLogsLoading}
                className="text-[10px] text-coquette-accent hover:underline flex items-center gap-1 font-bold"
              >
                <RefreshCw className={`w-3 h-3 ${diagLogsLoading ? 'animate-spin' : ''}`} />
                <span>Làm mới log</span>
              </button>
            </div>

            <div className="space-y-2.5">
              <p className="text-[11px] text-slate-500 leading-relaxed text-left">
                Chỉ hiển thị cho Quản Trị Viên: Chi tiết hóa toàn bộ các cuộc gọi tới đầu cuối RioHub.vn bao gồm cả tham số truyền lên và phản hồi dạng chuỗi (JSON body) để loại trừ triệt để tình huống "Lỗi kết nối API" chung chung.
              </p>

              {diagnosticLogs.length === 0 ? (
                <div className="py-8 text-center text-gray-450 text-xs bg-gray-50 rounded-xl border border-dashed border-gray-200">
                  Chưa ghi nhận hoạt động API nào trong phiên làm việc hiện tại.
                </div>
              ) : (
                <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
                  {diagnosticLogs.map((log: any) => (
                    <div key={log.id} className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-[10px] text-slate-300 font-mono space-y-1.5 text-left">
                      <div className="flex justify-between items-center text-[9px] border-b border-slate-900 pb-1.5 mb-1.5">
                        <span className="bg-slate-850 px-1.5 py-0.5 rounded text-slate-400 font-bold">
                          {log.method}
                        </span>
                        <span className="text-gray-500">{new Date(log.time).toLocaleTimeString()}</span>
                      </div>
                      <p className="break-all text-slate-400">
                        <strong className="text-gray-500 font-bold">URL:</strong> {log.url}
                      </p>
                      <p className="break-all text-slate-400">
                        <strong className="text-gray-500 font-bold">Params/Query:</strong> {JSON.stringify(log.params)}
                      </p>
                      <div className="pt-1 select-all">
                        <p className="text-gray-500 font-bold flex items-center justify-between mb-1">
                          <span>Response Body:</span>
                          <span className={log.status >= 200 && log.status < 300 ? 'text-emerald-400 font-extrabold' : 'text-rose-400 font-extrabold'}>
                            HTTP status {log.status}
                          </span>
                        </p>
                        <pre className="text-[9px] text-cyan-300 whitespace-pre-wrap bg-slate-900/80 p-2 rounded border border-slate-800 break-all select-all max-h-[120px] overflow-y-auto">
                          {JSON.stringify(log.body, null, 2)}
                        </pre>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: TikTok Shop Status Widget & Reports (5 Cols) */}
        <div className="lg:col-span-5 space-y-5">
          
          {/* Brand New TikTok Shop Status Widget */}
          <div className="bg-white rounded-[24px] p-5 border border-coquette-deep shadow-xs space-y-4">
            <div className="pb-1.5 border-b border-gray-100 flex justify-between items-center">
              <h3 className="font-serif text-[13.5px] font-black text-gray-800 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-coquette-accent" />
                <span>TikTok Shop Status</span>
              </h3>
              <span className="text-[10px] font-mono text-gray-400 bg-gray-50 px-1.5 py-0.2 rounded border border-gray-100">Live Diagnostics</span>
            </div>

            {/* Custom line elements indicating diagnostic status */}
            <div className="space-y-2.5">
              
              {/* LINE 1: API Key */}
              <div className="flex justify-between items-center text-xs">
                <span className="text-gray-500 font-sans">API Key hợp lệ</span>
                <span>
                  {statusApiKey === 'success' ? (
                    <strong className="text-emerald-600 font-sans flex items-center gap-1">🟢 Hợp lệ</strong>
                  ) : statusApiKey === 'error' ? (
                    <strong className="text-rose-600 font-sans flex items-center gap-1">🔴 Không hợp lệ</strong>
                  ) : (
                    <span className="text-gray-400">⚪ Chưa kiểm tra</span>
                  )}
                </span>
              </div>

              {/* LINE 2: Creator Connection */}
              <div className="flex justify-between items-center text-xs">
                <span className="text-gray-500 font-sans">Creator kết nối</span>
                <span>
                  {statusCreator === 'success' ? (
                    <strong className="text-emerald-600 font-sans flex items-center gap-1">🟢 Creator kết nối</strong>
                  ) : statusCreator === 'error' ? (
                    <strong className="text-rose-600 font-sans flex items-center gap-1">🔴 Lỗi kết nối</strong>
                  ) : (
                    <span className="text-gray-400">⚪ Chưa kiểm tra</span>
                  )}
                </span>
              </div>

              {/* LINE 3: Link Gen Success */}
              <div className="flex justify-between items-center text-xs">
                <span className="text-gray-500 font-sans">Tạo link thành công</span>
                <span>
                  {statusLinkGen === 'success' ? (
                    <strong className="text-emerald-600 font-sans flex items-center gap-1">🟢 Tạo link thành công</strong>
                  ) : statusLinkGen === 'error' ? (
                    <strong className="text-rose-600 font-sans flex items-center gap-1">🔴 Thất bại</strong>
                  ) : (
                    <span className="text-gray-400">⚪ Chưa kiểm tra</span>
                  )}
                </span>
              </div>

              {/* LINE 4: Orders Sync Syncing */}
              <div className="flex justify-between items-center text-xs">
                <span className="text-gray-500 font-sans">Đồng bộ đơn hàng hoạt động</span>
                <span>
                  {statusOrdersSync === 'success' ? (
                    <strong className="text-emerald-600 font-sans flex items-center gap-1">🟢 Đồng bộ đơn hàng hoạt động</strong>
                  ) : statusOrdersSync === 'error' ? (
                    <strong className="text-rose-600 font-sans flex items-center gap-1">🔴 Ngừng hoạt động</strong>
                  ) : (
                    <span className="text-gray-400">⚪ Chưa kiểm tra</span>
                  )}
                </span>
              </div>

            </div>

            {/* Verdict summary badge when everything is green */}
            {statusApiKey === 'success' && statusCreator === 'success' && statusLinkGen === 'success' && statusOrdersSync === 'success' && (
              <div className="p-3 bg-emerald-50 border border-emerald-250 rounded-xl text-[11px] leading-relaxed font-sans space-y-1">
                <p className="font-extrabold text-emerald-800">✅ RioHub hoạt động</p>
                <div className="text-[10.5px] text-emerald-600 font-medium list-disc list-inside space-y-0.2 pl-1">
                  <p>✔ API Key đúng & Bảo mật</p>
                  <p>✔ Creator đúng sở hữu</p>
                  <p>✔ Tạo link rút gọn hoạt động</p>
                  <p>✔ Đồng bộ đơn hàng thông suốt</p>
                </div>
              </div>
            )}

            {/* Display last check time info */}
            <div className="pt-2 border-t border-dashed border-gray-100 flex justify-between items-center text-[10px] text-gray-400 font-mono">
              <span>Lần kiểm tra cuối:</span>
              <span className="font-bold text-gray-600">
                {lastCheckedTime ? lastCheckedTime : 'Chưa kiểm tra gần đây'}
              </span>
            </div>
          </div>

          {/* Sub Panels for listing connections' links and synchronized orders */}
          <div className="bg-white rounded-[24px] p-4 border border-coquette-deep shadow-xs space-y-3.5">
            
            {/* Inner navigation */}
            <div className="flex gap-1 p-0.5 bg-gray-100 rounded-xl border border-gray-200/50">
              <button
                onClick={() => setReportTab('links')}
                style={{ cursor: 'pointer' }}
                className={`flex-1 text-center py-1.5 text-[10px] font-bold rounded-lg transition-all ${
                  reportTab === 'links' ? 'bg-white text-coquette-accent shadow-3xs' : 'text-gray-500 hover:text-gray-800'
                }`}
              >
                Link 📝
              </button>
              <button
                onClick={() => setReportTab('orders')}
                style={{ cursor: 'pointer' }}
                className={`flex-1 text-center py-1.5 text-[10px] font-bold rounded-lg transition-all ${
                  reportTab === 'orders' ? 'bg-white text-coquette-accent shadow-3xs' : 'text-gray-500 hover:text-gray-800'
                }`}
              >
                Đơn 📦
              </button>
              <button
                onClick={() => setReportTab('webhook')}
                style={{ cursor: 'pointer' }}
                className={`flex-1 text-center py-1.5 text-[10px] font-bold rounded-lg transition-all ${
                  reportTab === 'webhook' ? 'bg-white text-rose-600 shadow-3xs' : 'text-gray-500 hover:text-gray-800'
                }`}
              >
                Webhook 🔗
              </button>
            </div>

            {/* TAB REPORT CONTENT: LINKS HISTORY */}
            {reportTab === 'links' && (
              <div className="space-y-2.5">
                {linksLoading ? (
                  <div className="py-5 text-center text-[10.5px] text-gray-400 font-mono">Đang đồng bộ link...</div>
                ) : linksList.length === 0 ? (
                  <div className="py-6 text-center text-red-300 text-[10px] font-medium font-sans">Chưa có link nào được đồng bộ.</div>
                ) : (
                  <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
                    {linksList.map((l, index) => (
                      <div key={index} className="p-2.5 bg-coquette-cream rounded-xl border border-gray-100 text-[10px] space-y-1">
                        <div className="flex justify-between text-[9px] text-gray-400">
                          <span>{new Date(l.created_at).toLocaleString('vi-VN')}</span>
                          <span className="font-bold text-coquette-accent">PID: {l.product_id}</span>
                        </div>
                        <div className="truncate text-gray-600 font-mono">Gốc: {l.original_link}</div>
                        <div className="flex justify-between items-center pt-1 border-t border-dashed border-gray-100 font-sans">
                          <span className="font-extrabold text-emerald-600">Sub: {l.sub_id}</span>
                          <a href={l.affiliate_link} target="_blank" rel="noreferrer" className="text-coquette-accent font-bold hover:underline">Link rút gọn 🔗</a>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB REPORT CONTENT: ORDERS SYNCHRONIZATION */}
            {reportTab === 'orders' && (
              <div className="space-y-2.5">
                {ordersLoading ? (
                  <div className="py-5 text-center text-[10.5px] text-gray-400 font-mono">Đang đồng bộ đơn hàng...</div>
                ) : ordersList.length === 0 ? (
                  <div className="py-6 text-center text-red-300 text-[10px] font-medium font-sans">Chưa đồng bộ được đơn hàng nào.</div>
                ) : (
                  <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
                    {ordersList.map((o, index) => (
                      <div key={index} className="p-2.5 bg-coquette-cream rounded-xl border border-gray-100 text-[10px] space-y-1">
                        <div className="flex justify-between text-[9px] text-gray-400 font-mono">
                          <span>#{o.order_id}</span>
                          <span className={`px-1 rounded font-bold ${
                            o.status === 'completed' || o.status === 'approved' ? 'bg-emerald-50 text-emerald-600' :
                            o.status === 'cancelled' ? 'bg-rose-50 text-rose-600' : 'bg-amber-50 text-amber-600'
                          }`}>{o.status}</span>
                        </div>
                        <div className="truncate font-bold text-gray-700 font-sans">{o.product_name}</div>
                        <div className="flex justify-between items-center text-[10px] font-sans">
                          <span className="text-gray-400 font-mono">Dòng: {o.sub_id}</span>
                          <strong className="text-rose-600">+{o.commission.toLocaleString('vi-VN')}đ</strong>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB REPORT CONTENT: WEBHOOK STATUS */}
            {reportTab === 'webhook' && (
              <div className="space-y-3.5 text-xs animate-in fade-in duration-200">
                {webhookLoading && !webhookStats && (
                  <div className="py-5 text-center text-[10.5px] text-gray-400 font-mono flex items-center justify-center gap-1.5">
                    <RefreshCw className="w-4 h-4 animate-spin text-rose-600" />
                    <span>Đang tải thông tin webhook...</span>
                  </div>
                )}

                <div className="flex justify-between items-center bg-gray-50 p-2.5 rounded-xl border border-gray-150">
                  <span className="text-[11px] font-sans text-gray-500 font-semibold">Cấu hình bảo mật:</span>
                  <span className={`text-[10.5px] font-bold px-2 py-0.5 rounded-full inline-flex items-center gap-0.5 ${
                    hasSigningSecret 
                      ? 'bg-emerald-100 text-emerald-800' 
                      : 'bg-rose-100 text-rose-800'
                  }`}>
                    {hasSigningSecret ? '🟢 Webhook bảo mật' : '🔴 Chưa lưu Signing Secret'}
                  </span>
                </div>

                <div className="space-y-1.5">
                  <div className="flex justify-between items-center">
                    <span className="text-[11px] font-bold text-gray-600">URL Webhook nhận đơn:</span>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText('https://cashback.thuydeal.site/api/riohub/webhook');
                        alert('Đã copy URL chính thức! 📋');
                      }}
                      className="text-[10px] text-rose-600 font-bold hover:underline cursor-pointer"
                    >
                      Copy 📋
                    </button>
                  </div>
                  <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex flex-col justify-between items-start gap-1">
                    <code className="text-[10px] font-mono text-cyan-300 break-all select-all font-semibold leading-normal w-full">
                      https://cashback.thuydeal.site/api/riohub/webhook
                    </code>
                    <span className="text-[9.5px] text-slate-400 font-sans italic mt-1 leading-relaxed">
                      * Cấu hình Callback URL này trên RioHub để tự động hứng các webhook và lưu đơn hàng!
                    </span>
                  </div>
                </div>

                {webhookStats && (
                  <div className="space-y-2 text-[11px]">
                    <div className="grid grid-cols-2 gap-2 text-center">
                      <div className="bg-gray-50/70 p-2 rounded-xl border border-gray-150 flex flex-col justify-center">
                        <span className="text-[9px] text-gray-400 font-bold uppercase">Tổng đơn nhận</span>
                        <span className="text-sm font-extrabold text-gray-800 font-mono mt-0.5">
                          {webhookStats.totalOrdersStored || 0}
                        </span>
                      </div>
                      <div className="bg-gray-50/70 p-2 rounded-xl border border-gray-150 flex flex-col justify-center">
                        <span className="text-[9px] text-gray-400 font-bold uppercase">Webhook Calls</span>
                        <span className="text-sm font-extrabold text-gray-800 font-mono mt-0.5">
                          {webhookStats.receivedCount || 0}
                        </span>
                      </div>
                    </div>

                    <div className="flex justify-between items-center text-[10.5px] pt-1.5">
                      <span className="text-gray-400">Lần nhận gói cuối:</span>
                      <strong className="text-gray-700 font-mono">
                        {webhookStats.lastReceivedAt 
                          ? new Date(webhookStats.lastReceivedAt).toLocaleString('vi-VN') 
                          : 'Chưa có cuộc gọi nào'}
                      </strong>
                    </div>

                    <div className="pt-2">
                      <span className="text-[11px] font-bold text-gray-600 block mb-1.5 flex justify-between items-center font-sans">
                        <span>Nhật ký Webhook nhận gần đây:</span>
                        <button 
                          onClick={fetchWebhookStats}
                          className="text-[10px] text-rose-600 font-bold hover:underline cursor-pointer flex items-center gap-0.5 font-sans"
                        >
                          <RefreshCw className="w-2.5 h-2.5" /> Nạp lại
                        </button>
                      </span>

                      {(!webhookStats.logs || webhookStats.logs.length === 0) ? (
                        <div className="p-3 bg-gray-50 rounded-xl border border-dashed border-gray-200 text-center text-gray-400 text-[10px] leading-relaxed font-sans">
                          Chưa có log webhook hoạt động. Hãy cấu hình payload trên RioHub để bắt đầu đối soát đơn hàng TikTok Shop tự động!
                        </div>
                      ) : (
                        <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                          {webhookStats.logs.map((log: any) => (
                            <div key={log.id} className="p-2 bg-slate-900 border border-slate-800 text-[9.5px] font-mono text-gray-300 rounded-lg space-y-1 leading-normal text-left">
                              <div className="flex justify-between text-[8px] text-gray-500">
                                <span>{new Date(log.timestamp).toLocaleTimeString('vi-VN')} (event: {log.event})</span>
                                <span className={
                                  log.status === 'completed' ? 'text-emerald-400 font-bold' :
                                  log.status === 'cancelled' ? 'text-rose-400 font-bold' : 'text-amber-400 font-bold'
                                }>
                                  {log.status === 'completed' ? 'DUYỆT 🟢' : log.status === 'cancelled' ? 'HUỶ 🔴' : 'CHỜ 🟡'}
                                </span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-cyan-400 font-bold">#O: {log.order_id}</span>
                                <span className="text-pink-400">c: {log.sub_id || 'untracked'}</span>
                              </div>
                              <div className="flex justify-between text-[8.5px] pt-0.5 text-slate-400">
                                <span>Hoa hồng: +{log.commission?.toLocaleString('vi-VN')}đ</span>
                                <span>{log.elapsedMs}ms</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

          </div>

        </div>

      </div>

    </div>
  );
}
