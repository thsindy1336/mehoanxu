import React, { useState } from 'react';
import { Gift, Search, AlertCircle, CheckCircle, Ticket, Compass, ArrowRight, ShieldAlert, Sparkles } from 'lucide-react';
import { User, Voucher, Order, SupportTicket, InternalNotification } from '../types';
import { getVouchers, saveVouchers, getOrders, saveOrders, getUsers, saveUsers, getSupportTickets, saveSupportTickets, getInternalNotifications, saveInternalNotifications } from '../data';

interface UtilitiesViewProps {
  currentUser: User | null;
  onOpenAuthModal: () => void;
  // Cho phép chuyển tab nhanh bằng callback
  initialSubTab?: 'vouchers' | 'lost_order' | 'tutorial' | 'conditions';
}

export default function UtilitiesView({ currentUser, onOpenAuthModal, initialSubTab = 'vouchers' }: UtilitiesViewProps) {
  const [subTab, setSubTab] = useState<'vouchers' | 'lost_order' | 'tutorial' | 'conditions' | 'support'>(initialSubTab as any);

  // States Tìm đơn thất lạc
  const [orderIdInput, setOrderIdInput] = useState('');
  const [lostPlatform, setLostPlatform] = useState<'Shopee' | 'TikTok'>('Shopee');
  const [hasPassed48H, setHasPassed48H] = useState(false);
  const [lostMsg, setLostMsg] = useState<{ type: 'success' | 'error' | ''; txt: string }>({ type: '', txt: '' });

  // States Đổi Voucher
  const [vouchers, setVouchers] = useState<Voucher[]>(getVouchers());
  const [redeemedCodeShow, setRedeemedCodeShow] = useState<string | null>(null);

  // States Gửi Hỗ Trợ (Ticket)
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [ticketTitle, setTicketTitle] = useState('');
  const [ticketContent, setTicketContent] = useState('');
  const [ticketCategory, setTicketCategory] = useState<'lost_order' | 'withdraw' | 'other'>('other');
  const [ticketPlatform, setTicketPlatform] = useState<'shopee' | 'tiktok'>('shopee');
  const [ticketMsg, setTicketMsg] = useState('');

  React.useEffect(() => {
    if (currentUser) {
      setTickets(getSupportTickets().filter(t => t.username === currentUser.username));
    }
  }, [currentUser, subTab]);

  const handleCreateTicket = (e: React.FormEvent) => {
    e.preventDefault();
    setTicketMsg('');

    if (!currentUser) {
      onOpenAuthModal();
      return;
    }

    if (!ticketTitle.trim() || !ticketContent.trim()) {
      setTicketMsg('⚠️ Vui lòng nhập đầy đủ tiêu đề và nội dung yêu cầu hỗ trợ.');
      return;
    }

    const allTickets = getSupportTickets();
    const newTk: SupportTicket = {
      id: 'tk_' + Date.now(),
      username: currentUser.username,
      title: ticketTitle.trim(),
      content: ticketContent.trim(),
      category: ticketCategory,
      status: 'pending',
      createdAt: new Date().toISOString(),
      platform: ticketPlatform
    };

    allTickets.unshift(newTk);
    saveSupportTickets(allTickets);
    setTickets([newTk, ...tickets]);

    setTicketTitle('');
    setTicketContent('');
    setTicketMsg('🎉 Gửi Ticket hỗ trợ thành công! Ban quản trị đã được thông báo và sẽ trả lời bạn sớm nhất.');
    if (typeof (window as any).showToast === 'function') {
      (window as any).showToast('✅ Gửi ticket hỗ trợ thành công', 'success');
    }
  };

  // Xử lý Tìm đơn thất lạc
  const handleLostOrderSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setLostMsg({ type: '', txt: '' });

    if (!currentUser) {
      onOpenAuthModal();
      return;
    }

    if (!orderIdInput.trim()) {
      setLostMsg({ type: 'error', txt: `Vui lòng nhập mã đơn hàng ${lostPlatform} cần tra soát.` });
      return;
    }

    if (!hasPassed48H) {
      setLostMsg({
        type: 'error',
        txt: `⚠️ Điều kiện: Chỉ có thể tra soát tìm đơn thất lạc sau 48 giờ kể từ khi đặt hàng trên ${lostPlatform} để đối tác có thời gian ghi nhận. Vui lòng thử lại sau.`
      });
      return;
    }

    const trimmedOrderId = orderIdInput.trim();
    const orders = getOrders();
    // Đơn hàng khớp mã
    const matchIndex = orders.findIndex(o => o.orderId === trimmedOrderId);

    // Tạo tự động Support Ticket
    const tickets = getSupportTickets();
    const newTicket: SupportTicket = {
      id: 'tk_lost_' + Date.now(),
      username: currentUser.username,
      title: `Tra soát mất đơn ${lostPlatform} #${trimmedOrderId}`,
      content: `Yêu cầu tra soát tự động cho đơn hàng ${lostPlatform} #${trimmedOrderId}.\nMua hàng vào lúc: ${new Date().toLocaleDateString('vi-VN')}. Trạng thái đơn được yêu cầu: Mất Đơn Thất Lạc. Nền tảng: ${lostPlatform}.`,
      category: 'lost_order',
      status: 'pending',
      createdAt: new Date().toISOString(),
      platform: lostPlatform.toLowerCase() === 'tiktok' ? 'tiktok' : 'shopee'
    };
    tickets.unshift(newTicket);
    saveSupportTickets(tickets);

    const platformVal = lostPlatform.toLowerCase() === 'tiktok' ? 'tiktok' : 'shopee';

    if (matchIndex >= 0) {
      const matchedOrder = orders[matchIndex];
      
      // Nếu đã thuộc về người khác
      if (matchedOrder.username && matchedOrder.username !== currentUser.username) {
        setLostMsg({
          type: 'error',
          txt: 'Mã đơn hàng này đã được đăng ký và đối soát bởi một tài khoản khác trên hệ thống. Xin vui lòng kiểm tra lại.'
        });
        return;
      }

      // Tạo yêu cầu tra soát thành công
      matchedOrder.username = currentUser.username;
      matchedOrder.isLostClaim = true;
      matchedOrder.platform = platformVal;
      matchedOrder.lostClaimNote = `Tra soát thất lạc ${lostPlatform} bởi @${currentUser.username} vào ${new Date().toLocaleDateString('vi-VN')}`;
      if (matchedOrder.status === 'pending_record') {
        matchedOrder.status = 'pending_approve'; // Kích hoạt trạng thái chờ duyệt để admin chú ý xử lý
      }
      saveOrders(orders);

      setLostMsg({
        type: 'success',
        txt: `Yêu cầu tra soát đơn ${lostPlatform} của bạn đã được gửi thành công. Admin sẽ kiểm tra và cộng xu trong vòng 24-48 giờ.`
      });
      if (typeof (window as any).showToast === 'function') {
        (window as any).showToast('✅ Gửi yêu cầu tra soát thành công', 'success');
      }
    } else {
      // Đơn chưa hề có trong click logs
      // Ghi nhận đơn mới cho user rồi gắn cờ thất lạc
      const newOrder: Order = {
        orderId: trimmedOrderId,
        username: currentUser.username,
        time: new Date().toISOString(),
        rebateAmount: 0,
        rawCommission: 0,
        status: 'pending_approve',
        productName: `Đơn tra soát thất lạc ${lostPlatform}`,
        platform: platformVal,
        isLostClaim: true,
        lostClaimNote: `Đơn tự khai báo tra soát ${lostPlatform} sau 48h`
      };
      orders.unshift(newOrder);
      saveOrders(orders);

      setLostMsg({
        type: 'success',
        txt: `Yêu cầu tra soát đơn ${lostPlatform} của bạn đã được gửi thành công. Admin sẽ kiểm tra và cộng xu trong vòng 24-48 giờ.`
      });
      if (typeof (window as any).showToast === 'function') {
        (window as any).showToast('✅ Gửi yêu cầu tra soát thành công', 'success');
      }
    }
  };

  // Đổi voucher
  const handleRedeemVoucher = (voucher: Voucher) => {
    setRedeemedCodeShow(null);
    if (!currentUser) {
      onOpenAuthModal();
      return;
    }

    // Giá quy đổi: 1 VNĐ hoàn tiền = 1 điểm.
    const userPoints = currentUser.availableBalance;
    if (userPoints < voucher.costPoints) {
      alert(`⚠️ Số dư khả dụng của bạn không đủ (${userPoints.toLocaleString('vi-VN')} điểm). Bạn cần tích lũy thêm tối thiểu ${(voucher.costPoints - userPoints).toLocaleString('vi-VN')} điểm nữa để đổi voucher nha.`);
      return;
    }

    // Xác nhận đổi
    const confirmRedeem = window.confirm(`Bạn có đồng ý dùng ${voucher.costPoints.toLocaleString('vi-VN')} điểm (tương đương ${voucher.costPoints.toLocaleString('vi-VN')}đ tiền khả dụng) để đổi lấy "${voucher.title}" không?`);
    if (!confirmRedeem) return;

    // Trừ điểm/tiền ví
    const users = getUsers();
    const userIndex = users.findIndex(u => u.username === currentUser.username);
    if (userIndex >= 0) {
      users[userIndex].availableBalance -= voucher.costPoints;
      saveUsers(users);
      
      currentUser.availableBalance -= voucher.costPoints;
    }

    // Đánh dấu voucher đã đổi
    const updatedVouchers = getVouchers().map(v => {
      if (v.id === voucher.id) {
        return {
          ...v,
          redeemedBy: currentUser.username,
          redeemedAt: new Date().toISOString()
        };
      }
      return v;
    });
    saveVouchers(updatedVouchers);
    setVouchers(updatedVouchers);

    // Kích hoạt hiển thị code
    setRedeemedCodeShow(voucher.code);
  };

  return (
    <div className="space-y-6">
      
      {/* Category selector */}
      <div className="flex flex-wrap gap-1 p-1 bg-coquette-cream rounded-2xl">
        <button
          onClick={() => { setSubTab('vouchers'); setRedeemedCodeShow(null); setLostMsg({ type: '', txt: '' }); }}
          className={`flex-1 min-w-[70px] text-center py-2 rounded-xl text-[10.5px] font-bold cursor-pointer transition-all ${
            subTab === 'vouchers'
              ? 'bg-coquette-accent text-white shadow-xs'
              : 'text-gray-500 hover:text-coquette-accent'
          }`}
        >
          🎁 Voucher
        </button>
        
        <button
          onClick={() => { setSubTab('lost_order'); setRedeemedCodeShow(null); setLostMsg({ type: '', txt: '' }); }}
          className={`flex-1 min-w-[70px] text-center py-2 rounded-xl text-[10.5px] font-bold cursor-pointer transition-all ${
            subTab === 'lost_order'
              ? 'bg-coquette-accent text-white shadow-xs'
              : 'text-gray-500 hover:text-coquette-accent'
          }`}
        >
          🔍 Mất Đơn
        </button>

        <button
          onClick={() => { setSubTab('support'); setRedeemedCodeShow(null); setLostMsg({ type: '', txt: '' }); }}
          className={`flex-1 min-w-[70px] text-center py-2 rounded-xl text-[10.5px] font-bold cursor-pointer transition-all ${
            subTab === 'support'
              ? 'bg-coquette-accent text-white shadow-xs'
              : 'text-gray-500 hover:text-coquette-accent'
          }`}
        >
          💬 Hỗ Trợ
        </button>

        <button
          onClick={() => { setSubTab('tutorial'); setRedeemedCodeShow(null); setLostMsg({ type: '', txt: '' }); }}
          className={`flex-1 min-w-[70px] text-center py-2 rounded-xl text-[10.5px] font-bold cursor-pointer transition-all ${
            subTab === 'tutorial'
              ? 'bg-coquette-accent text-white shadow-xs'
              : 'text-gray-500 hover:text-coquette-accent'
          }`}
        >
          📖 Hướng Dẫn
        </button>

        <button
          onClick={() => { setSubTab('conditions'); setRedeemedCodeShow(null); setLostMsg({ type: '', txt: '' }); }}
          className={`flex-1 min-w-[70px] text-center py-2 rounded-xl text-[10.5px] font-bold cursor-pointer transition-all ${
            subTab === 'conditions'
              ? 'bg-coquette-accent text-white shadow-xs'
              : 'text-gray-500 hover:text-coquette-accent'
          }`}
        >
          🛡️ Quy Định
        </button>
      </div>

      {/* VOUCHERS SUB VIEW */}
      {subTab === 'vouchers' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          <div className="text-center space-y-1 py-1">
            <h3 className="font-serif text-lg font-bold text-gray-800 flex items-center justify-center gap-1">
              <span>Kho Voucher Đổi Thưởng</span>
              <span className="text-coquette-accent">🎁</span>
            </h3>
            <p className="text-[11px] text-gray-400">1đ hoàn tiền tích lũy ví = 1 điểm đổi voucher mua sắm cực sốc</p>
          </div>

          {/* Quick code notification if redeemed */}
          {redeemedCodeShow && (
            <div className="bg-gradient-to-r from-emerald-500/5 to-emerald-500/10 p-4 border-2 border-emerald-300 rounded-3xl text-center space-y-3.5 shadow-sm animate-in zoom-in duration-200">
              <span className="text-2xl block">🎉 🎀</span>
              <div className="space-y-1">
                <span className="text-xs font-bold text-emerald-800 block">Đổi Quà Thành Công!</span>
                <p className="text-[10px] text-gray-500">Mã ưu đãi độc quyền của bạn trên Shopee:</p>
                <div className="bg-white px-4 py-2 border border-emerald-200 inline-block rounded-xl font-mono text-sm font-black text-emerald-700 tracking-wider shadow-2xs">
                  {redeemedCodeShow}
                </div>
              </div>
              <p className="text-[9px] text-emerald-600/80">Bạn vui lòng sao chép mã và dán vào ô Khuyến Mãi lúc thanh toán đơn trên Shopee nhé.</p>
              <button
                onClick={() => setRedeemedCodeShow(null)}
                className="text-[10px] font-bold text-emerald-700 underline"
              >
                Đóng thông báo
              </button>
            </div>
          )}

          {/* Vouchers lists */}
          <div className="space-y-3">
            {vouchers.map((v) => {
              const isRedeemedByMe = v.redeemedBy === currentUser?.username;
              const isRedeemedByOther = v.redeemedBy && v.redeemedBy !== currentUser?.username;

              return (
                <div 
                  key={v.id} 
                  className={`bg-white rounded-2xl border flex overflow-hidden items-stretch relative transition-all ${
                    v.redeemedBy ? 'opacity-70 border-gray-100' : 'border-coquette-deep/40 hover:border-coquette-accent'
                  }`}
                >
                  {/* Left Side Tag indicator */}
                  <div className={`w-20 shrink-0 p-3 text-center flex flex-col justify-center items-center relative border-r border-dashed ${
                    v.redeemedBy ? 'bg-gray-100 text-gray-400 border-gray-200' : 'bg-coquette-pink/40 text-coquette-accent border-coquette-deep/30'
                  }`}>
                    {/* Tiny bows */}
                    <span className="text-lg mb-1">{v.redeemedBy ? '🎟️' : '🎀'}</span>
                    <span className="font-mono text-xs font-black">{v.discountValue >= 10000 ? `${v.discountValue/1000}K` : v.discountValue}</span>
                    <span className="text-[8px] uppercase tracking-wider font-bold">SALE</span>
                  </div>

                  {/* Right Side Content details */}
                  <div className="p-3.5 flex-1 flex flex-col justify-between space-y-2 text-xs">
                    <div className="space-y-1">
                      <span className="font-bold text-gray-800 block text-[11.5px] leading-snug">{v.title}</span>
                      <div className="flex gap-2 text-[9px] text-gray-400 font-mono">
                        <span>Giá: <strong className="text-coquette-accent font-bold font-sans">{v.costPoints.toLocaleString('vi-VN')} điểm</strong></span>
                        <span>Hạn dùng: {v.expiryDate}</span>
                      </div>
                    </div>

                    {/* Submit Button */}
                    <div className="text-right">
                      {isRedeemedByMe ? (
                        <div className="space-y-1">
                          <span className="inline-block bg-emerald-50 text-emerald-700 font-bold px-2.5 py-1 rounded text-[9.5px]">Đã đổi</span>
                          <span className="block text-[8px] font-mono text-gray-400">{v.code}</span>
                        </div>
                      ) : isRedeemedByOther ? (
                        <span className="inline-block bg-gray-100 text-gray-400 font-bold px-2.5 py-1 rounded text-[9.5px]">Bạn khác đổi hết</span>
                      ) : (
                        <button
                          onClick={() => handleRedeemVoucher(v)}
                          className="bg-coquette-accent hover:bg-coquette-accent/90 text-white font-bold px-4 py-1.5 rounded-lg text-[10.5px] cursor-pointer transition-all active:scale-95 shadow-3xs"
                        >
                          Đổi code
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* LOST ORDER CLAIM SUB VIEW */}
      {subTab === 'lost_order' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          <div className="text-center space-y-1 py-1">
            <h3 className="font-serif text-lg font-bold text-gray-800 flex items-center justify-center gap-1">
              <span>Đại Đối Soát Tìm Đơn Thất Lạc</span>
              <span className="text-rose-500">🔍</span>
            </h3>
            <p className="text-[11px] text-gray-400">Nếu đặt hàng quá 48 giờ mà chưa thấy ghi nhận vui lòng tra soát</p>
          </div>

          <div className="bg-white rounded-3xl p-5 border border-coquette-deep/40 shadow-xs space-y-4">
            {/* Platform Selection */}
            <div className="space-y-1.5 text-left">
              <label className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">Chọn nền tảng mua sắm:</label>
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => {
                    setLostPlatform('Shopee');
                    setLostMsg({ type: '', txt: '' });
                  }}
                  className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-2xl text-xs font-bold transition-all border cursor-pointer active:scale-95 ${
                    lostPlatform === 'Shopee'
                      ? 'bg-orange-50 text-orange-600 border-orange-200 shadow-2xs'
                      : 'bg-gray-50/50 text-gray-500 border-gray-150 hover:bg-gray-50'
                  }`}
                >
                  <span className="text-sm">🧡</span>
                  <span>Shopee</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setLostPlatform('TikTok');
                    setLostMsg({ type: '', txt: '' });
                  }}
                  className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-2xl text-xs font-bold transition-all border cursor-pointer active:scale-95 ${
                    lostPlatform === 'TikTok'
                      ? 'bg-stone-50 text-stone-850 border-stone-250 shadow-2xs'
                      : 'bg-gray-50/50 text-gray-500 border-gray-150 hover:bg-gray-50'
                  }`}
                >
                  <span className="text-sm">🖤</span>
                  <span>TikTok Shop</span>
                </button>
              </div>
            </div>

            <form onSubmit={handleLostOrderSearch} className="space-y-4">
              {lostPlatform === 'Shopee' ? (
                <div className="space-y-1.5 text-left">
                  <label className="text-[11px] font-bold text-gray-700 block">Mã đơn hàng Shopee của bạn <span className="text-red-500">*</span></label>
                  <input
                    type="text"
                    required
                    value={orderIdInput}
                    onChange={(e) => setOrderIdInput(e.target.value)}
                    placeholder="Ví dụ: 849204892408 (Copy chuẩn ở đơn mua Shopee)"
                    className="w-full text-xs px-3.5 py-2.5 bg-coquette-cream/30 focus:bg-white border border-coquette-deep/40 rounded-xl outline-hidden focus:border-coquette-accent transition-all text-gray-700 font-mono"
                  />
                </div>
              ) : (
                <div className="space-y-1.5 text-left">
                  <label className="text-[11px] font-bold text-gray-700 block">Mã đơn hàng TikTok Shop của bạn <span className="text-red-500">*</span></label>
                  <input
                    type="text"
                    required
                    value={orderIdInput}
                    onChange={(e) => setOrderIdInput(e.target.value)}
                    placeholder="Nhập mã đơn hàng TikTok (gồm 19 chữ số)..."
                    className="w-full text-xs px-3.5 py-2.5 bg-coquette-cream/30 focus:bg-white border border-coquette-deep/40 rounded-xl outline-hidden focus:border-coquette-accent transition-all text-gray-700 font-mono"
                  />
                </div>
              )}

              {/* Requirement Checkbox for 48h to demonstrate actual rules */}
              <div className="flex items-start gap-2 bg-rose-50/50 p-3 rounded-xl border border-rose-200/50 text-left">
                <input
                  type="checkbox"
                  id="chk48"
                  checked={hasPassed48H}
                  onChange={(e) => setHasPassed48H(e.target.checked)}
                  className="mt-0.5"
                />
                <label htmlFor="chk48" className="text-[10px] text-gray-600 leading-relaxed cursor-pointer select-none">
                  Tôi xác nhận đơn hàng <strong className="font-bold">{lostPlatform}</strong> này đã được đặt <strong className="text-red-600 font-bold">quá 48 giờ</strong> so với hiện tại.
                </label>
              </div>

              {lostMsg.txt && (
                <div className={`p-3.5 rounded-xl border text-[10.5px] leading-relaxed flex items-start gap-1.5 text-left ${
                  lostMsg.type === 'success'
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    : 'bg-red-50 text-red-600 border-red-200'
                }`}>
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600" />
                  <span>{lostMsg.txt}</span>
                </div>
              )}

              <button
                type="submit"
                className="w-full bg-coquette-accent hover:bg-coquette-accent/90 text-white font-bold text-xs py-3 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1"
              >
                <span>Yêu Cầu Tra Soát Đơn Thất Lạc 🎀</span>
              </button>
            </form>
          </div>

          <div className="bg-orange-50/40 p-4 rounded-xl border border-orange-200 text-[10.5px] text-gray-600 leading-relaxed space-y-1.5">
            <span className="font-bold text-orange-600 block">💡 Vì sao đơn hàng bị Thất Lạc hoặc Mất Hoàn Tiền?</span>
            <ul className="list-disc pl-4 space-y-0.5 text-gray-500">
              <li>Bạn mua hàng từ kịch bản giỏ Live, Video hay kênh livestream khác.</li>
              <li>Bạn click nhầm liên kết của các KOL, KOC khác ngay trước khi đặt hàng.</li>
              <li>Mã giảm giá bạn sử dụng bị vi phạm điều kiện chiết khấu Affiliate của Shopee.</li>
              <li>Tính năng cookies bảo vệ bị kẹt hoặc quá hạn 30 phút.</li>
            </ul>
          </div>
        </div>
      )}

      {/* TUTORIALS SUB VIEW */}
      {subTab === 'tutorial' && (
        <div className="space-y-4 animate-in fade-in duration-200 text-xs">
          <div className="bg-white rounded-3xl p-5 border border-coquette-deep/40 shadow-xs space-y-3.5">
            <h4 className="font-serif text-sm font-bold text-coquette-accent pb-1 border-b border-dashed border-coquette-deep/20">👉 Hướng Dẫn Mua Hàng Chuẩn</h4>
            <div className="space-y-2.5 text-gray-600 leading-relaxed">
              <p>Mê Hoàn Xu xin giải đáp quy trình mua sắm tối ưu cookies giúp ghi nhận hoàn tiền tới 100%:</p>
              <ol className="list-decimal pl-4 space-y-1 text-gray-500">
                <li>Vào Shopee chọn sản phẩm, lưu ý không nhấp bất kì liên kết ngoại nào.</li>
                <li>Copy đường dẫn bằng nút "Chia Sẻ" ➔ "Sao chép liên kết" ở trang SP.</li>
                <li>Mở <strong className="text-coquette-accent">Mê Hoàn Xu</strong>, dán link vào ô tạo và chọn "Mua hàng".</li>
                <li>Nhấp liên kết ngắn đã tạo để định hướng mở thẳng App Shopee gốc trên điện thoại.</li>
                <li>Thêm SP vào giỏ và hoàn tất thanh toán trong vòng tối đa 30 phút.</li>
              </ol>
            </div>
          </div>

          <div className="bg-white rounded-3xl p-5 border border-coquette-deep/40 shadow-xs space-y-3.5">
            <h4 className="font-serif text-sm font-bold text-coquette-accent pb-1 border-b border-dashed border-coquette-deep/20">👛 Hướng Dẫn Nhận Tiền Hoàn Ví</h4>
            <div className="space-y-2.5 text-gray-600 leading-relaxed">
              <p>Quy trình thẩm định và đối soát của hệ thống hoạt động như thế nào?</p>
              <ul className="list-disc pl-4 space-y-1 text-gray-500">
                <li><strong className="text-gray-700">Bước 1:</strong> Sau khi mua hàng 24h - 48h, đơn hàng xuất hiện ở trạng thái "Chờ Duyệt" trong ví của bạn.</li>
                <li><strong className="text-gray-700">Bước 2:</strong> Shopee thường sẽ gửi đối soát và thanh toán hoa hồng định kỳ hàng tuần/tháng.</li>
                <li><strong className="text-gray-700">Bước 3:</strong> Ngay sau khi Admin cập nhật file báo cáo Shopee lên hệ thống, hoa hồng tương ứng sẽ tự động chuyển từ trạng thái "Chờ Duyệt" sang "Số Dư Khả Dụng".</li>
                <li><strong className="text-gray-700">Bước 4:</strong> Bạn có thể điền thông tin tài khoản rút tiền ngay lập tức khi số khả dụng đạt trên 10.000đ.</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* T&C CONDITIONS SUB VIEW */}
      {subTab === 'conditions' && (
        <div className="space-y-4 animate-in fade-in duration-200 text-xs text-gray-600 leading-relaxed">
          <div className="bg-white rounded-3xl p-5 border border-coquette-deep/40 shadow-xs space-y-3">
            <h4 className="font-serif text-sm font-bold text-emerald-800 pb-1 border-b border-dashed border-emerald-200">✅ Điều Kiện Tạo & Chấp Nhận Hoàn Tiền</h4>
            <ul className="list-disc pl-4 space-y-1.5 text-gray-500">
              <li>Hoàn tất giao dịch bàn giao thành công, không phát ra trường hợp trả hàng hoặc hoàn tiền từ phía người mua.</li>
              <li>Sử dụng liên kết s.shopee.vn rút gọn trung chuyển được sinh độc quyền bởi Mê Hoàn Xu.</li>
              <li>Thanh toán trực tuyến hoặc COD trong vòng thời gian hạn mức.</li>
              <li>Không xem thêm video/livestream của bất kỳ tài khoản Shopee nào khác trong quá trình từ lúc nhấn link Mê Hoàn Xu đến lúc thanh toán.</li>
            </ul>
          </div>

          <div className="bg-white rounded-3xl p-5 border border-coquette-deep/40 shadow-xs space-y-3">
            <h4 className="font-serif text-sm font-bold text-rose-800 pb-1 border-b border-dashed border-rose-200">❌ Trường Hợp Bị Từ Chối Hoàn Tiền</h4>
            <ul className="list-disc pl-4 space-y-1.5 text-gray-500">
              <li>Đơn hàng giả mạo, đầu cơ ôm số lượng lớn bán lại (gian lận thương mại).</li>
              <li>Tự bùng hàng, huỷ thanh toán sau khi nhận, không nhận bưu phẩm (boom hàng).</li>
              <li>Phát sinh do click chéo các liên kết KOL/KOC khác được lưu cookie sau liên kết rác.</li>
              <li>Nhiều tài khoản người dùng đăng ký ảo cùng một địa chỉ IP hay đăng nhập cùng một dòng máy bất thường để trục lợi điểm và voucher.</li>
              <li>Người dùng tự tạo link affiliate chéo nhau để lấy hoa hồng của chính mình qua shop ảo.</li>
            </ul>
          </div>
        </div>
      )}

      {/* SUPPORT TICKETS SUB VIEW */}
      {subTab === 'support' && (
        <div className="space-y-5 animate-in fade-in duration-200 text-xs">
          <div className="text-center space-y-1 py-1">
            <h3 className="font-serif text-lg font-bold text-gray-800 flex items-center justify-center gap-1.5">
              <span>Trung Tâm Hỗ Trợ Khách Hàng</span>
              <span className="text-coquette-accent">💬</span>
            </h3>
            <p className="text-[11px] text-gray-400">Gửi thắc mắc, yêu cầu soát đơn hoặc phản ảnh lỗi rút tiền đến Admin</p>
          </div>

          {/* Create new Ticket Form */}
          <div className="bg-white rounded-3xl p-4 border border-coquette-deep/40 shadow-xs space-y-3">
            <span className="font-bold text-gray-700 block">✨ Gửi yêu cầu hỗ trợ mới</span>
            
            <form onSubmit={handleCreateTicket} className="space-y-3">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-600 block">Phân loại hỗ trợ:</label>
                <select
                  value={ticketCategory}
                  onChange={(e) => setTicketCategory(e.target.value as any)}
                  className="w-full text-xs px-3 py-2 bg-coquette-cream/50 border border-coquette-deep/30 rounded-xl"
                >
                  <option value="other">💬 Yêu cầu / Khác</option>
                  <option value="lost_order">🔎 Tra soát đơn hàng bị thất lạc</option>
                  <option value="withdraw">💸 Thắc mắc rút tiền ví</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-600 block">Nền tảng liên quan:</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setTicketPlatform('shopee')}
                    className={`py-1.5 px-3 rounded-lg text-[10px] font-bold border transition-colors cursor-pointer ${
                      ticketPlatform === 'shopee'
                        ? 'bg-coquette-pink text-coquette-primary border-coquette-deep shadow-3xs'
                        : 'bg-white text-gray-500 border-gray-200 hover:bg-gray-50'
                    }`}
                  >
                    🛍️ Shopee
                  </button>
                  <button
                    type="button"
                    onClick={() => setTicketPlatform('tiktok')}
                    className={`py-1.5 px-3 rounded-lg text-[10px] font-bold border transition-colors cursor-pointer ${
                      ticketPlatform === 'tiktok'
                        ? 'bg-purple-50 text-purple-700 border-purple-200 shadow-3xs'
                        : 'bg-white text-gray-500 border-gray-200 hover:bg-gray-50'
                    }`}
                  >
                    🎵 TikTok Shop
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-600 block">Tiêu đề yêu cầu:</label>
                <input
                  type="text"
                  required
                  placeholder="Ghi ngắn gọn thắc mắc chính..."
                  value={ticketTitle}
                  onChange={(e) => setTicketTitle(e.target.value)}
                  className="w-full text-xs px-3 py-2 bg-coquette-cream/50 border border-coquette-deep/30 rounded-xl"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-600 block">Chi tiết sự vụ:</label>
                <textarea
                  required
                  rows={3}
                  placeholder="Mô tả cụ thể mã đơn hàng, sự cố, thông tin người dùng..."
                  value={ticketContent}
                  onChange={(e) => setTicketContent(e.target.value)}
                  className="w-full text-xs px-3 py-2 bg-coquette-cream/50 border border-coquette-deep/30 rounded-xl"
                />
              </div>

              {ticketMsg && (
                <p className="bg-rose-50/50 border border-rose-200 text-rose-800 text-[10.5px] p-2.5 rounded-xl">
                  {ticketMsg}
                </p>
              )}

              <button
                type="submit"
                className="w-full bg-coquette-accent hover:bg-coquette-accent/90 text-white font-bold py-2.5 rounded-xl cursor-pointer"
              >
                Gửi Đề Xuất Hỗ Trợ Lên Hệ Thống 🎀
              </button>
            </form>
          </div>

          {/* Tickets lists */}
          <div className="space-y-3.5">
            <span className="font-bold text-gray-800 block">📜 Lịch sử Ticket của bạn ({tickets.length})</span>
            {tickets.length === 0 ? (
              <p className="text-[10.5px] text-gray-400 text-center py-6 bg-white rounded-3xl border border-dashed border-coquette-deep/20">Bạn chưa gửi ticket hỗ trợ nào.</p>
            ) : (
              <div className="space-y-3">
                {tickets.map(tk => (
                  <div key={tk.id} className="bg-white rounded-2xl p-4 border border-coquette-deep/30 space-y-2.5 shadow-3xs">
                    <div className="flex justify-between items-start">
                      <div className="space-y-0.5">
                        <span className="text-[10px] text-gray-400 font-mono">#{tk.id}</span>
                        <h4 className="font-bold text-gray-800">{tk.title}</h4>
                      </div>
                      <span className={`px-2 py-0.5 rounded text-[8.5px] font-bold ${
                        tk.status === 'replied'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : tk.status === 'closed'
                          ? 'bg-gray-100 text-gray-400 border border-gray-200'
                          : 'bg-amber-50 text-amber-700 border border-amber-200 animate-pulse'
                      }`}>
                        {tk.status === 'replied' ? 'Đã phản hồi' : tk.status === 'closed' ? 'Đã đóng' : 'Chờ xử lý'}
                      </span>
                    </div>

                    <p className="text-[11px] text-gray-500 whitespace-pre-line bg-gray-50/50 p-2.5 rounded-xl border border-gray-100">{tk.content}</p>

                    {tk.adminReply && (
                      <div className="bg-coquette-pink/30 p-2.5 rounded-xl border border-coquette-deep/20 space-y-1">
                        <span className="text-[10px] font-bold text-coquette-accent">💝 Phản hồi của Thụy Vy Admin:</span>
                        <p className="text-[11px] text-gray-700 leading-relaxed whitespace-pre-line">{tk.adminReply}</p>
                      </div>
                    )}

                    <div className="text-[9px] text-gray-350 flex justify-between items-center">
                      <div className="flex gap-2">
                        <span>Phân loại: {tk.category === 'lost_order' ? '🔎 Tra soát đơn' : tk.category === 'withdraw' ? '💸 Lỗi rút tiền' : '💬 Khác'}</span>
                        <span className="text-coquette-primary font-bold">
                          • {tk.platform === 'tiktok' ? '🎵 TikTok Shop' : '🛍️ Shopee'}
                        </span>
                      </div>
                      <span>Ngày tạo: {new Date(tk.createdAt).toLocaleDateString('vi-VN')}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
}
