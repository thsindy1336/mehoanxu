import React, { useState } from 'react';
import { Wallet, Search, ArrowRight, UserPlus, FileText, CheckCircle2, Clock, XCircle, AlertTriangle, ShieldCheck, ChevronRight, CornerDownRight } from 'lucide-react';
import { User, Order, WithdrawRequest, OrderStatus } from '../types';
import { SUPPORTED_BANKS, getOrders, saveOrders, getWithdrawRequests, saveWithdrawRequests, getUsers, saveUsers, getConfig } from '../data';

interface ProfileViewProps {
  currentUser: User | null;
  onOpenAuthModal: () => void;
  // Cho phép nhảy tab hoặc mở view khác nếu cần
  setCurrentView: (view: string) => void;
}

export default function ProfileView({ currentUser, onOpenAuthModal, setCurrentView }: ProfileViewProps) {
  const [activeTab, setActiveTab] = useState<'wallet' | 'orders' | 'referrals' | 'withdraw'>('wallet');
  
  // States cho Rút tiền
  const [withdrawMoney, setWithdrawMoney] = useState('');
  const [selectedBank, setSelectedBank] = useState(SUPPORTED_BANKS[0]);
  const [bankHolder, setBankHolder] = useState('');
  const [bankNumber, setBankNumber] = useState('');
  const [withdrawError, setWithdrawError] = useState('');
  const [withdrawSuccess, setWithdrawSuccess] = useState(false);
  const [referralCopied, setReferralCopied] = useState(false);

  // States cho Lịch sử đơn hàng
  const [orderQuery, setOrderQuery] = useState('');
  const [orderFilter, setOrderFilter] = useState<'all' | 'approved' | 'pending' | 'cancelled'>('all');

  if (!currentUser) {
    return (
      <div className="bg-white rounded-3xl p-8 border border-coquette-deep/40 shadow-xs text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-coquette-pink flex items-center justify-center text-3xl mx-auto shadow-2xs">🎀</div>
        <div className="space-y-1.5">
          <h3 className="font-serif text-lg font-bold text-gray-800">Cổng Thông Tin Cá Nhân</h3>
          <p className="text-xs text-gray-400 max-w-xs mx-auto">Vui lòng đăng ký tài khoản hoặc đăng nhập để kiểm tra số dư ví, khai báo đơn hàng và đổi voucher quà tặng nhé.</p>
        </div>
        <button
          onClick={onOpenAuthModal}
          className="bg-coquette-accent hover:bg-coquette-accent/90 text-white font-bold text-xs px-6 py-2.5 rounded-full transition-all cursor-pointer shadow-xs"
        >
          Đăng Nhập Ngay
        </button>
      </div>
    );
  }

  // Đọc danh bạ dữ liệu động để hiển thị chính xác
  const allOrders = getOrders().filter(o => o.username === currentUser.username);
  const allWithdraws = getWithdrawRequests().filter(w => w.username === currentUser.username);

  // Tính số lượng đơn được duyệt cho referral check
  const approvedOrdersCount = allOrders.filter(o => o.status === 'approved').length;
  const isReferralEligible = approvedOrdersCount >= 3;

  // Lấy nhãn và màu cho từng trạng thái đơn hàng
  const getStatusMeta = (status: OrderStatus) => {
    switch (status) {
      case 'approved':
        return {
          label: 'Đã đối soát',
          color: 'text-emerald-700 bg-emerald-50 border-emerald-300 shadow-3xs',
          icon: <span className="text-xs mr-0.5">✅</span>
        };
      case 'pending_approve':
        return {
          label: 'Chờ đối soát',
          color: 'text-amber-700 bg-amber-50 border-amber-300 animate-pulse',
          icon: <span className="text-xs mr-0.5">⏳</span>
        };
      case 'pending_record':
        return {
          label: 'Chờ duyệt',
          color: 'text-amber-600 bg-yellow-50/50 border-[#E4B53D]/70',
          icon: <span className="text-xs mr-0.5">🟡</span>
        };
      case 'cancelled':
        return {
          label: 'Đã hủy',
          color: 'text-rose-700 bg-rose-50 border-rose-300',
          icon: <span className="text-xs mr-0.5">❌</span>
        };
    }
  };

  // Tìm kiếm & lọc đơn hàng
  const filteredOrders = allOrders.filter(o => {
    const matchesSearch = o.orderId.includes(orderQuery);
    if (!matchesSearch) return false;

    if (orderFilter === 'approved') return o.status === 'approved';
    if (orderFilter === 'pending') return o.status === 'pending_approve' || o.status === 'pending_record';
    if (orderFilter === 'cancelled') return o.status === 'cancelled';
    return true;
  });

  // Gửi lệnh rút tiền
  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setWithdrawError('');
    setWithdrawSuccess(false);

    const amount = parseInt(withdrawMoney, 10);
    if (isNaN(amount) || amount < 10000) {
      setWithdrawError('Số tiền rút tối thiểu phải từ 10.000đ trở lên.');
      return;
    }

    if (amount > currentUser.availableBalance) {
      setWithdrawError(`Bạn không đủ số dư khả dụng (Hiện có: ${currentUser.availableBalance.toLocaleString('vi-VN')}đ).`);
      return;
    }

    if (!bankHolder.trim() || !bankNumber.trim()) {
      setWithdrawError('Vui lòng nhập đầy đủ tên chủ tài khoản và số tài khoản ngân hàng.');
      return;
    }

    // Trừ số dư ví khả dụng của user, lưu lại database
    const users = getUsers();
    const userIndex = users.findIndex(u => u.username === currentUser.username);
    if (userIndex >= 0) {
      users[userIndex].availableBalance -= amount;
      users[userIndex].pendingBalance += amount; // Đưa vào tiền đang đối soát rút
      saveUsers(users);
      
      // Update local copy of current user inside parent component state (handled in App.tsx)
      currentUser.availableBalance -= amount;
      currentUser.pendingBalance += amount;
    }

    // Thêm yêu cầu rút tiền mới
    const withdrawals = getWithdrawRequests();
    const newRequest: WithdrawRequest = {
      id: 'w' + (withdrawals.length + 101),
      username: currentUser.username,
      amount,
      bankName: selectedBank,
      accountHolder: bankHolder.toUpperCase(),
      accountNumber: bankNumber,
      status: 'pending',
      createdAt: new Date().toISOString()
    };
    withdrawals.unshift(newRequest);
    saveWithdrawRequests(withdrawals);

    setWithdrawSuccess(true);
    setWithdrawMoney('');
    setBankHolder('');
    setBankNumber('');
    if (typeof (window as any).showToast === 'function') {
      (window as any).showToast('✅ Gửi yêu cầu rút tiền thành công', 'success');
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Wallet overview banner (Coquette Styled) */}
      <div className="relative bg-white rounded-3xl p-6 border-2 border-[#FFA6B7] shadow-md overflow-hidden">
        <div className="absolute -top-3 -right-3 text-7xl opacity-5 select-none font-serif">🎀</div>
        
        <div className="flex items-center gap-2.5 mb-5">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-coquette-pink to-[#FFD2DC] flex items-center justify-center text-coquette-accent shadow-xs border border-[#FFABC0]">
            <Wallet className="w-5 h-5 text-[#FF4D79]" />
          </div>
          <div>
            <h3 className="font-serif text-sm font-black text-gray-800 uppercase tracking-wider">Ví Tiền Mê Hoàn Xu</h3>
            <p className="text-[10px] text-gray-500 font-medium">Tài khoản: <strong className="font-bold text-gray-700">@{currentUser.username}</strong></p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3 text-center">
          <div className="bg-[#EDFDF5] p-3 rounded-2xl border-2 border-[#10B981] space-y-1 shadow-3xs hover:scale-[1.02] transition-transform">
            <span className="text-[10px] text-emerald-800 font-extrabold block uppercase tracking-wider">Khả Dụng</span>
            <span className="text-xs sm:text-sm font-black text-[#047857] font-sans block">{currentUser.availableBalance.toLocaleString('vi-VN')}đ</span>
          </div>

          <div className="bg-[#FEFBE8] p-3 rounded-2xl border-2 border-[#F59E0B] space-y-1 shadow-3xs hover:scale-[1.02] transition-transform">
            <span className="text-[10px] text-amber-800 font-extrabold block uppercase tracking-wider">Chờ Duyệt</span>
            <span className="text-xs sm:text-sm font-black text-[#B45309] font-sans block">{currentUser.pendingBalance.toLocaleString('vi-VN')}đ</span>
          </div>

          <div className="bg-[#EFF6FF] p-3 rounded-2xl border-2 border-[#1E40AF] space-y-1 shadow-3xs hover:scale-[1.02] transition-transform">
            <span className="text-[10px] text-blue-800 font-extrabold block uppercase tracking-wider">Tổng Nhận</span>
            <span className="text-xs sm:text-sm font-black text-[#1D4ED8] font-sans block">{currentUser.totalCashback.toLocaleString('vi-VN')}đ</span>
          </div>
        </div>

        {/* Quick action buttons Inside the wallet */}
        <div className="grid grid-cols-2 gap-3 mt-5">
          <button
            onClick={() => setActiveTab('withdraw')}
            className={`py-3 text-xs font-black rounded-xl border-2 tracking-wider transition-all text-center cursor-pointer shadow-3xs hover:opacity-95 active:scale-[0.98] ${
              activeTab === 'withdraw'
                ? 'bg-gradient-to-r from-coquette-accent to-[#FF7B94] text-white border-transparent'
                : 'bg-white hover:bg-coquette-pink/30 text-coquette-accent border-[#FFA6B7]/60'
            }`}
          >
            💸 RÚT TIỀN VÍ
          </button>
          
          <button
            onClick={() => setActiveTab('orders')}
            className={`py-3 text-xs font-black rounded-xl border-2 tracking-wider transition-all text-center cursor-pointer shadow-3xs hover:opacity-95 active:scale-[0.98] ${
              activeTab === 'orders'
                ? 'bg-gradient-to-r from-coquette-accent to-[#FF7B94] text-white border-transparent'
                : 'bg-white hover:bg-coquette-pink/30 text-coquette-accent border-[#FFA6B7]/60'
            }`}
          >
            📋 LỊCH SỬ ĐƠN
          </button>
        </div>
      </div>

      {/* Profile Inner Views */}
      
      {activeTab === 'wallet' && (
        <div className="space-y-4">
          <div className="bg-white rounded-3xl p-5 border border-coquette-deep/40 shadow-xs space-y-4">
            <h3 className="font-serif text-sm font-bold text-gray-800 flex items-center gap-1.5 pb-2 border-b border-dashed border-coquette-deep/30">
              <span>Lịch Sử Rút Tiền</span>
              <span className="text-coquette-accent">🎀</span>
            </h3>

            {allWithdraws.length === 0 ? (
              <p className="text-xs text-center py-6 text-gray-400">Bạn chưa phát sinh giao dịch rút tiền nào.</p>
            ) : (
              <div className="divide-y divide-gray-100 max-h-56 overflow-y-auto pr-1">
                {allWithdraws.map((w) => (
                  <div key={w.id} className="py-2.5 flex justify-between items-center text-xs">
                    <div className="space-y-0.5">
                      <p className="font-bold text-gray-800">-{w.amount.toLocaleString('vi-VN')} VNĐ</p>
                      <p className="text-[10px] text-gray-400 font-mono truncate max-w-xs">{w.bankName} - {w.accountNumber}</p>
                    </div>
                    <div className="text-right space-y-0.5">
                      <span className={`inline-block px-2 py-0.5 rounded text-[9px] font-bold ${
                        w.status === 'completed'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : w.status === 'rejected'
                          ? 'bg-rose-50 text-rose-700 border border-rose-200'
                          : 'bg-amber-50 text-amber-700 border border-amber-200'
                      }`}>
                        {w.status === 'completed' ? 'Thành công' : w.status === 'rejected' ? 'Bị từ chối' : 'Chờ xử lý'}
                      </span>
                      <p className="text-[9px] text-gray-300 font-mono">{new Date(w.createdAt).toLocaleDateString('vi-VN')}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Referral promo banner inside wallet page */}
          <button
            onClick={() => setActiveTab('referrals')}
            className="w-full text-left bg-gradient-to-r from-purple-500/5 to-purple-500/10 hover:from-purple-500/10 hover:to-purple-500/20 rounded-3xl p-4 border border-purple-200/50 transition-all flex justify-between items-center cursor-pointer"
          >
            <div className="space-y-1">
              <span className="text-xs font-bold text-purple-700 block">🎁 Nhận Thưởng Giới Thiệu Bạn Bè</span>
              <p className="text-[10px] text-gray-500">Mời thêm bạn bè tham gia và nhận thưởng tự động khi đủ điều kiện đối soát trên hệ thống!</p>
            </div>
            <ChevronRight className="w-5 h-5 text-purple-400 shrink-0" />
          </button>
        </div>
      )}

      {/* WITHDRAW FORM SCREEN */}
      {activeTab === 'withdraw' && (
        <div className="bg-white rounded-3xl p-6 border-2 border-[#FFA6B7]/60 shadow-md space-y-5 animate-in fade-in duration-200">
          <div className="flex justify-between items-center pb-3 border-b border-dashed border-gray-200">
            <h3 className="font-serif text-sm font-black text-gray-800 flex items-center gap-1 uppercase">
              <span>Đề Xuất Rút Tiền Ví</span>
              <span className="text-coquette-accent">💸</span>
            </h3>
            <span className="text-[10px] bg-rose-100 text-[#FF4D79] border border-[#FFA6B7] px-2.5 py-1 rounded-full font-mono font-black">Tối thiểu: 10K VNĐ</span>
          </div>

          {withdrawSuccess ? (
            <div className="bg-emerald-50 text-emerald-700 p-5 rounded-2xl border-2 border-emerald-300 space-y-4 text-center animate-in zoom-in duration-200">
              <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center mx-auto text-emerald-600 font-black text-xl border-2 border-emerald-400">✓</div>
              <div className="space-y-1.5">
                <span className="text-sm font-black block text-emerald-900 uppercase">Yêu cầu rút tiền thành công!</span>
                <p className="text-xs text-emerald-850 leading-relaxed font-semibold">
                  Mê Hoàn Xu đã ghi nhận yêu cầu của bạn. Hệ thống sẽ tiến hành đối soát và cộng tài khoản thực nhận tối đa trong vòng <strong className="font-black text-emerald-950">48h</strong>.
                </p>
              </div>
              <button
                onClick={() => setWithdrawSuccess(false)}
                className="bg-white hover:bg-emerald-50 text-emerald-700 font-black text-xs px-5 py-2 rounded-xl border-2 border-emerald-400 transition-all cursor-pointer shadow-3xs"
              >
                Tạo giao dịch rút tiền khác
              </button>
            </div>
          ) : (
            <form onSubmit={handleWithdrawSubmit} className="space-y-4">
              
              {/* Amount input */}
              <div className="space-y-1.5 text-left">
                <label className="text-xs font-black text-gray-700 uppercase">Số tiền muốn rút (VNĐ) <span className="text-rose-500">*</span></label>
                <input
                  type="number"
                  required
                  min="10000"
                  value={withdrawMoney}
                  onChange={(e) => setWithdrawMoney(e.target.value)}
                  placeholder="Ví dụ: 20000"
                  className="w-full text-xs px-4 py-3 bg-stone-50 hover:bg-white focus:bg-white border-2 border-gray-300 focus:border-coquette-accent focus:ring-4 focus:ring-coquette-accent/20 rounded-xl outline-hidden transition-all text-gray-800 font-mono font-bold placeholder:font-sans placeholder:font-medium placeholder:text-gray-400"
                />
              </div>

              {/* Bank Selection */}
              <div className="space-y-1.5 text-left">
                <label className="text-xs font-black text-gray-700 uppercase">Ngân hàng thụ hưởng <span className="text-rose-500">*</span></label>
                <select
                  value={selectedBank}
                  onChange={(e) => setSelectedBank(e.target.value)}
                  className="w-full text-xs px-4 py-3 bg-stone-50 hover:bg-white focus:bg-white border-2 border-gray-300 focus:border-coquette-accent focus:ring-4 focus:ring-coquette-accent/20 rounded-xl outline-hidden transition-all text-gray-800 font-sans font-bold"
                >
                  {SUPPORTED_BANKS.map((bank) => (
                    <option key={bank} value={bank}>{bank}</option>
                  ))}
                </select>
              </div>

              {/* Account holder */}
              <div className="space-y-1.5 text-left">
                <label className="text-xs font-black text-gray-700 uppercase">Họ và tên chủ tài khoản (Viết hoa không dấu) <span className="text-rose-500">*</span></label>
                <input
                  type="text"
                  required
                  value={bankHolder}
                  onChange={(e) => setBankHolder(e.target.value)}
                  placeholder="Ví dụ: NGUYEN THI THU THUY"
                  className="w-full text-xs px-4 py-3 bg-stone-50 hover:bg-white focus:bg-white border-2 border-gray-300 focus:border-coquette-accent focus:ring-4 focus:ring-coquette-accent/20 rounded-xl outline-hidden transition-all text-gray-800 font-sans font-black upper-case placeholder:font-sans placeholder:font-medium placeholder:text-gray-400"
                />
              </div>

              {/* Account number */}
              <div className="space-y-1.5 text-left">
                <label className="text-xs font-black text-gray-700 uppercase">Số tài khoản ngân hàng <span className="text-rose-500">*</span></label>
                <input
                  type="text"
                  required
                  value={bankNumber}
                  onChange={(e) => setBankNumber(e.target.value)}
                  placeholder="Nhập chính xác số tài khoản..."
                  className="w-full text-xs px-4 py-3 bg-stone-50 hover:bg-white focus:bg-white border-2 border-gray-300 focus:border-coquette-accent focus:ring-4 focus:ring-coquette-accent/20 rounded-xl outline-hidden transition-all text-gray-800 font-mono font-bold placeholder:font-sans placeholder:font-medium placeholder:text-gray-400"
                />
              </div>

              {withdrawError && (
                <p className="text-xs text-red-600 bg-red-100/50 p-3 rounded-xl border-2 border-red-300 flex items-center gap-1.5 leading-relaxed font-semibold">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-red-600" />
                  <span>{withdrawError}</span>
                </p>
              )}

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-coquette-accent to-[#FF7B94] hover:opacity-95 text-white font-black text-xs py-3.5 rounded-xl transition-all cursor-pointer shadow-md active:scale-[0.98] uppercase tracking-wider"
              >
                Gửi Đề Xuất Rút Tiền (24/7) 🎀
              </button>
            </form>
          )}
        </div>
      )}

      {/* ORDERS HISTORY SCREEN */}
      {activeTab === 'orders' && (
        <div className="bg-white rounded-3xl p-5 border border-coquette-deep/40 shadow-xs space-y-4 animate-in fade-in duration-200">
          <div className="pb-2 border-b border-dashed border-coquette-deep/30 flex justify-between items-center">
            <h3 className="font-serif text-sm font-bold text-gray-800 flex items-center gap-1">
              <span>Đơn Hàng Đã Ghi Nhận</span>
              <span className="text-coquette-accent">🛍️</span>
            </h3>
            <span className="text-[10px] text-gray-400 font-mono">Tổng: {allOrders.length} đơn</span>
          </div>

          {/* Informational guide block about "Thông Báo Đơn Hàng Chờ Duyệt" */}
          <div className="bg-[#FFFDFD] p-4 rounded-2xl border-2 border-[#FFA6B7]/40 text-[11.5px] leading-relaxed text-gray-750 shadow-3xs space-y-2 select-text">
            <div className="font-extrabold text-[#FF4D79] flex items-center gap-1.5 uppercase text-[11px] tracking-wide">
              <span>🔔 QUY TRÌNH KIỂM TRA ĐỐI SOÁT HOÀN TIỀN</span>
            </div>
            <p className="font-medium text-gray-600">
              Đơn hàng của bạn đã được ghi nhận thành công. Nếu đơn hàng không bị hủy, hoàn trả hoặc vi phạm điều kiện của sàn, tiền hoàn sẽ được xác nhận và cộng vào tài khoản sau khi hoàn tất quá trình đối soát. Thời gian xử lý thông thường từ 7 - 15 ngày tùy theo Shopee hoặc TikTok Shop.
            </p>
            <div className="pt-2 border-t border-dashed border-[#FFA6B7]/25 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[11px] font-bold">
              <span className="text-[#FF8500] flex items-center gap-1.5">
                <span>🟡 Đơn hàng đang chờ đối soát</span>
              </span>
              <span className="text-coquette-accent/90">
                ⏳ Dự kiến hoàn tất trong khoảng 7 - 15 ngày nếu đơn không bị hủy hoặc hoàn trả.
              </span>
            </div>
          </div>

          {/* Filters and search info */}
          <div className="space-y-3">
            <div className="grid grid-cols-4 gap-1.5 p-1 bg-stone-100 rounded-xl">
              {(['all', 'approved', 'pending', 'cancelled'] as const).map((filter) => (
                <button
                  key={filter}
                  onClick={() => setOrderFilter(filter)}
                  className={`text-center py-2.5 rounded-lg text-xs font-black cursor-pointer transition-all ${
                    orderFilter === filter
                      ? 'bg-gradient-to-r from-coquette-accent to-[#FF7B94] text-white shadow-3xs'
                      : 'text-gray-500 hover:text-coquette-accent hover:bg-white/50'
                  }`}
                >
                  {filter === 'all' ? 'Tất cả' : filter === 'approved' ? 'Đã duyệt' : filter === 'pending' ? 'Chờ duyệt' : 'Đã hủy'}
                </button>
              ))}
            </div>

            <div className="relative">
              <input
                type="text"
                value={orderQuery}
                onChange={(e) => setOrderQuery(e.target.value)}
                placeholder="Tìm mã đơn hàng Shopee..."
                className="w-full text-xs pl-9 pr-4 py-3 bg-stone-50 hover:bg-white focus:bg-white border-2 border-gray-300 focus:border-coquette-accent focus:ring-4 focus:ring-coquette-accent/25 rounded-xl outline-hidden text-gray-800 font-mono font-bold"
              />
              <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          {/* List of orders */}
          {filteredOrders.length === 0 ? (
            <p className="text-xs text-center py-10 text-gray-500 leading-relaxed font-semibold">
              Không tìm thấy đơn hàng nào khớp với bộ lọc.<br />
              <button 
                onClick={() => setCurrentView('cashback')}
                className="text-coquette-accent underline text-xs font-black mt-2 inline-block cursor-pointer"
              >
                Dán link mua hàng nhận hoàn tiền đầu tiên 🌸
              </button>
            </p>
          ) : (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 max-h-[500px] overflow-y-auto pr-1 pb-2">
                {filteredOrders.map((o) => {
                  const statusMeta = getStatusMeta(o.status);
                  const isTikTok = o.platform === 'tiktok' || 
                                   o.orderId.toLowerCase().includes('tiktok') || 
                                   (o.productName && o.productName.toLowerCase().includes('tiktok')) ||
                                   !o.orderId.match(/^\d+$/);
                  const platformLabel = isTikTok ? 'TikTok Shop' : 'Shopee';
                  const platformIcon = isTikTok ? '🖤' : '🧡';
                  return (
                    <div key={o.orderId} className="bg-white rounded-2xl p-5 border-2 border-slate-200 shadow-sm flex flex-col justify-between hover:scale-[1.01] hover:border-coquette-accent/50 hover:shadow-md transition-all duration-200">
                      <div className="flex items-center justify-between pb-3 border-b-2 border-slate-100 mb-4">
                        <div className="flex items-center gap-1.5 font-bold font-serif text-gray-800 text-xs uppercase tracking-wider">
                          <span>{platformIcon}</span>
                          <span>{platformLabel}</span>
                        </div>
                        <div className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider border flex items-center gap-0.5 ${statusMeta?.color}`}>
                          {statusMeta?.icon}
                          <span>{statusMeta?.label}</span>
                        </div>
                      </div>

                      <div className="space-y-2 text-left text-gray-650 text-[11.5px] pl-1 font-medium">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Mã đơn hàng:</span>
                          <span className="font-mono font-black text-gray-800 select-all">#{o.orderId}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Ngày mua:</span>
                          <span className="text-gray-700 font-mono font-semibold">
                            {new Date(o.time || Date.now()).toLocaleDateString('vi-VN')} {new Date(o.time || Date.now()).toLocaleTimeString('vi-VN', {hour: '2-digit', minute: '2-digit'})}
                          </span>
                        </div>
                      </div>

                      <div className="mt-5 pt-3 border-t-2 border-dashed border-gray-100 flex items-center justify-between text-[11.5px] bg-[#FFF0F3]/30 px-3 py-2.5 rounded-xl border border-[#FFA6B7]/30">
                        <span className="font-bold text-gray-650 flex items-center gap-1">💰 TIỀN HOÀN CỘNG VÍ:</span>
                        <span className="font-sans font-black text-[#FF4D79] text-base shrink-0">
                          +{o.rebateAmount?.toLocaleString('vi-VN')}đ
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* REFERRALS SYSTEM SCREEN */}
      {activeTab === 'referrals' && (
        <div className="bg-white rounded-3xl p-6 border-2 border-[#FFA6B7]/65 shadow-md space-y-5 animate-in fade-in duration-200">
          <div className="pb-3 border-b border-dashed border-gray-200">
            <h3 className="font-serif text-sm font-black text-gray-800 flex items-center gap-1.5 uppercase tracking-wider">
              <span>🎁 Giới Thiệu Bạn Bè Nhận Thưởng</span>
            </h3>
            <p className="text-[10px] text-gray-500">Mới rộng cộng đồng để nhận ưu đãi tích lũy không giới hạn</p>
          </div>

          {!isReferralEligible ? (
            <div className="bg-purple-50/50 p-5 border-2 border-purple-300 rounded-2xl space-y-3.5 shadow-3xs text-left">
              <p className="text-xs text-purple-950 leading-relaxed font-black flex items-start gap-1">
                <AlertTriangle className="w-4.5 h-4.5 text-purple-600 shrink-0 mt-0.5 animate-pulse" />
                <span>CHƯA ĐỦ ĐIỀU KIỆN KÍCH HOẠT LIÊN KẾT NHẬN THƯỞNG</span>
              </p>
              <div className="text-xs text-gray-650 space-y-1.5 pl-5 font-sans">
                <p className="font-bold text-purple-950">⚠️ Quy định điều kiện tham gia chương trình:</p>
                <p>• Phải phát sinh và hoàn tất tối thiểu <strong className="text-purple-700 font-extrabold">3 đơn hàng được duyệt hoàn tiền thành công</strong>.</p>
                <p>• Hiện tại: bạn mới chỉ tích lũy được: <strong className="text-rose-500 font-black font-sans">{approvedOrdersCount} / 3 đơn</strong>.</p>
              </div>
              <p className="text-[11px] text-purple-600 leading-normal italic pl-5">
                Hãy dán thêm link sản phẩm Shopee/TikTok Shop để mua sắm ngay hoặc gửi mã đơn hàng của bạn để đối soát nhanh nhé! 🌸
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="bg-[#FAF5FF] p-5 rounded-2xl border-2 border-purple-200 text-xs text-purple-950 space-y-2 shadow-3xs text-left">
                <p className="font-black text-purple-900 text-sm">🎉 XIN CHÚC MỪNG! BẠN ĐÃ ĐỦ ĐIỀU KIỆN NHẬN THƯỞNG!</p>
                <p className="leading-relaxed text-[11px] text-gray-750">
                  Hệ thống đã tự động tích hợp mã liên kết giới thiệu cá nhân riêng biệt cho bạn. Hãy chia sẻ đường dẫn bên dưới tới bạn bè để bắt đầu nhận thưởng.
                </p>
              </div>

              {/* Referral Code display */}
              <div className="space-y-1.5 text-left">
                <span className="text-[10px] font-black text-purple-800 uppercase tracking-wider block">Liên kết giới thiệu của bạn:</span>
                <div className="flex bg-[#FAF5FF] border-2 border-purple-300 rounded-xl p-4 items-center justify-between shadow-3xs">
                  <div>
                    <span className="font-mono text-sm font-black text-purple-950 tracking-wider">
                      {currentUser.referralCode}
                    </span>
                    <p className="text-[10px] text-purple-650 font-mono mt-0.5">mê-hoàn-xu.site/register?ref={currentUser.referralCode}</p>
                  </div>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(`https://me-hoan-xu.site/register?ref=${currentUser.referralCode}`);
                      setReferralCopied(true);
                      setTimeout(() => setReferralCopied(false), 2000);
                    }}
                    className="bg-purple-600 hover:bg-purple-700 text-white font-black text-xs px-4 py-2.5 rounded-xl transition-all cursor-pointer shadow-3xs"
                  >
                    {referralCopied ? 'Đã Sao Chép ✨' : 'Sao Chép Link'}
                  </button>
                </div>
              </div>

              {/* Policy & Example calculation */}
              <div className="bg-stone-50 p-5 border-2 border-slate-300 rounded-2xl space-y-4 shadow-3xs text-left">
                <div>
                  <span className="text-xs font-black text-gray-850 uppercase tracking-widest block mb-1">🎁 QUYỀN LỢI & THỂ LỆ CHƯƠNG TRÌNH</span>
                  <div className="text-[11px] text-gray-600 space-y-2 pl-4 list-decimal leading-relaxed">
                    <p>• <strong className="font-extrabold text-[#7C3AED]">Mức Quyền Lợi:</strong> Bạn nhận phần thưởng tương đương <strong className="font-extrabold text-rose-600">1%</strong> tổng số tiền hoàn mà người được giới thiệu nhận được.</p>
                    <p>• <strong className="font-extrabold text-[#7C3AED]">Hạn thời gian thưởng:</strong> Áp dụng tối đa lên tới <strong className="font-extrabold">3 tháng (90 ngày)</strong> kể từ ngày bạn bè đăng ký thành viên mới thành công qua link giới thiệu của bạn.</p>
                    <p>• <strong className="font-extrabold text-[#7C3AED]">Cơ chế cộng thưởng:</strong> Thưởng tự động được đối soát và cộng trực tiếp vào ví khả dụng khi đơn hàng của bạn bè được duyệt hoàn tiền thành công.</p>
                  </div>
                </div>

                <div className="border-t border-dashed border-gray-200 pt-3">
                  <span className="text-xs font-black text-gray-850 uppercase tracking-widest block mb-1">💡 VÍ DỤ MINH HỌA DỄ HIỂU</span>
                  <div className="bg-[#FFFDFD] p-3.5 rounded-xl border border-[#FFA6B7]/40 text-[11px] text-gray-600 space-y-2 font-medium">
                    <p>👉 Bạn giới thiệu <strong className="font-bold text-gray-800">bạn A</strong>.</p>
                    <p>👉 Bạn A phát sinh đơn hàng, khi đơn được duyệt hoàn tiền: <strong className="text-emerald-700 font-extrabold">20.000đ</strong>. Bạn lập tức nhận thưởng tự động: <strong className="text-[#FF4D79] font-black">20.000đ × 1% = 200đ</strong>.</p>
                    <p>👉 Bạn A tiếp tục mua sắm và có thêm đơn hoàn: <strong className="text-emerald-700 font-extrabold">50.000đ</strong>. Bạn tiếp tục nhận thêm: <strong className="text-[#FF4D79] font-black">50.000đ × 1% = 500đ</strong>.</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

    </div>
  );
}
