import React, { useState, useEffect } from 'react';
import { AlertCircle, Link as LinkIcon, ArrowRight, Clipboard, Check, HelpCircle, ExternalLink, Sparkles, RefreshCw, Smartphone } from 'lucide-react';
import { User, ShortLink, Order } from '../types';
import { getConfig, getShortLinks, saveShortLinks, getOrders, saveOrders } from '../data';

interface AddLiveTagCacheItem {
  productName: string;
  imageUrl: string;
  price: string | number;
  sales?: string | number;
  rating?: string | number;
  shopName?: string;
  lastUpdate: number;
}

interface CashbackViewProps {
  currentUser: User | null;
  onOpenAuthModal: () => void;
}

export default function CashbackView({ currentUser, onOpenAuthModal }: CashbackViewProps) {
  const isAdmin = currentUser?.role === 'admin';
  const [platform, setPlatform] = useState<'shopee' | 'tiktok_shop'>('shopee');
  const [inputUrl, setInputUrl] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [clipboardBlocked, setClipboardBlocked] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [isRedirecting, setIsRedirecting] = useState(false);

  // States: Shopee generated output
  const [generatedLink, setGeneratedLink] = useState<ShortLink | null>(null);
  const [orderCode, setOrderCode] = useState('');
  const [hasSubmittedOrder, setHasSubmittedOrder] = useState(false);

  // States for AddLiveTag Product Data
  const [productLoading, setProductLoading] = useState(false);
  const [productError, setProductError] = useState<string | null>(null);
  const [productInfo, setProductInfo] = useState<AddLiveTagCacheItem | null>(null);

  // States: TikTok product generation
  const [creatorUsername, setCreatorUsername] = useState('tthuy3326');
  const [subId, setSubId] = useState('web');
  const [tiktokLoading, setTiktokLoading] = useState(false);
  const [generatedTikTokLink, setGeneratedTikTokLink] = useState<{
    originalLink: string;
    affiliateLink: string;
    productId: string;
    subId: string;
    createdAt: string;
    code?: string;
  } | null>(null);

  const [processedLink, setProcessedLink] = useState<{
    code: string;
    originalLink: string;
    affiliateLink: string;
    platform: 'shopee' | 'tiktok_shop';
    shopId?: string;
    itemId?: string;
    createdAt: string;
  } | null>(null);

  const [lastProcessedUrl, setLastProcessedUrl] = useState('');

  const [adminTikTokConfig, setAdminTikTokConfig] = useState<{ creator_username: string } | null>(null);

  // Tải cấu hình Creator Username mặc định của User trên server side
  useEffect(() => {
    if (currentUser) {
      fetchUserDefaultConfig();
    }
    const fetchAdminConfig = async () => {
      try {
        const response = await fetch('/api/tiktok/config/admin');
        if (response.ok) {
          const data = await response.json();
          setAdminTikTokConfig(data);
        }
      } catch (err) {
        console.warn('Không thể kéo cấu hình Admin Tiktok:', err);
      }
    };
    fetchAdminConfig();
  }, [currentUser]);

  const fetchUserDefaultConfig = async () => {
    try {
      const response = await fetch(`/api/tiktok/config/${currentUser?.username}`);
      if (response.ok) {
        const data = await response.json();
        if (data.creator_username) {
          setCreatorUsername(data.creator_username);
        }
      }
    } catch (err) {
      console.warn('Không thể kéo Creator mặc định:', err);
    }
  };

  // Tự động nhận diện đường dẫn link dán vào
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setInputUrl(val);
    
    const lowercaseVal = val.toLowerCase();
    if (lowercaseVal.includes('tiktok.com') || lowercaseVal.includes('vt.tiktok.com')) {
      setPlatform('tiktok_shop');
    } else if (lowercaseVal.includes('shopee.vn') || lowercaseVal.includes('shope.ee')) {
      setPlatform('shopee');
    }
  };

  // Tự động kích hoạt xử lý khi dán link hoàn chỉnh
  useEffect(() => {
    const checkAndAutoProcess = async () => {
      const trimmed = inputUrl.trim();
      if (!trimmed) return;
      if (trimmed === lastProcessedUrl) return;

      // Nhận diện nếu là link hoàn chỉnh (bắt đầu bằng http hoặc https)
      const isUrl = /^https?:\/\//i.test(trimmed);
      if (isUrl) {
        // Nhận diện xem link có chứa Shopee hoặc TikTok Shop không
        const lower = trimmed.toLowerCase();
        const isShopee = lower.includes('shopee.vn') || lower.includes('shope.ee');
        const isTikTok = lower.includes('tiktok.com') || lower.includes('vt.tiktok.com');

        if (isShopee || isTikTok) {
          setLastProcessedUrl(trimmed);
          const detectedPlatform = isTikTok ? 'tiktok_shop' : 'shopee';
          setPlatform(detectedPlatform);
          await handleProcess(trimmed, detectedPlatform);
        }
      }
    };

    checkAndAutoProcess();
  }, [inputUrl, currentUser]);

  // Hàm sinh mã rút gọn 2-4 ký tự A-Z, a-z, 0-9 cho Shopee
  const generateShortCode = (): string => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const length = Math.floor(Math.random() * 3) + 2; // 2, 3 hoặc 4
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  };

  // Hàm xử lý chính cho cả Shopee và TikTok Shop (Luôn luôn thành công tạo link rút gọn, bổ sung thông tin sản phẩm nếu có)
  const handleProcess = async (urlToProcess: string, targetPlatform: 'shopee' | 'tiktok_shop') => {
    const trimmedUrl = urlToProcess.trim();
    if (!trimmedUrl) {
      setErrorMsg('Vui lòng điền vào đường dẫn liên kết.');
      return;
    }

    setErrorMsg('');
    setGeneratedLink(null);
    setGeneratedTikTokLink(null);
    setProcessedLink(null);
    setProductInfo(null);
    setProductError(null);
    setHasSubmittedOrder(false);
    setOrderCode('');

    // Bắt buộc người dùng đăng nhập
    if (!currentUser) {
      onOpenAuthModal();
      return;
    }

    const currentUsername = currentUser.username;
    const config = getConfig();

    // Sinh luôn mã rút gọn trước mắt để luôn đảm bảo tính khả dụng
    const listLinks = getShortLinks();
    let shortCode = generateShortCode();
    while (listLinks.some(l => l.code === shortCode)) {
      shortCode = generateShortCode();
    }

    if (targetPlatform === 'shopee') {
      setProductLoading(true);

      // Trích xuất shopId và itemId sơ bộ ở client
      let localShopId = '';
      let localItemId = '';
      const regexI = /i\.(\d+)\.(\d+)/i;
      const regexProduct = /product\/(\d+)\/(\d+)/i;
      
      const matchI = trimmedUrl.match(regexI);
      const matchProduct = trimmedUrl.match(regexProduct);

      if (matchI) {
        localShopId = matchI[1];
        localItemId = matchI[2];
      } else if (matchProduct) {
        localShopId = matchProduct[1];
        localItemId = matchProduct[2];
      }

      // Tạo sẵn link affiliate cơ bản ban đầu để đảm bảo an toàn tuyệt đối
      let initialShopeeLink = trimmedUrl;
      if (localShopId && localItemId) {
        initialShopeeLink = `https://shopee.vn/product/${localShopId}/${localItemId}`;
      }
      const initialAffiliateLink = `https://s.shopee.vn/an_redir?origin_link=${encodeURIComponent(initialShopeeLink)}&affiliate_id=${config.affiliateId}&sub_id=${currentUsername}&deep_and_deferred=1`;

      // 1. Kiểm tra cache client theo itemId
      let cachedItem: AddLiveTagCacheItem | null = null;
      if (localItemId) {
        const cachedDataStr = localStorage.getItem(`addlivetag_cache_${localItemId}`);
        if (cachedDataStr) {
          try {
            const parsed = JSON.parse(cachedDataStr) as AddLiveTagCacheItem;
            const now = Date.now();
            if (now - parsed.lastUpdate < 24 * 60 * 60 * 1000) {
              cachedItem = parsed;
            }
          } catch (_) {}
        }
      }

      // Nếu có cache, nạp luôn để hiển thị tức thì
      if (cachedItem) {
        setProductInfo(cachedItem);
      }

      // Lưu shortlink này vào bộ nhớ để luôn sẵn sàng
      const newShortLink: ShortLink = {
        code: shortCode,
        originalLink: trimmedUrl,
        affiliateLink: initialAffiliateLink,
        createdBy: currentUsername,
        createdAt: new Date().toISOString(),
        clicks: 0,
        shopId: localShopId || undefined,
        itemId: localItemId || undefined
      };

      listLinks.unshift(newShortLink);
      saveShortLinks(listLinks);
      setGeneratedLink(newShortLink);
      setProcessedLink({
        code: shortCode,
        originalLink: trimmedUrl,
        affiliateLink: initialAffiliateLink,
        platform: 'shopee',
        shopId: localShopId || undefined,
        itemId: localItemId || undefined,
        createdAt: newShortLink.createdAt
      });

      if (typeof (window as any).showToast === 'function') {
        (window as any).showToast('✅ Đã tạo link hoàn tiền thành công', 'success');
      }

      // Tự động sao chép
      const shortLinkVal = `cashback.thuydeal.site/${shortCode}`;
      try {
        await navigator.clipboard.writeText(shortLinkVal);
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2000);
      } catch (e) {}

      // 2. Gọi API để bổ sung thông tin sản phẩm (nếu không có cache)
      if (!cachedItem) {
        try {
          const usernameParam = currentUser ? `&username=${encodeURIComponent(currentUser.username)}` : '';
          const res = await fetch(`/api/addlivetag/product?url=${encodeURIComponent(trimmedUrl)}${usernameParam}`);
          
          if (res.ok) {
            const json = await res.json();
            if (json.success && json.data) {
              const payload = json.data;
              const pName = payload.productName || payload.product_name || payload.name || payload.title || '';
              const imgUrl = payload.imageUrl || payload.image_url || payload.image || (payload.images && payload.images[0]) || '';
              const prc = payload.price || payload.raw_price || '';
              const shpName = payload.shopName || payload.shop_name || payload.shop || '';
              const sls = payload.sales || payload.historical_sold || payload.sold || payload.sold_count || '';
              const rtng = payload.rating || payload.rating_star || payload.ratingStar || payload.stars || '';

              const freshItem: AddLiveTagCacheItem = {
                productName: pName,
                imageUrl: imgUrl,
                price: prc,
                shopName: shpName,
                sales: sls,
                rating: rtng,
                lastUpdate: Date.now()
              };

              const finalShopId = json.shopId || localShopId;
              const finalItemId = json.itemId || localItemId;

              if (finalItemId) {
                localStorage.setItem(`addlivetag_cache_${finalItemId}`, JSON.stringify(freshItem));
              }

              setProductInfo(freshItem);

              // Cập nhật lại aff link chính xác hơn nếu lấy được Shop ID / Item ID mới từ API
              if (finalShopId && finalItemId) {
                const preciseShopeeLink = `https://shopee.vn/product/${finalShopId}/${finalItemId}`;
                const preciseAffiliateLink = `https://s.shopee.vn/an_redir?origin_link=${encodeURIComponent(preciseShopeeLink)}&affiliate_id=${config.affiliateId}&sub_id=${currentUsername}&deep_and_deferred=1`;
                
                // Cập nhật danh sách lưu trữ
                const currentLinks = getShortLinks();
                const targetIdx = currentLinks.findIndex(l => l.code === shortCode);
                if (targetIdx >= 0) {
                  currentLinks[targetIdx].affiliateLink = preciseAffiliateLink;
                  currentLinks[targetIdx].shopId = finalShopId;
                  currentLinks[targetIdx].itemId = finalItemId;
                  saveShortLinks(currentLinks);
                }

                // Cập nhật state hiển thị
                setProcessedLink(prev => prev ? {
                  ...prev,
                  affiliateLink: preciseAffiliateLink,
                  shopId: finalShopId,
                  itemId: finalItemId
                } : null);
              }
            }
          }
        } catch (err) {
          console.warn('Lỗi lấy dữ liệu AddLiveTag phụ, im lặng bỏ qua không báo lỗi:', err);
        }
      }

      setProductLoading(false);

    } else {
      // LOGIC TIKTOK SHOP KẾT NỐI SERVER RIOHUB PROXY
      const finalCreatorUsername = isAdmin ? creatorUsername.trim() : (adminTikTokConfig?.creator_username || 'admin');
      const finalSubId = isAdmin ? (subId.trim() || currentUser.username) : currentUser.username;

      setTiktokLoading(true);

      try {
        const payload = {
          creator_username: finalCreatorUsername || 'admin',
          product_url: trimmedUrl,
          sub_id: finalSubId,
          username: currentUser.username
        };

        const response = await fetch('/api/v1/partner/tiktok/affiliate/links', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        const data = await response.json();

        let finalAffiliateLink = trimmedUrl; // Fallback dùng chính link gốc nếu sập API
        let finalItemId = undefined;

        if (response.ok && !data.error && data.affiliate_link) {
          finalAffiliateLink = data.affiliate_link;
          finalItemId = data.product_id || undefined;
        }

        const newShortLink: ShortLink = {
          code: shortCode,
          originalLink: trimmedUrl,
          affiliateLink: finalAffiliateLink,
          createdBy: currentUsername,
          createdAt: new Date().toISOString(),
          clicks: 0,
          itemId: finalItemId
        };

        listLinks.unshift(newShortLink);
        saveShortLinks(listLinks);
        setGeneratedTikTokLink({
          originalLink: trimmedUrl,
          affiliateLink: finalAffiliateLink,
          productId: finalItemId || 'N/A',
          subId: finalSubId,
          createdAt: newShortLink.createdAt,
          code: shortCode
        });

        setProcessedLink({
          code: shortCode,
          originalLink: trimmedUrl,
          affiliateLink: finalAffiliateLink,
          platform: 'tiktok_shop',
          itemId: finalItemId,
          createdAt: newShortLink.createdAt
        });

        if (typeof (window as any).showToast === 'function') {
          (window as any).showToast('✅ Đã tạo link hoàn tiền thành công', 'success');
        }

        // Tự động sao chép
        const shortLinkVal = `cashback.thuydeal.site/${shortCode}`;
        try {
          await navigator.clipboard.writeText(shortLinkVal);
          setIsCopied(true);
          setTimeout(() => setIsCopied(false), 2000);
        } catch (e) {}

      } catch (err) {
        console.warn('Lỗi gọi TikTok RioHub, thực hiện fallback luồng chạy không ảnh hưởng:', err);
        // Fallback im lặng tạo rút gọn trực tiếp
        const newShortLink: ShortLink = {
          code: shortCode,
          originalLink: trimmedUrl,
          affiliateLink: trimmedUrl,
          createdBy: currentUsername,
          createdAt: new Date().toISOString(),
          clicks: 0
        };

        listLinks.unshift(newShortLink);
        saveShortLinks(listLinks);

        setProcessedLink({
          code: shortCode,
          originalLink: trimmedUrl,
          affiliateLink: trimmedUrl,
          platform: 'tiktok_shop',
          createdAt: newShortLink.createdAt
        });

        if (typeof (window as any).showToast === 'function') {
          (window as any).showToast('✅ Đã tạo link hoàn tiền thành công', 'success');
        }

        // Tự động sao chép
        const shortLinkVal = `cashback.thuydeal.site/${shortCode}`;
        try {
          await navigator.clipboard.writeText(shortLinkVal);
          setIsCopied(true);
          setTimeout(() => setIsCopied(false), 2000);
        } catch (e) {}
      } finally {
        setTiktokLoading(false);
      }
    }
  };

  // Nút Dán Link - Tích hợp đầy đủ Clipboard và Auto Process
  const handlePasteAndProcess = async () => {
    try {
      setClipboardBlocked(false);
      const text = await navigator.clipboard.readText();
      const urlText = text.trim();
      if (!urlText) {
        setErrorMsg('Bộ nhớ tạm (clipboard) hiện đang trống hoặc không chứa liên kết hợp lệ.');
        return;
      }

      setInputUrl(urlText);

      let targetPlatform: 'shopee' | 'tiktok_shop' = platform;
      const lowercaseVal = urlText.toLowerCase();
      if (lowercaseVal.includes('tiktok.com') || lowercaseVal.includes('vt.tiktok.com')) {
        targetPlatform = 'tiktok_shop';
        setPlatform('tiktok_shop');
      } else if (lowercaseVal.includes('shopee.vn') || lowercaseVal.includes('shope.ee')) {
        targetPlatform = 'shopee';
        setPlatform('shopee');
      }

      await handleProcess(urlText, targetPlatform);
    } catch (e) {
      console.warn('Lỗi truy cập clipboard:', e);
      setClipboardBlocked(true);
      // Im lặng bỏ qua lỗi clipboard, không báo lỗi đỏ lớn (setErrorMsg)
    }
  };

  // Submit form thủ công
  const handleGenerateLinkSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await handleProcess(inputUrl, platform);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  // Giả lập click link tracking của Shopee
  const handleSimulateClick = (link: ShortLink) => {
    const listLinks = getShortLinks();
    const updated = listLinks.map(l => {
      if (l.code === link.code) {
        return { ...l, clicks: l.clicks + 1 };
      }
      return l;
    });
    saveShortLinks(updated);
    
    setIsRedirecting(true);
    setTimeout(() => {
      setIsRedirecting(false);
      window.open(link.affiliateLink, '_blank', 'noopener,noreferrer');
    }, 1500);
  };

  // Người dùng đăng ký đơn hàng tự khai báo hỗ trợ cả Shopee và TikTok Shop
  const handleRegisterOrderGeneric = (e: React.FormEvent, type: 'shopee' | 'tiktok_shop') => {
    e.preventDefault();
    if (!orderCode.trim()) return;

    if (!currentUser) {
      onOpenAuthModal();
      return;
    }

    const orders = getOrders();
    const orderId = orderCode.trim();

    const existingOrderIndex = orders.findIndex(o => o.orderId === orderId);

    if (existingOrderIndex >= 0) {
      const order = orders[existingOrderIndex];
      if (!order.username || order.username === 'khach_vo_danh') {
        order.username = currentUser.username;
        if (!order.platform) {
          order.platform = type === 'shopee' ? 'shopee' : 'tiktok';
        }
        saveOrders(orders);
        setHasSubmittedOrder(true);
      } else {
        setErrorMsg('Mã đơn hàng này đã được khai báo bởi tài khoản khác.');
      }
    } else {
      const newOrder: Order = {
        orderId,
        username: currentUser.username,
        time: new Date().toISOString(),
        productName: type === 'shopee' ? 'Sản phẩm Shopee' : 'Sản phẩm TikTok Shop',
        status: 'pending_record',
        rebateAmount: 0,
        rawCommission: 0,
        platform: type === 'shopee' ? 'shopee' : 'tiktok'
      };
      orders.unshift(newOrder);
      saveOrders(orders);
      setHasSubmittedOrder(true);
    }
  };

  return (
    <div className="space-y-6">
      {/* Visual Title */}
      <div className="text-center space-y-1.5 py-2">
        <h2 className="font-serif text-2xl font-bold text-gray-800 flex items-center justify-center gap-1.5 animate-in fade-in">
          <span>Dán Link Nhận Hoàn Tiền</span>
          <span className="text-coquette-accent">🎀</span>
        </h2>
        <p className="text-xs text-gray-400">Dán link sản phẩm Shopee hoặc TikTok Shop để nhận hoàn tiền tự động và nhanh chóng</p>
      </div>

      {/* Main input card */}
      <div className="bg-white rounded-3xl p-6 border-2 border-[#FFD7E2] shadow-lg space-y-5">
        
        {/* Nền tảng hoàn tiền */}
        <div className="space-y-2 animate-in fade-in">
          <span className="text-[11px] font-black text-gray-500 tracking-wider block uppercase">Chọn Nền Tảng Mua Sắm:</span>
          <div className="grid grid-cols-2 gap-3">
            <label className={`flex items-center justify-center gap-2 h-11 text-[14px] md:text-[15px] font-semibold rounded-xl border-2 cursor-pointer transition-all duration-200 select-none ${
              platform === 'shopee'
                ? 'bg-[#FFF5F2] border-[#FF5722] text-[#FF5722] ring-2 ring-[#FF5722]/10'
                : 'bg-white border-[#FFE3EA] text-[#4B5563] hover:bg-stone-50'
            }`}>
              <input
                type="radio"
                name="platform"
                checked={platform === 'shopee'}
                onChange={() => { setPlatform('shopee'); setErrorMsg(''); }}
                className="sr-only"
              />
              <span>🧡 Shopee</span>
            </label>

            <label className={`flex items-center justify-center gap-2 h-11 text-[14px] md:text-[15px] font-semibold rounded-xl border-2 cursor-pointer transition-all duration-200 select-none ${
              platform === 'tiktok_shop'
                ? 'bg-[#FAF3F5] border-stone-900 text-stone-900 ring-2 ring-stone-900/5'
                : 'bg-white border-[#FFE3EA] text-[#4B5563] hover:bg-stone-50'
            }`}>
              <input
                type="radio"
                name="platform"
                checked={platform === 'tiktok_shop'}
                onChange={() => { setPlatform('tiktok_shop'); setErrorMsg(''); }}
                className="sr-only"
              />
              <span>🖤 TikTok Shop</span>
            </label>
          </div>
        </div>

        <form onSubmit={handleGenerateLinkSubmit} className="space-y-4">
          {/* Ô dán link sản phẩm tự động nhận diện */}
          <div className="space-y-2 text-left">
            <div className="flex items-center justify-between gap-1.5 flex-wrap">
              <label className="text-xs font-black text-gray-800 uppercase tracking-wide">
                Đường dẫn sản phẩm 🌸
              </label>
              <span className="inline-flex items-center justify-center h-6 text-[11px] bg-[#FFF2F4] border border-[#FFD7E2] text-[#FF6B8A] font-bold px-2 rounded-full leading-none">
                Tự nhận dạng link
              </span>
            </div>
            <div className="relative">
              <input
                type="text"
                required
                value={inputUrl}
                onChange={handleInputChange}
                placeholder="Dán link sản phẩm Shopee hoặc TikTok Shop tại đây..."
                className="w-full h-12 text-xs pl-4 pr-14 bg-stone-50 hover:bg-white focus:bg-white border-2 border-gray-300 focus:border-[#FF6B9D] focus:ring-4 focus:ring-[#FF6B9D]/15 rounded-xl outline-hidden transition-all text-gray-800 placeholder-gray-400 font-semibold shadow-inner"
              />
              <button
                type="button"
                onClick={handlePasteAndProcess}
                className="absolute right-1 top-1/2 -translate-y-1/2 w-11 h-11 bg-gradient-to-r from-[#FF6B9D] to-[#FF8A47] hover:opacity-95 text-white font-black rounded-lg transition-all cursor-pointer shadow-3xs flex items-center justify-center"
                title="Dán từ clipboard"
              >
                <span className="text-base">📋</span>
              </button>
            </div>
            {clipboardBlocked && (
              <p className="text-[10px] text-gray-500 font-medium font-sans mt-1">
                💡 Không thể tự động đọc clipboard. Bạn vui lòng dán link trực tiếp vào ô sản phẩm bên trên nhé!
              </p>
            )}
          </div>

          {errorMsg && (
            <div className="flex items-start gap-2 text-xs text-red-500 bg-red-100/50 border border-red-300 px-3.5 py-2.5 rounded-xl font-medium">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
              <span>{errorMsg}</span>
            </div>
          )}
        </form>
      </div>

      {(productLoading || tiktokLoading) && !processedLink && (
        <div className="bg-white rounded-3xl p-5 border border-coquette-deep/45 shadow-sm flex flex-col items-center justify-center gap-3 py-8 animate-pulse text-center">
          <RefreshCw className="w-5 h-5 animate-spin text-coquette-accent" />
          <span className="text-xs text-gray-500 font-extrabold font-sans">⏳ Đang tự động xử lý liên kết hoàn tiền...</span>
        </div>
      )}

      {/* HIỂN THỊ KẾT QUẢ ĐỒNG BỘ MỚI */}
      {processedLink && (
        <div className="bg-white rounded-3xl p-5 border-2 border-coquette-deep shadow-md space-y-5 animate-in fade-in duration-300">
          
          {/* Header kết quả */}
          <div className="flex gap-2.5 items-center pb-3 border-b border-dashed border-coquette-deep/30">
            <div className="w-8 h-8 rounded-full bg-coquette-pink flex items-center justify-center text-md">✨</div>
            <div>
              <h3 className="text-xs font-bold text-emerald-600">Liên kết hoàn tiền đã tạo thành công 🎉</h3>
              <p className="text-[10px] text-gray-400">Mã đơn hàng và tiền hoàn sẽ được ghi nhận tự động vào ví của bạn</p>
            </div>
          </div>

          {/* Hiển thị chi tiết sản phẩm nếu có thông tin (AddLiveTag) */}
          {productLoading && (
            <div className="bg-white rounded-2xl p-4 border border-coquette-deep/40 shadow-xs flex items-center justify-center gap-2 py-6 animate-pulse text-left">
              <RefreshCw className="w-4 h-4 animate-spin text-coquette-accent" />
              <span className="text-xs text-gray-500 font-semibold font-sans">⏳ Đang tải thông tin sản phẩm...</span>
            </div>
          )}

          {productInfo && !productLoading && (
            <div className="bg-coquette-pink/10 rounded-2xl p-4 border border-coquette-deep shadow-3xs text-left space-y-3 animate-in zoom-in duration-200">
              <div className="flex items-center gap-1.5 pb-2 border-b border-dashed border-coquette-deep/30">
                <span className="text-sm">📦</span>
                <span className="font-serif text-xs font-black text-coquette-accent uppercase tracking-wider">Thông Tin Sản Phẩm</span>
              </div>
              
              <div className="flex flex-row gap-4 items-center">
                {productInfo.imageUrl && (
                  <div className="w-16 h-16 rounded-xl overflow-hidden border border-coquette-deep/20 shrink-0 bg-white flex items-center justify-center">
                    <img 
                      src={productInfo.imageUrl} 
                      alt={productInfo.productName} 
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                
                <div className="flex-1 space-y-1.5 min-w-0">
                  <h4 className="text-xs font-bold text-gray-800 leading-tight line-clamp-2">
                    {productInfo.productName}
                  </h4>
                  
                  <div className="flex flex-wrap gap-2 items-center text-[10px]">
                    <span className="font-extrabold text-rose-650 bg-rose-50 px-2 py-0.5 rounded-md font-mono">
                      {typeof productInfo.price === 'number' 
                        ? `${productInfo.price.toLocaleString('vi-VN')}đ` 
                        : String(productInfo.price).endsWith('đ') || String(productInfo.price).includes('đ')
                          ? productInfo.price 
                          : `${productInfo.price}đ`}
                    </span>
                    
                    {productInfo.rating && (
                      <span className="text-amber-500 bg-amber-50 px-2 py-0.5 rounded-md font-bold flex items-center gap-0.5">
                        ⭐ {productInfo.rating}
                      </span>
                    )}
                  </div>

                  {productInfo.shopName && (
                    <p className="text-[10px] text-gray-500 truncate">
                      Cửa hàng: <span className="text-gray-700 font-semibold">{productInfo.shopName}</span>
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Phần dải liên kết rút gọn */}
          <div className="space-y-3">
            <div className="space-y-1 text-left">
              <span className="text-[10px] uppercase font-bold tracking-wider text-coquette-accent block">Liên kết rút gọn tự động:</span>
              <div className="flex items-center gap-2 bg-coquette-cream/50 p-2.5 rounded-xl border border-coquette-deep/30">
                <span className="font-mono text-xs text-gray-650 truncate flex-1 select-all font-semibold">
                  cashback.thuydeal.site/{processedLink.code}
                </span>
                <button
                  onClick={() => copyToClipboard(`cashback.thuydeal.site/${processedLink.code}`)}
                  className="bg-white text-coquette-accent border border-coquette-deep hover:bg-coquette-pink p-1.5 rounded-lg transition-all shrink-0 cursor-pointer"
                  title="Sao chép liên kết"
                >
                  {isCopied ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Clipboard className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {/* Chi tiết kĩ thuật cho admin */}
            {isAdmin && (processedLink.shopId || processedLink.itemId) && (
              <div className="bg-coquette-pink/15 px-3 py-2 rounded-xl border border-coquette-deep/20 text-[10px] text-gray-500 flex justify-between font-mono">
                <span>Shop ID: <strong className="font-bold text-gray-750">{processedLink.shopId || 'N/A'}</strong></span>
                <span>Product ID: <strong className="font-bold text-gray-750">{processedLink.itemId || 'N/A'}</strong></span>
              </div>
            )}
          </div>

          <div className="border-t border-dashed border-coquette-deep/30 my-2" />

          {/* Hướng dẫn và Nút mua sắm */}
          <div className="bg-gradient-to-br from-pink-50 to-coquette-pink/30 p-5 rounded-2xl border-2 border-coquette-deep/50 space-y-3.5 text-left">
            <span className="text-sm font-extrabold text-coquette-accent block tracking-wide uppercase">
              {processedLink.platform === 'shopee' ? '🧡 CÁCH TRÁNH THẤT LẠC ĐƠN SHOPEE' : '🖤 CÁCH TRÁNH THẤT LẠC ĐƠN TIKTOK'}
            </span>
            <div className="space-y-2 text-xs text-gray-750 leading-relaxed">
              <p>✅ Bấm “{processedLink.platform === 'shopee' ? 'MỞ SHOPEE & MUA NGAY' : 'MỞ TIKTOK SHOP MUA NGAY'}”</p>
              <p>✅ Chỉ mua sản phẩm sau khi bấm qua nút định tuyến bên dưới</p>
              <p>✅ Đảm bảo giỏ hàng trống hoặc xóa đi thêm lại sản phẩm sau khi click</p>
              <p>✅ Thanh toán thành công và quay lại trang web này dán mã đơn hàng</p>
            </div>

            {processedLink.platform === 'shopee' ? (
              <button
                onClick={() => handleSimulateClick({
                  code: processedLink.code,
                  originalLink: processedLink.originalLink,
                  affiliateLink: processedLink.affiliateLink,
                  createdBy: currentUser?.username || 'khach_vo_danh',
                  createdAt: processedLink.createdAt,
                  clicks: 0
                })}
                disabled={isRedirecting}
                className={`w-full py-3 px-4 rounded-xl text-xs font-extrabold text-white transition-all shadow-sm flex items-center justify-center gap-1.5 cursor-pointer border-none ${
                  isRedirecting 
                    ? 'bg-orange-350' 
                    : 'bg-gradient-to-r from-orange-500 to-orange-600 hover:opacity-95'
                }`}
              >
                {isRedirecting ? (
                  <span className="animate-pulse">Đang định tuyến sang Shopee... 🐰</span>
                ) : (
                  <>
                    <span>MỞ SHOPEE & MUA NGAY 🎀</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            ) : (
              <button
                onClick={() => {
                  handleSimulateClick({
                    code: processedLink.code,
                    originalLink: processedLink.originalLink,
                    affiliateLink: processedLink.affiliateLink,
                    createdBy: currentUser?.username || 'khach_vo_danh',
                    createdAt: processedLink.createdAt,
                    clicks: 0
                  });
                }}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs py-3 rounded-xl transition-all shadow-sm flex items-center justify-center gap-1.5 cursor-pointer border-none"
              >
                <span>MỞ TIKTOK SHOP MUA NGAY</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Khai Báo Đơn Hàng */}
          <div className="space-y-3 bg-pink-50/75 p-5 rounded-2xl border-2 border-dashed border-coquette-accent shadow-xs text-left">
            <div className="space-y-1">
              <span className="text-xs font-black text-coquette-accent flex items-center gap-1.5 uppercase tracking-wide font-sans">
                <span>📦 KHAI BÁO MÃ ĐƠN HÀNG MUA SẮM (KHÔNG BẮT BUỘC)</span>
              </span>
              <p className="text-[10.5px] text-gray-650 leading-relaxed font-sans">
                Khai báo mã đơn là không bắt buộc nhưng được khuyến khích để hệ thống hỗ trợ đối soát nhanh hơn khi phát sinh lỗi đồng bộ.
              </p>
            </div>

            {hasSubmittedOrder ? (
              <div className="bg-emerald-50 text-emerald-700 p-3.5 rounded-xl border border-emerald-200 text-center text-xs space-y-1 animate-in zoom-in duration-200 font-sans">
                <p className="font-bold flex items-center justify-center gap-1 text-emerald-800 uppercase tracking-tight">
                  <Check className="w-4 h-4 text-emerald-600 font-bold" />
                  <span>Khai báo đơn hàng thành công!</span>
                </p>
                <p className="text-[10px] text-emerald-650">
                  Mã đơn <strong className="font-mono font-bold">{orderCode}</strong> đã được lưu thành công trên hệ thống đối soát.
                </p>
              </div>
            ) : (
              <form onSubmit={(e) => handleRegisterOrderGeneric(e, processedLink.platform)} className="flex gap-2">
                <input
                  type="text"
                  required
                  value={orderCode}
                  onChange={(e) => setOrderCode(e.target.value)}
                  placeholder={processedLink.platform === 'shopee' ? 'Nhập mã đơn Shopee đã đặt' : 'Nhập mã đơn TikTok Shop đã đặt'}
                  className="flex-1 text-xs px-3 py-2 bg-white border-2 border-rose-200 focus:border-coquette-accent rounded-lg outline-hidden text-gray-700 font-mono font-bold shadow-3xs placeholder:text-gray-400 placeholder:font-sans"
                />
                <button
                  type="submit"
                  className="bg-coquette-accent hover:bg-opacity-95 text-white font-bold px-4 py-2 rounded-lg text-xs transition-all shrink-0 cursor-pointer shadow-3xs uppercase"
                >
                  Gửi mã
                </button>
              </form>
            )}
          </div>

          <div className="border-t border-dashed border-coquette-deep/30 my-2" />

          {/* Chú ý */}
          <div className="bg-rose-50/80 p-4 rounded-xl border border-rose-200/60 text-[10.5px] text-rose-700 space-y-2 text-left">
            <p className="font-bold flex items-center gap-1">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
              <span>⚠️ CHÚ Ý: TRÁNH MẤT TIỀN HOÀN CHẮC CHẮN</span>
            </p>
            <ul className="list-disc pl-4 space-y-1 leading-relaxed">
              <li><strong className="font-bold text-rose-800">Không mua qua:</strong> Shopee Live, Live TikTok trực tiếp nếu không click lại link, KOC/KOL khát.</li>
              <li>Sản phẩm phải được thanh toán trong vòng 30 phút kể từ lúc bấm liên kết này.</li>
              <li>Đảm bảo không click qua các kênh quảng cáo hoặc hoàn tiền khác trước lúc bấm mua.</li>
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}
