import React, { useState } from 'react';
import { Menu, X, User as UserIcon, LogOut, Wallet, Shield, Sparkles, RefreshCw, Bell } from 'lucide-react';
import { User } from '../types';
import { getInternalNotifications } from '../data';

interface CoquetteHeaderProps {
  currentUser: User | null;
  onLogout: () => void;
  setCurrentView: (view: string) => void;
  currentView: string;
  onOpenAuthModal: () => void;
  isAdminMode: boolean;
}

export default function CoquetteHeader({
  currentUser,
  onLogout,
  setCurrentView,
  currentView,
  onOpenAuthModal,
  isAdminMode,
}: CoquetteHeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  React.useEffect(() => {
    if (currentUser) {
      const getUnread = () => {
        try {
          const list = getInternalNotifications();
          const count = list.filter((n: any) => n.username === currentUser.username && !n.isRead).length;
          setUnreadCount(count);
        } catch (e) {}
      };
      getUnread();
      const interval = setInterval(getUnread, 3000);
      return () => clearInterval(interval);
    } else {
      setUnreadCount(0);
    }
  }, [currentUser]);

  const mainItems = [
    { label: 'Trang Chủ 🏠', view: 'home' },
    { label: 'Tạo Link Hoàn Tiền 🛍️', view: 'cashback' },
    { label: 'Ví Tiền & Đơn Hàng 💳', view: 'wallet' },
  ];

  const subItems = [
    { label: 'Lịch Sử Link 📋', view: 'link_history' },
    { label: 'Đổi Voucher 🎁', view: 'vouchers' },
    { label: 'Tìm Đơn Thất Lạc 🔍', view: 'lost_order' },
    { label: 'Giới Thiệu Bạn Bè 👭', view: 'referrals' },
    { label: 'Cộng Đồng 💬', view: 'comments' },
    { label: 'Trang Quản Trị 👑', view: 'admin', requireAdmin: true },
  ];

  const handleNav = (view: string) => {
    setCurrentView(view);
    setIsMenuOpen(false);
  };

  const renderButton = (item: { label: string; view: string; requireAdmin?: boolean }) => {
    if (item.requireAdmin && (!currentUser || currentUser.role !== 'admin')) {
      return null;
    }
    const isActive = currentView === item.view;
    return (
      <button
        key={item.view}
        onClick={() => handleNav(item.view)}
        className={`flex items-center justify-between py-3 px-4 rounded-[16px] text-[12.5px] transition-all duration-300 text-left cursor-pointer border-2 font-bold select-none h-11 w-full hover:scale-101 active:scale-97 text-stone-850 ${
          isActive 
            ? 'bg-[#FFF0F2] text-[#FF4D79] border-[#FF4D79] shadow-md font-extrabold' 
            : 'bg-[#FCFAF9] text-gray-800 border-gray-200/90 hover:bg-[#FFF0F2]/50 hover:text-[#FF4D79] hover:border-[#FFB7C5] shadow-3xs'
        }`}
      >
        <span>{item.label}</span>
        {isActive && <span className="text-[10px] text-[#FF4D79] animate-pulse">●</span>}
      </button>
    );
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b-2 border-coquette-deep/40 shadow-xs">
      <div className="max-w-md md:max-w-3xl mx-auto px-2 md:px-4 py-3 flex justify-between items-center gap-1.5">
        {/* Logo and Menu toggle */}
        <div className="flex items-center gap-1.5 shrink-0 min-w-[150px]">
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="p-1 text-coquette-accent hover:bg-coquette-pink rounded-full transition-colors duration-200 cursor-pointer shrink-0"
            id="menu-toggle-btn"
          >
            {isMenuOpen ? <X className="w-5.5 h-5.5" /> : <Menu className="w-5.5 h-5.5" />}
          </button>
          
          <button 
            onClick={() => handleNav('home')}
            className="flex items-center gap-1 font-serif text-[#FF4D79] bg-gradient-to-r from-[#FFF0F2]/95 to-[#FFF7F0]/95 border-[1px] border-[#FFA6B7] px-2.5 py-1 rounded-full shadow-3xs hover:shadow-2xs transition-all duration-300 cursor-pointer h-9 md:h-11 hover:scale-102 hover:-translate-y-0.5 active:scale-98 select-none shrink-0"
          >
            <span className="text-[13px] md:text-[15px] animate-pulse shrink-0">🎀</span>
            <span className="tracking-tight text-gray-850 font-black whitespace-nowrap text-[16px] md:text-[18px]">Mê Hoàn Xu</span>
          </button>
        </div>

        {/* User profile action */}
        <div className="shrink-0">
          {currentUser ? (
            <div className="flex items-center gap-1 md:gap-1.5">
              <button
                onClick={() => handleNav('wallet')}
                className="flex items-center gap-0.5 md:gap-1 bg-coquette-pink px-2 md:px-2.5 py-1 md:py-1.5 rounded-full text-[11px] md:text-xs font-semibold text-coquette-accent border border-coquette-deep/50 hover:bg-white hover:border-coquette-accent transition-all cursor-pointer shadow-3xs whitespace-nowrap"
              >
                <Wallet className="w-3 h-3 md:w-3.5 md:h-3.5" />
                <span>{currentUser.availableBalance.toLocaleString('vi-VN')}đ</span>
              </button>

              <button
                onClick={() => handleNav('notifications')}
                className="p-1 md:p-1.5 text-gray-400 hover:text-coquette-accent rounded-full hover:bg-coquette-pink transition-colors cursor-pointer relative shrink-0"
                title={`${unreadCount} thông báo mới`}
              >
                <Bell className="w-4 h-4 md:w-4.5 md:h-4.5" />
                {unreadCount > 0 && (
                  <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 bg-rose-500 rounded-full animate-bounce" />
                )}
              </button>
              
              <button
                onClick={onLogout}
                className="p-1 md:p-1.5 text-gray-400 hover:text-coquette-accent rounded-full hover:bg-coquette-pink transition-colors cursor-pointer shrink-0"
                title="Đăng xuất"
              >
                <LogOut className="w-4 h-4 md:w-4.5 md:h-4.5" />
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenAuthModal}
              className="bg-coquette-accent hover:bg-coquette-accent/90 text-white font-medium text-[11px] md:text-xs px-2.5 md:px-4 py-1.5 rounded-full transition-all duration-200 cursor-pointer flex items-center gap-1 shadow-xs border border-transparent active:scale-95 whitespace-nowrap shrink-0"
            >
              <UserIcon className="w-3 h-3 md:w-3.5 md:h-3.5" />
              <span>Đăng Nhập</span>
            </button>
          )}
        </div>
      </div>

      {/* Slide Navigation Menu (Drawer style optimized for mobile with increased pop out and groups) */}
      {isMenuOpen && (
        <div className="absolute top-100% left-0 w-full bg-[#FFFCFD] border-b-3 border-[#FFA6B7] shadow-[0_25px_60px_rgba(255,77,121,0.22)] z-55 animate-in slide-in-from-top-4 duration-250">
          <div className="max-w-md mx-auto py-5 px-5 space-y-4 text-left">
            
            {/* NHÓM CHÍNH */}
            <div className="space-y-2">
              <div className="text-[10.5px] uppercase font-black text-[#FF4D79] tracking-wider flex items-center gap-1 justify-between">
                <span>MENU CHÍNH 🌟</span>
                <span className="text-[9px] text-[#FF8A3D] font-bold bg-amber-50 border border-amber-200 px-1.5 py-0.5 rounded-md">Ưu tiên</span>
              </div>
              <div className="grid grid-cols-1 gap-2.5">
                {mainItems.map(item => renderButton(item))}
              </div>
            </div>

            {/* NHÓM PHỤ */}
            <div className="space-y-2 pt-2 border-t border-dashed border-[#FFC7D3]">
              <div className="text-[10.5px] uppercase font-black text-gray-400 tracking-wider">
                HỆ THỐNG TIỆN ÍCH 🎀
              </div>
              <div className="grid grid-cols-2 gap-2">
                {subItems.map(item => renderButton(item))}
              </div>
            </div>
            
            <div className="pt-3 border-t border-gray-150 flex justify-between items-center text-[10.5px] font-bold text-gray-400">
              <span className="flex items-center gap-1">✨ Shopee & TikTok Cashback</span>
              <span>thuydeal.site</span>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
