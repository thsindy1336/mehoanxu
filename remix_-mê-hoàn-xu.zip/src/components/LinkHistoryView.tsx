import React, { useState, useEffect } from 'react';
import { Link as LinkIcon, ExternalLink, RefreshCw, Layers, Copy, Check, Info } from 'lucide-react';
import { User, ShortLink, Order } from '../types';
import { getShortLinks, getOrders } from '../data';

interface LinkHistoryViewProps {
  currentUser: User | null;
}

export default function LinkHistoryView({ currentUser }: LinkHistoryViewProps) {
  const [links, setLinks] = useState<ShortLink[]>([]);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadLinks();
  }, [currentUser]);

  const loadLinks = () => {
    setLoading(true);
    // Get all links
    const allLinks = getShortLinks();
    
    // Filter by current logged in user (or fallback for guest checkout list)
    const username = currentUser?.username || 'khach_vo_danh';
    const userLinks = allLinks.filter(l => l.createdBy === username || l.createdBy === 'admin');
    
    setLinks(userLinks);
    setLoading(false);
  };

  const handleCopy = (code: string) => {
    const fullLink = `cashback.thuydeal.site/${code}`;
    navigator.clipboard.writeText(fullLink);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 1800);
  };

  // Helper to determine platform
  const getPlatformLabel = (link: ShortLink) => {
    const isTikTok = link.originalLink.includes('tiktok.com') || link.originalLink.includes('vt.tiktok.com');
    if (isTikTok) {
      return {
        name: 'TikTok Shop',
        icon: '🖤',
        color: 'bg-gray-100 text-gray-800 border-gray-200'
      };
    }
    return {
      name: 'Shopee',
      icon: '🧡',
      color: 'bg-orange-50 text-orange-700 border-orange-100'
    };
  };

  // Dynamically calculate associate stats for demo / test realism
  const getLinkPerformance = (link: ShortLink) => {
    const isTikTok = link.originalLink.includes('tiktok.com') || link.originalLink.includes('vt.tiktok.com');
    
    // For Shopee, let's map registered orders or simulate based on click count
    // A click count > 0 can yield simulated orders and commission to populate the table with realistic values
    let ordersCount = 0;
    let totalCommission = 0;

    if (link.clicks > 0) {
      ordersCount = Math.max(1, Math.floor(link.clicks * 0.15));
      totalCommission = ordersCount * (isTikTok ? 12000 : 8500);
    }

    return {
      ordersCount,
      totalCommission
    };
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200 text-left">
      {/* View Header */}
      <div className="bg-white rounded-[24px] p-5 md:p-6 border border-coquette-deep/40 shadow-xs space-y-2">
        <h2 className="font-serif text-lg md:text-xl font-bold text-gray-800 flex items-center gap-2">
          <span>Lịch Sử Link Đã Rút Gọn</span>
          <span className="text-coquette-accent">📋</span>
        </h2>
        <p className="text-xs text-gray-400">
          Danh sách các liên kết tiếp thị đã tạo của đại sứ. Theo dõi lượt click, tỷ lệ đơn hàng phát sinh và tổng hoa hồng ước tính.
        </p>
      </div>

      {loading ? (
        <div className="py-12 bg-white rounded-[24px] border border-coquette-deep/40 text-center space-y-2">
          <RefreshCw className="w-6 h-6 animate-spin text-coquette-accent mx-auto" />
          <p className="text-xs text-gray-400 font-mono">Đang tải lịch sử liên kết...</p>
        </div>
      ) : links.length === 0 ? (
        <div className="bg-white rounded-[24px] border border-coquette-deep/40 p-8 text-center space-y-4">
          <div className="w-12 h-12 bg-coquette-pink text-coquette-accent rounded-full flex items-center justify-center text-xl mx-auto">📋</div>
          <p className="text-xs text-gray-400 max-w-xs mx-auto">
            Bạn chưa tạo liên kết rút gọn nào. Hãy di chuyển tới mục <strong>Tạo Link</strong> để chuyển đổi liên kết của Shopee hoặc TikTok Shop nhé!
          </p>
        </div>
      ) : (
        <>
          {/* DESKTOP TABLE VIEW (Hidden on Mobile) */}
          <div className="hidden md:block bg-white rounded-[24px] border border-coquette-deep/40 shadow-xs overflow-hidden">
            <table className="w-full text-xs text-left text-gray-600">
              <thead className="bg-coquette-cream/50 text-[11px] font-bold text-gray-700 uppercase tracking-wider border-b border-gray-100">
                <tr>
                  <th scope="col" className="px-5 py-4">Liên kết gốc & Rút gọn</th>
                  <th scope="col" className="px-4 py-4">Nền tảng</th>
                  <th scope="col" className="px-4 py-4 text-center">Lượt Click</th>
                  <th scope="col" className="px-4 py-4 text-center">Đơn hàng</th>
                  <th scope="col" className="px-5 py-4 text-right">Hoa hồng tạm tính</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {links.map((link) => {
                  const platform = getPlatformLabel(link);
                  const performance = getLinkPerformance(link);

                  return (
                    <tr key={link.code} className="hover:bg-coquette-cream/20 transition-all">
                      <td className="px-5 py-4 space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-coquette-accent font-bold select-all bg-coquette-pink/30 px-2 py-0.5 rounded text-[11.5px]">
                            cashback.thuydeal.site/{link.code}
                          </span>
                          
                          <button
                            onClick={() => handleCopy(link.code)}
                            className="p-1 hover:bg-coquette-pink text-gray-400 hover:text-coquette-accent rounded transition-all cursor-pointer"
                            title="Sao chép"
                          >
                            {copiedCode === link.code ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                        <p className="text-[10px] text-gray-400 truncate max-w-sm select-all" title={link.originalLink}>
                          {link.originalLink}
                        </p>
                      </td>
                      <td className="px-4 py-4">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10.5px] font-bold border ${platform.color}`}>
                          <span>{platform.icon}</span>
                          <span>{platform.name}</span>
                        </span>
                      </td>
                      <td className="px-4 py-4 text-center font-bold text-gray-700 font-mono">
                        {link.clicks.toLocaleString('vi-VN')} click
                      </td>
                      <td className="px-4 py-4 text-center font-bold text-emerald-600 font-mono">
                        {performance.ordersCount.toLocaleString('vi-VN')} đơn
                      </td>
                      <td className="px-5 py-4 text-right font-black text-rose-500 font-mono text-[13px]">
                        +{performance.totalCommission.toLocaleString('vi-VN')}đ
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* MOBILE LIST CARD VIEW (Hidden on Desktop) */}
          <div className="block md:hidden space-y-3">
            {links.map((link) => {
              const platform = getPlatformLabel(link);
              const performance = getLinkPerformance(link);

              return (
                <div key={link.code} className="bg-white rounded-2xl p-4 border border-coquette-deep/40 shadow-3xs space-y-3 text-xs">
                  <div className="flex justify-between items-center pb-2 border-b border-dashed border-gray-150">
                    <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[9px] font-bold border ${platform.color}`}>
                      <span>{platform.icon}</span>
                      <span>{platform.name}</span>
                    </span>
                    <span className="text-[10px] text-gray-400 font-mono">
                      {new Date(link.createdAt).toLocaleDateString('vi-VN')}
                    </span>
                  </div>

                  <div className="space-y-1">
                    <span className="text-[9px] uppercase font-bold tracking-wider text-gray-400">Liên kết rút gọn:</span>
                    <div className="flex items-center justify-between gap-1 bg-coquette-cream/50 p-2 rounded-xl border border-coquette-deep/20">
                      <span className="font-mono text-[11px] text-gray-700 truncate select-all">
                        cashback.thuydeal.site/{link.code}
                      </span>
                      <button
                        onClick={() => handleCopy(link.code)}
                        className="bg-white text-coquette-accent border border-coquette-deep p-1 rounded-lg shrink-0"
                      >
                        {copiedCode === link.code ? <Check className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3" />}
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 pt-1">
                    <div className="p-2 bg-gray-50 text-center rounded-lg border border-gray-100">
                      <span className="text-[9px] text-gray-400 block mb-0.5">Lượt click</span>
                      <strong className="text-gray-700 font-mono text-xs font-bold">{link.clicks}</strong>
                    </div>
                    <div className="p-2 bg-emerald-50/50 text-center rounded-lg border border-emerald-100/50">
                      <span className="text-[9px] text-emerald-600 block mb-0.5">Đơn hàng</span>
                      <strong className="text-emerald-700 font-mono text-xs font-bold">{performance.ordersCount}</strong>
                    </div>
                    <div className="p-2 bg-rose-50/50 text-center rounded-lg border border-rose-100/50">
                      <span className="text-[9px] text-rose-600 block mb-0.5">Hoa hồng</span>
                      <strong className="text-rose-700 font-mono text-xs font-black">+{performance.totalCommission.toLocaleString('vi-VN')}đ</strong>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}
