import React, { useState, useEffect } from 'react';
import { Sparkles, ArrowRight, TrendingUp } from 'lucide-react';
import { User, Order } from '../types';
import { getWebContent, getDashboardStats, getUsers, getOrders, getShortLinks } from '../data';
// @ts-ignore
import mascotImage from '../assets/images/cashback_savings_mascot_1781341472211.jpg';

interface HomeViewProps {
  currentUser: User | null;
  setCurrentView: (view: string) => void;
  onOpenAuthModal: () => void;
}

export default function HomeView({ currentUser, setCurrentView, onOpenAuthModal }: HomeViewProps) {
  const [activeTab, setActiveTab] = useState<'shopee' | 'policy' | 'tips'>('shopee');
  const webContent = getWebContent();
  
  const isAdmin = currentUser?.role === 'admin';
  const stats = isAdmin ? getDashboardStats() : { totalOrders: 0, totalCashbackPaid: 0, totalUsers: 0, totalLinksCreated: 0 };

  const allOrders = isAdmin ? getOrders() : [];
  const allUsers = isAdmin ? getUsers() : [];
  const allLinks = isAdmin ? getShortLinks() : [];

  const [userStats, setUserStats] = useState({
    myOrders: 0,
    myCashback: 0,
    myLinks: 0,
    monthIncome: 0,
    todayIncome: 0
  });

  const [showPopup, setShowPopup] = useState(false);

  useEffect(() => {
    // Disabled system welcome popup per user request to improve user experience
    setShowPopup(false);
  }, [webContent.showPopup]);

  useEffect(() => {
    if (currentUser && currentUser.role !== 'admin') {
      const username = currentUser.username;
      
      const allOrders = getOrders();
      const userOrders = allOrders.filter(o => o.username === username);
      
      const myOrders = userOrders.length;
      const myCashback = userOrders.reduce((sum, o) => sum + (o.rebateAmount || 0), 0);
      
      const allLinks = getShortLinks();
      const myLinks = allLinks.filter(l => l.createdBy === username).length;
      
      const now = new Date();
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      
      const monthOrders = userOrders.filter(o => {
        const oDate = new Date(o.time);
        return oDate >= startOfMonth;
      });
      const monthIncome = monthOrders.reduce((sum, o) => sum + (o.rebateAmount || 0), 0);
      
      const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const todayOrders = userOrders.filter(o => {
        const oDate = new Date(o.time);
        return oDate >= startOfToday;
      });
      const todayIncome = todayOrders.reduce((sum, o) => sum + (o.rebateAmount || 0), 0);
      
      setUserStats({
        myOrders,
        myCashback,
        myLinks,
        monthIncome,
        todayIncome
      });
    }
  }, [currentUser]);

  const closePopup = () => {
    sessionStorage.setItem('mhx_home_popup_closed', 'true');
    setShowPopup(false);
  };

  const steps = [
    {
      step: '01',
      title: webContent.step1_title,
      desc: webContent.step1_desc,
      icon: '🔍',
    },
    {
      step: '02',
      title: webContent.step2_title,
      desc: webContent.step2_desc,
      icon: '🎀',
    },
    {
      step: '03',
      title: webContent.step3_title,
      desc: webContent.step3_desc,
      icon: '🛒',
    },
    {
      step: '04',
      title: webContent.step4_title,
      desc: webContent.step4_desc,
      icon: '👛',
    }
  ];

  return (
    <div className="space-y-6">
      {/* Upgraded Hero Brand Banner - Compact version */}
      <div className="relative w-full overflow-hidden bg-gradient-to-br from-[#FFF2F4] via-[#FFF9FA] to-[#FFF5ED] rounded-[20px] border-2 border-[#FFABC0] shadow-3xs py-2 px-4 sm:py-2.5 sm:px-5 transition-all duration-300 group/banner flex flex-col justify-center text-left">
        
        {/* Soft floating background accents like background in design */}
        <div className="absolute top-1 right-1/4 text-xs opacity-30 select-none animate-pulse">🌸</div>
        <div className="absolute bottom-1 left-12 text-xs opacity-30 select-none animate-bounce delay-700">🍑</div>
        <div className="absolute top-1/2 left-[2%] text-[9px] opacity-25 select-none animate-ping">✨</div>

        {/* Decorative curvy base background for premium branding wave */}
        <div className="absolute inset-0 pointer-events-none select-none opacity-20">
          <svg className="w-full h-full" viewBox="0 0 1000 200" fill="none" xmlns="http://www.w3.org/2050/svg" preserveAspectRatio="none">
            <path d="M0 120C150 90 320 140 480 115C640 90 820 60 1000 80V200H0V120Z" fill="white" />
          </svg>
        </div>

        {/* Inner Content - Adjusted to take 100% full width and show high-contrast typography */}
        <div className="relative z-10 w-full flex flex-col space-y-1.5 select-none">
          
          {/* Top Logo Pill Tag */}
          <div className="flex">
            <div className="inline-flex items-center gap-1 bg-white/95 border border-[#FFB7C5] px-2 py-0.5 rounded-full text-[8.5px] sm:text-[9.5px] text-[#FF4D79] font-black tracking-wide shadow-3xs group-hover/banner:scale-101 transition-transform duration-300">
              <span>🌸</span>
              <span className="font-extrabold font-sans text-[8.5px] sm:text-[9.5px]">Mê Hoàn Xu Shop • Hoàn Tiền Tự Động</span>
              <span className="w-1.5 h-1.5 bg-[#FF8A3D] rounded-full animate-ping"></span>
            </div>
          </div>

          <div className="flex flex-col items-start space-y-1.5 max-w-4xl text-left">
            <div className="space-y-0.5">
              {/* Secondary Title */}
              <div className="flex">
                <span className="font-sans font-extrabold text-[#FF8A3D] uppercase tracking-widest text-[7.5px] sm:text-[8.5px] bg-amber-50/90 px-1 py-0.5 rounded-md border border-[#FFD2DC] block shadow-3xs">
                  🎁 HOÀN TIỀN SHOPEE & TIKTOK SHOP
                </span>
              </div>
              
              {/* Main Prominent bold brand typography */}
              <h1 className="font-serif text-sm sm:text-lg md:text-xl font-black text-[#262626] tracking-tight leading-snug select-text">
                <span className="text-[#FF4D79]">Hoàn Tiền Xu</span>
                <span> Lên Đến 20%</span>
              </h1>
            </div>

            {/* High-visibility Brand Slogan Description - Slightly smaller to avoid clutter */}
            <p className="text-[#2B2B2B] text-[9.5px] sm:text-[11px] font-semibold max-w-3xl leading-relaxed select-text">
              💰 Dán link sản phẩm, mua hàng và nhận hoàn tiền tự động sau khi đơn hàng được đối soát.
            </p>

            {/* Mega Call to Action button - Moderately smaller for higher density */}
            <div className="pt-0.5">
              <button
                onClick={() => setCurrentView('cashback')}
                className="group/btn inline-flex items-center gap-1 bg-gradient-to-r from-[#FF4D79] to-[#FF7A2B] hover:from-[#FF2E60] hover:to-[#FF6B14] text-white font-extrabold text-[9px] sm:text-[10px] px-3.5 py-1 rounded-full transition-all cursor-pointer shadow-3xs hover:shadow-2xs hover:scale-101 active:scale-98 border border-white"
              >
                <span className="uppercase tracking-wider">HOÀN TIỀN NGAY</span>
                <ArrowRight className="w-3 h-3 group-hover/btn:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
        </div>

          {/* Bottom Banner Status Bar */}
          <div className="hidden sm:flex mt-1 pt-1.5 border-t border-dashed border-[#FFC7D3] justify-between items-center text-[9px] text-gray-750 font-bold font-sans gap-2 w-full max-w-full overflow-hidden select-none">
            <span className="flex items-center gap-0.5 bg-white/95 px-1.5 py-0.5 rounded-full border border-[#FFD2DC] shadow-3xs">🛍️ Mua sắm dễ dàng</span>
            <span className="flex items-center gap-0.5 bg-white/95 px-1.5 py-0.5 rounded-full border border-[#FFD2DC] shadow-3xs">💰 Hoàn xu cực khủng</span>
            <span className="flex items-center gap-0.5 bg-white/95 px-1.5 py-0.5 rounded-full border border-[#FFD2DC] shadow-3xs">💳 Rút tiền siêu nhanh</span>
            <span className="flex items-center gap-0.5 bg-white/95 px-1.5 py-0.5 rounded-full border border-[#FFD2DC] shadow-3xs">🛡️ An toàn rút ví 100%</span>
          </div>

        </div>

      {/* Main utilities dashboard - Enlarged, sharper borders, pure white background, distinct card shadows, clear hover states */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center animate-in fade-in duration-200">
        <button 
          onClick={() => setCurrentView('cashback')}
          className="flex flex-col items-center justify-center p-4 bg-white hover:bg-[#FFF5F7] rounded-[20px] border-2 border-[#FFC2CE] hover:border-[#FF4D79] transition-all duration-200 hover:-translate-y-1 cursor-pointer shadow-sm hover:shadow-md group/card"
        >
          <div className="w-12 h-12 rounded-full bg-coquette-pink group-hover/card:bg-coquette-pink/80 flex items-center justify-center text-xl mb-2 shadow-3xs border border-[#FFD2DC]">🛍️</div>
          <span className="text-xs sm:text-[13px] font-black text-[#2B2B2B] tracking-wide block">Dán Link Nhận Xu</span>
        </button>

        <button 
          onClick={() => setCurrentView('vouchers')}
          className="flex flex-col items-center justify-center p-4 bg-white hover:bg-orange-50/40 rounded-[20px] border-2 border-orange-200 hover:border-orange-400 transition-all duration-200 hover:-translate-y-1 cursor-pointer shadow-sm hover:shadow-md group/card"
        >
          <div className="w-12 h-12 rounded-full bg-orange-50 group-hover/card:bg-orange-100/80 flex items-center justify-center text-xl mb-2 shadow-3xs border border-orange-110">🎁</div>
          <span className="text-xs sm:text-[13px] font-black text-[#2B2B2B] tracking-wide block">Đổi Siêu Voucher</span>
        </button>

        <button 
          onClick={() => setCurrentView('lost_order')}
          className="flex flex-col items-center justify-center p-4 bg-white hover:bg-rose-50/40 rounded-[20px] border-2 border-rose-200 hover:border-rose-400 transition-all duration-200 hover:-translate-y-1 cursor-pointer shadow-sm hover:shadow-md group/card"
        >
          <div className="w-12 h-12 rounded-full bg-rose-50 group-hover/card:bg-rose-100/80 flex items-center justify-center text-xl mb-2 shadow-3xs border border-rose-110">🔍</div>
          <span className="text-xs sm:text-[13px] font-black text-[#2B2B2B] tracking-wide block">Báo Mất Đơn Xu</span>
        </button>

        <button 
          onClick={() => setCurrentView('referrals')}
          className="flex flex-col items-center justify-center p-4 bg-white hover:bg-purple-50/40 rounded-[20px] border-2 border-purple-200 hover:border-purple-400 transition-all duration-200 hover:-translate-y-1 cursor-pointer shadow-sm hover:shadow-md group/card"
        >
          <div className="w-12 h-12 rounded-full bg-purple-50 group-hover/card:bg-purple-100/80 flex items-center justify-center text-xl mb-2 shadow-3xs border border-purple-110">👭</div>
          <span className="text-xs sm:text-[13px] font-black text-[#2B2B2B] tracking-wide block">Giới Thiệu Bạn Bè</span>
        </button>
      </div>

      {/* DASHBOARD TỔNG HỢP: ROLE-BASED DYNAMIC DASHBOARD */}
      {currentUser && (
        isAdmin ? (
          <div className="space-y-6 animate-in fade-in duration-200">
            {/* DASHBOARD ADMIN */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Card 1: Tổng đơn hàng */}
              <div className="bg-white rounded-[24px] p-5 border border-coquette-deep/55 shadow-3xs flex items-center gap-4 hover:shadow-xs transition-all text-left">
                <div className="w-12 h-12 bg-indigo-50 rounded-full flex items-center justify-center text-xl shrink-0">📦</div>
                <div className="space-y-0.5">
                  <span className="text-[10px] uppercase font-bold text-gray-400 block tracking-wider">Tổng Đơn Hàng</span>
                  <strong className="text-gray-800 text-base block font-mono font-black font-semibold">
                    {stats.totalOrders} đơn
                  </strong>
                  <span className="text-[9px] text-gray-400 block">
                    🧡 Shopee: {allOrders.filter(o => !o.orderId.toLowerCase().includes('tiktok') && !o.orderId.toLowerCase().startsWith('tt-')).length} | 🖤 TikTok: {allOrders.filter(o => o.orderId.toLowerCase().includes('tiktok') || o.orderId.toLowerCase().startsWith('tt-')).length}
                  </span>
                </div>
              </div>

              {/* Card 2: Tổng hoa hồng */}
              <div className="bg-white rounded-[24px] p-5 border border-coquette-deep/55 shadow-3xs flex items-center gap-4 hover:shadow-xs transition-all text-left">
                <div className="w-12 h-12 bg-emerald-50 rounded-full flex items-center justify-center text-xl shrink-0">💰</div>
                <div className="space-y-0.5">
                  <span className="text-[10px] uppercase font-bold text-gray-400 block tracking-wider">Tổng Hoa Hồng</span>
                  <strong className="text-gray-800 text-base block font-mono font-black font-semibold">{stats.totalCashbackPaid.toLocaleString('vi-VN')}đ</strong>
                </div>
              </div>

              {/* Card 3: Tổng người dùng */}
              <div className="bg-white rounded-[24px] p-5 border border-coquette-deep/55 shadow-3xs flex items-center gap-4 hover:shadow-xs transition-all text-left">
                <div className="w-12 h-12 bg-purple-50 rounded-full flex items-center justify-center text-xl shrink-0">👭</div>
                <div className="space-y-0.5">
                  <span className="text-[10px] uppercase font-bold text-gray-400 block tracking-wider">Tổng Thành Viên</span>
                  <strong className="text-gray-800 text-base block font-mono font-black font-semibold">{allUsers.length} ambassadors</strong>
                </div>
              </div>

              {/* Card 4: Tổng link đã tạo */}
              <div className="bg-white rounded-[24px] p-5 border border-coquette-deep/55 shadow-3xs flex items-center gap-4 hover:shadow-xs transition-all text-left">
                <div className="w-12 h-12 bg-pink-50 rounded-full flex items-center justify-center text-xl shrink-0">🔗</div>
                <div className="space-y-0.5">
                  <span className="text-[10px] uppercase font-bold text-gray-400 block tracking-wider">Tổng Link Đã Tạo</span>
                  <strong className="text-gray-800 text-base block font-mono font-black font-semibold">{stats.totalLinksCreated} liên kết</strong>
                </div>
              </div>
            </div>

            {/* New members & Revenue report */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Cột 1: Báo cáo Doanh thu */}
              <div className="bg-white rounded-[24px] p-5 border border-coquette-deep/55 shadow-xs space-y-4">
                <div className="flex justify-between items-center pb-2 border-b border-dashed border-coquette-deep/30">
                  <h3 className="font-serif text-sm font-bold text-gray-800 flex items-center gap-1.5">
                    <TrendingUp className="w-4 h-4 text-coquette-accent" />
                    <span>Báo Cáo Doanh Thu Hệ Thống</span>
                  </h3>
                  <span className="text-[10px] text-gray-400">Theo tháng</span>
                </div>
                <div className="overflow-x-auto text-[11px] font-sans">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-gray-100 text-gray-400 font-bold uppercase tracking-wider text-[9px]">
                        <th className="py-2.5">Tháng</th>
                        <th className="py-2.5 text-center">Số đơn</th>
                        <th className="py-2.5 text-right">Hoa hồng gốc</th>
                        <th className="py-2.5 text-right">Tiền hoàn</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(() => {
                        const reportMap: Record<string, { count: number; totalRebate: number; totalCommission: number }> = {};
                        allOrders.forEach(o => {
                          try {
                            const date = new Date(o.time);
                            const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
                            if (!reportMap[key]) {
                              reportMap[key] = { count: 0, totalRebate: 0, totalCommission: 0 };
                            }
                            reportMap[key].count += 1;
                            reportMap[key].totalRebate += o.rebateAmount || 0;
                            reportMap[key].totalCommission += o.rawCommission || 0;
                          } catch (e) {}
                        });

                        const sortedKeys = Object.keys(reportMap).sort((a,b) => b.localeCompare(a)).slice(0, 5);
                        if (sortedKeys.length === 0) {
                          return (
                            <tr>
                              <td colSpan={4} className="py-4 text-center text-gray-400">Không có dữ liệu hóa đơn</td>
                            </tr>
                          );
                        }
                        return sortedKeys.map(k => (
                          <tr key={k} className="border-b border-gray-50 hover:bg-gray-50/40">
                            <td className="py-2.5 font-mono text-gray-700">{k}</td>
                            <td className="py-2.5 text-center text-gray-650">{reportMap[k].count}</td>
                            <td className="py-2.5 text-right font-mono font-bold text-gray-500">{reportMap[k].totalCommission.toLocaleString('vi-VN')}đ</td>
                            <td className="py-2.5 text-right font-mono font-black text-coquette-accent">{reportMap[k].totalRebate.toLocaleString('vi-VN')}đ</td>
                          </tr>
                        ));
                      })()}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Cột 2: Thành viên mới */}
              <div className="bg-white rounded-[24px] p-5 border border-coquette-deep/55 shadow-xs space-y-4">
                <div className="flex justify-between items-center pb-2 border-b border-dashed border-coquette-deep/30">
                  <h3 className="font-serif text-sm font-bold text-gray-800 flex items-center gap-1.5">
                    <span>👭 Thành Viên Mới Nhất</span>
                  </h3>
                  <span className="text-[10px] text-coquette-accent bg-coquette-pink font-bold px-2 py-0.5 rounded">Mới</span>
                </div>
                <div className="space-y-2 text-[11px] max-h-[220px] overflow-y-auto">
                  {allUsers
                    .filter(u => u.username !== 'admin')
                    .sort((a, b) => new Date(b.registeredAt || 0).getTime() - new Date(a.registeredAt || 0).getTime())
                    .slice(0, 5)
                    .map(u => (
                      <div key={u.username} className="flex justify-between items-center p-2 rounded-xl bg-coquette-cream/30 hover:bg-coquette-pink/15 transition-all">
                        <div className="flex items-center gap-2">
                          <span className="text-sm">🌸</span>
                          <div>
                            <strong className="text-gray-800 block text-xs">{u.username}</strong>
                            <span className="text-[9px] text-gray-400">Tham gia: {new Date(u.registeredAt).toLocaleDateString('vi-VN')}</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="text-[9px] font-bold text-gray-400 font-mono block">Ví khả dụng</span>
                          <span className="font-mono text-emerald-600 font-bold">{(u.availableBalance || 0).toLocaleString('vi-VN')}đ</span>
                        </div>
                      </div>
                    ))}
                  {allUsers.filter(u => u.username !== 'admin').length === 0 && (
                    <p className="text-gray-400 text-center py-4">Chưa có thành viên nào đăng ký ngoài admin</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-6 animate-in fade-in duration-300">
            {/* DASHBOARD USER */}
            <div className="grid grid-cols-2 sm:grid-cols-6 lg:grid-cols-5 gap-3.5">
              {/* Card 1: Đơn hàng của tôi */}
              <div className="col-span-1 sm:col-span-2 lg:col-span-1 bg-[#FFF3E8] rounded-[24px] p-3 md:p-4 border-2 border-[#FFD7BA] shadow-md flex flex-col items-center justify-center gap-1.5 hover:scale-[1.03] transition-all text-center h-[130px] sm:h-[138px]">
                <div className="w-9 h-9 md:w-11 md:h-11 bg-[#FFEFE5] rounded-full flex items-center justify-center text-xl shrink-0 shadow-sm border border-[#FFD7BA]/50">📦</div>
                <strong className="text-[#9A3412] text-xl md:text-2xl block font-mono font-black tracking-tight">{userStats.myOrders} đơn</strong>
                <span className="text-[11px] md:text-xs font-bold text-gray-700 block uppercase tracking-wider">Đơn Của Tôi</span>
              </div>

              {/* Card 2: Hoa hồng của tôi */}
              <div className="col-span-1 sm:col-span-2 lg:col-span-1 bg-[#ECFFF2] rounded-[24px] p-3 md:p-4 border-2 border-[#C6F6D5] shadow-md flex flex-col items-center justify-center gap-1.5 hover:scale-[1.03] transition-all text-center h-[130px] sm:h-[138px]">
                <div className="w-9 h-9 md:w-11 md:h-11 bg-[#DFFFF0] rounded-full flex items-center justify-center text-xl shrink-0 shadow-sm border border-[#C6F6D5]/50">👛</div>
                <strong className="text-[#065F46] text-xl md:text-2xl block font-mono font-black tracking-tight">{userStats.myCashback.toLocaleString('vi-VN')}đ</strong>
                <span className="text-[11px] md:text-xs font-bold text-gray-700 block uppercase tracking-wider">Hoa Hồng</span>
              </div>

              {/* Card 3: Link đã tạo của tôi */}
              <div className="col-span-1 sm:col-span-2 lg:col-span-1 bg-[#F8F0FF] rounded-[24px] p-3 md:p-4 border-2 border-[#E9D5FF] shadow-md flex flex-col items-center justify-center gap-1.5 hover:scale-[1.03] transition-all text-center h-[130px] sm:h-[138px]">
                <div className="w-9 h-9 md:w-11 md:h-11 bg-[#F3E8FF] rounded-full flex items-center justify-center text-xl shrink-0 shadow-sm border border-[#E9D5FF]/50">🔗</div>
                <strong className="text-[#581C87] text-xl md:text-2xl block font-mono font-black tracking-tight">{userStats.myLinks} link</strong>
                <span className="text-[11px] md:text-xs font-bold text-gray-700 block uppercase tracking-wider">Link Đã Tạo</span>
              </div>

              {/* Card 4: Thu nhập tháng này */}
              <div className="col-span-1 sm:col-span-3 lg:col-span-1 bg-[#EEF5FF] rounded-[24px] p-3 md:p-4 border-2 border-[#BFDBFE] shadow-md flex flex-col items-center justify-center gap-1.5 hover:scale-[1.03] transition-all text-center h-[130px] sm:h-[138px]">
                <div className="w-9 h-9 md:w-11 md:h-11 bg-[#E0F2FE] rounded-full flex items-center justify-center text-xl shrink-0 shadow-sm border border-[#BFDBFE]/50">📅</div>
                <strong className="text-[#1E3A8A] text-xl md:text-2xl block font-mono font-black tracking-tight">{userStats.monthIncome.toLocaleString('vi-VN')}đ</strong>
                <span className="text-[11px] md:text-xs font-bold text-gray-700 block uppercase tracking-wider">Tháng Này</span>
              </div>

              {/* Card 5: Thu nhập hôm nay */}
              <div className="col-span-2 sm:col-span-3 lg:col-span-1 bg-[#FFFBE8] rounded-[24px] p-3 md:p-4 border-2 border-[#FEF3C7] shadow-md flex flex-col items-center justify-center gap-1.5 hover:scale-[1.03] transition-all text-center h-[130px] sm:h-[138px]">
                <div className="w-9 h-9 md:w-11 md:h-11 bg-[#FEF8D3] rounded-full flex items-center justify-center text-xl shrink-0 shadow-sm border border-[#FEF3C7]/50">🌻</div>
                <strong className="text-[#854D0E] text-xl md:text-2xl block font-mono font-black tracking-tight">{userStats.todayIncome.toLocaleString('vi-VN')}đ</strong>
                <span className="text-[11px] md:text-xs font-bold text-gray-700 block uppercase tracking-wider">Hôm Nay</span>
              </div>
            </div>
          </div>
        )
      )}

      {/* Step by step usage guide */}
      <div className="bg-white rounded-[24px] p-6 border-2 border-[#FFD7E2] shadow-lg space-y-5">
        <div className="flex justify-between items-center pb-3 border-b-2 border-dashed border-[#FFD7E2]/50">
          <h2 className="font-serif text-base font-black text-gray-800 flex items-center gap-2">
            <span>Hướng Dẫn Sử Dụng Hệ Thống</span>
            <span className="text-coquette-accent animate-bounce">🎀</span>
          </h2>
          <span className="text-xs text-rose-500 bg-rose-55 px-3 py-1 rounded-full font-black uppercase tracking-wider">Chỉ 4 bước</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {steps.map((item) => (
            <div 
              key={item.step} 
              className="flex gap-4 items-start p-5 bg-white hover:bg-[#FFF6F8] rounded-[20px] transition-all duration-200 border border-[#FFE3EA] shadow-sm hover:shadow-md"
            >
              <div className="w-12 h-12 rounded-full bg-[#FFF0F3] font-black text-rose-500 flex items-center justify-center text-xl shrink-0 shadow-inner border border-[#FFE3EA] select-none">
                {item.icon}
              </div>
              <div className="space-y-1.5 text-left">
                <h3 className="text-sm font-black text-[#1F2937] flex items-center gap-2">
                  <span className="text-[10px] font-mono text-[#FF8A47] font-black bg-white px-2 py-0.5 rounded-full border border-[#FFD7E2] shadow-3xs">BƯỚC {item.step}</span>
                  {item.title}
                </h3>
                <p className="text-xs text-[#4B5563] leading-relaxed font-semibold">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Info Tabs: Shopee standards, Tips & tricks, T&C info */}
      <div className="bg-white rounded-[24px] p-6 border-2 border-[#FFD7E2] shadow-lg space-y-5">
        <div className="flex p-1 bg-[#FFF6F8] rounded-2xl gap-2 border border-[#FFD7E2]/40">
          <button
            onClick={() => setActiveTab('shopee')}
            className={`flex-1 text-center py-3 rounded-xl text-xs font-black uppercase tracking-wider cursor-pointer transition-all duration-300 ${
              activeTab === 'shopee'
                ? 'bg-[#FF8A47] text-white shadow-[0_6px_18px_rgba(255,138,71,0.25)]'
                : 'bg-white text-[#374151] hover:bg-stone-50'
            }`}
          >
            {webContent.tabCorrectTitle}
          </button>
          
          <button
            onClick={() => setActiveTab('policy')}
            className={`flex-1 text-center py-3 rounded-xl text-xs font-black uppercase tracking-wider cursor-pointer transition-all duration-300 ${
              activeTab === 'policy'
                ? 'bg-[#FF8A47] text-white shadow-[0_6px_18px_rgba(255,138,71,0.25)]'
                : 'bg-white text-[#374151] hover:bg-stone-50'
            }`}
          >
            {webContent.tabPolicyTitle}
          </button>
          
          <button
            onClick={() => setActiveTab('tips')}
            className={`flex-1 text-center py-3 rounded-xl text-xs font-black uppercase tracking-wider cursor-pointer transition-all duration-300 ${
              activeTab === 'tips'
                ? 'bg-[#FF8A47] text-white shadow-[0_6px_18px_rgba(255,138,71,0.25)]'
                : 'bg-white text-[#374151] hover:bg-stone-50'
            }`}
          >
            {webContent.tabTipsTitle}
          </button>
        </div>

        {/* Content for tabs dynamic */}
        <div className="p-1 text-left">
          {activeTab === 'shopee' && (
            <div className="text-xs space-y-3 text-gray-700 leading-relaxed whitespace-pre-line bg-[#FFF9FA]/40 p-4 rounded-xl border border-[#FFD7E2]/30">
              <p className="font-extrabold text-sm text-[#1F2937]">{webContent.tabCorrectTitle} 🛒</p>
              <div className="space-y-1 pl-1 font-semibold text-gray-600">
                {webContent.tabCorrectContent}
              </div>
            </div>
          )}

          {activeTab === 'policy' && (
            <div className="text-xs space-y-3 text-gray-700 leading-relaxed whitespace-pre-line bg-[#FFF9FA]/40 p-4 rounded-xl border border-[#FFD7E2]/30">
              <p className="font-extrabold text-sm text-[#1F2937]">{webContent.tabPolicyTitle} 🎀</p>
              <div className="space-y-1 pl-1 font-semibold text-gray-600">
                {webContent.tabPolicyContent}
              </div>
            </div>
          )}

          {activeTab === 'tips' && (
            <div className="text-xs space-y-3 text-gray-700 leading-relaxed whitespace-pre-line bg-[#FFFBE8]/40 p-4 rounded-xl border border-[#FEF3C7]/40">
              <p className="font-extrabold text-sm text-yellow-800">⚠️ {webContent.tabTipsTitle}:</p>
              <div className="space-y-1 pl-1 font-semibold text-gray-600">
                {webContent.tabTipsContent}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Call to action for account signup/login if guest */}
      {!currentUser && (
        <div className="bg-gradient-to-r from-coquette-accent/5 to-coquette-pink/30 rounded-[24px] p-5 border border-coquette-deep/50 text-center space-y-3">
          <p className="text-xs text-gray-600">
            Đăng ký tài khoản ngay để nhận ngay <strong className="text-coquette-accent font-bold font-serif">liên kết giới thiệu nhận thưởng</strong> và tích lũy tiền hoàn không giới hạn!
          </p>
          <button
            onClick={onOpenAuthModal}
            className="bg-coquette-accent hover:bg-coquette-accent/95 text-white text-xs font-bold py-2 px-6 rounded-full inline-flex items-center gap-1.5 cursor-pointer shadow-3xs active:scale-95 transition-all"
          >
            <span>Đăng Ký Khởi Đầu 🎀</span>
          </button>
        </div>
      )}
    </div>
  );
}
