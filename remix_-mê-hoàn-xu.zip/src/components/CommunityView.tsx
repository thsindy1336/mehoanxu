import React, { useState } from 'react';
import { MessageSquare, Star, Clock, Send, ShieldCheck, Heart } from 'lucide-react';
import { User, Comment } from '../types';
import { getComments, saveComments } from '../data';

interface CommunityViewProps {
  currentUser: User | null;
  onOpenAuthModal: () => void;
}

export default function CommunityView({ currentUser, onOpenAuthModal }: CommunityViewProps) {
  const [comments, setComments] = useState<Comment[]>(getComments());
  const [newCommentText, setNewCommentText] = useState('');
  const [rating, setRating] = useState(5);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!currentUser) {
      onOpenAuthModal();
      return;
    }

    if (!newCommentText.trim()) {
      setErrorMsg('Vui lòng nhập nội dung đánh giá của bạn.');
      return;
    }

    if (newCommentText.length < 5) {
      setErrorMsg('Đánh giá phải có ít nhất 5 ký tự để đảm bảo chất lượng thông tin.');
      return;
    }

    const nextComment: Comment = {
      id: 'c' + (Date.now()),
      username: currentUser.username,
      content: newCommentText.trim(),
      rating,
      createdAt: new Date().toISOString()
    };

    const updatedComments = [nextComment, ...comments];
    saveComments(updatedComments);
    setComments(updatedComments);
    
    setNewCommentText('');
    setRating(5);
  };

  return (
    <div className="space-y-6">
      <div className="text-center space-y-1 py-2">
        <h2 className="font-serif text-2xl font-bold text-gray-800 flex items-center justify-center gap-1.5">
          <span>Góc Cộng Đồng 💬</span>
          <span className="text-coquette-accent">🎀</span>
        </h2>
        <p className="text-xs text-gray-400">Nơi người dùng chia sẻ kinh nghiệm mua sắm, mẹo dán link và nhận hoàn tiền</p>
      </div>

      {/* Review input Form */}
      <div className="bg-white rounded-3xl p-5 border border-coquette-deep/40 shadow-xs space-y-4">
        <h3 className="font-serif text-xs font-bold text-gray-700 flex items-center gap-1">
          <span>Đăng bình luận & đánh giá của bạn ✨</span>
        </h3>

        <form onSubmit={handleSubmitComment} className="space-y-3.5">
          {currentUser ? (
            <div className="text-[11px] text-gray-400 bg-coquette-pink/30 px-3 py-1.5 rounded-lg inline-block">
              Đăng nhận định với tên: <strong className="text-coquette-accent">@{currentUser.username}</strong>
            </div>
          ) : (
            <div className="p-3 bg-rose-50 border border-rose-100 rounded-xl text-center">
              <button
                type="button"
                onClick={onOpenAuthModal}
                className="text-xs text-coquette-accent font-bold underline"
              >
                Vui lòng đăng nhập hoặc đăng ký tài khoản để đóng góp ý kiến
              </button>
            </div>
          )}

          {/* Core rating */}
          <div className="space-y-1">
            <span className="text-[11px] font-bold text-gray-700 block">Đánh giá hệ thống:</span>
            <div className="flex gap-1.5">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  className="cursor-pointer hover:scale-110 transition-transform"
                >
                  <Star 
                    className={`w-6 h-6 ${
                      star <= rating ? 'fill-amber-400 text-amber-400' : 'text-gray-300'
                    }`} 
                  />
                </button>
              ))}
              <span className="text-[11px] font-mono font-bold text-amber-600 self-center ml-2">({rating}/5 Sao)</span>
            </div>
          </div>

          {/* Area box */}
          <div className="space-y-1">
            <span className="text-[11px] font-bold text-gray-700 block">Nội dung bình luận:</span>
            <textarea
              value={newCommentText}
              onChange={(e) => setNewCommentText(e.target.value)}
              placeholder="Chia sẻ trải nghiệm hoàn tiền Shopee của bạn tại đây nào..."
              maxLength={300}
              rows={3}
              className="w-full text-xs p-3 bg-coquette-cream/30 hover:bg-white focus:bg-white border border-coquette-deep/40 focus:border-coquette-accent rounded-xl outline-hidden transition-all text-gray-700 placeholder-gray-400"
            />
            <div className="flex justify-between items-center text-[10px] text-gray-400">
              <span>Được nhập tối đa 300 ký tự</span>
              <span>Đã nhập: {newCommentText.length}/300</span>
            </div>
          </div>

          {errorMsg && (
            <div className="text-xs text-red-500 bg-red-50 p-2.5 rounded-lg border border-red-200">
              {errorMsg}
            </div>
          )}

          <button
            type="submit"
            disabled={!currentUser}
            className={`w-full font-bold text-xs py-3 rounded-xl transition-all flex items-center justify-center gap-1.5 shadow-sm ${
              currentUser 
                ? 'bg-coquette-accent hover:bg-coquette-accent/90 text-white cursor-pointer hover:translate-y-[-1px]' 
                : 'bg-gray-100 text-gray-300 cursor-not-allowed'
            }`}
          >
            <span>Gửi bình luận lên bảng tin 🎀</span>
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>

      {/* Feed list */}
      <div className="space-y-3.5">
        <h3 className="font-serif text-sm font-semibold text-gray-700 px-1 border-l-3 border-coquette-accent">Bảng tin thảo luận ({comments.length})</h3>
        
        <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
          {comments.map((comment) => (
            <div 
              key={comment.id}
              className="bg-white p-4 rounded-2xl border border-coquette-deep/30 space-y-2.5 shadow-3xs hover:border-coquette-deep/70 transition-all"
            >
              <div className="flex justify-between items-start text-xs">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-gray-800">@{comment.username}</span>
                    <span className="bg-coquette-pink text-coquette-accent text-[8.5px] px-1.5 py-0.2 rounded font-mono font-bold">Thành viên</span>
                  </div>
                  <span className="text-[10px] text-gray-400 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>{new Date(comment.createdAt).toLocaleDateString('vi-VN')} {new Date(comment.createdAt).toLocaleTimeString('vi-VN', {hour: '2-digit', minute:'2-digit'})}</span>
                  </span>
                </div>
                
                {/* Rating star badges */}
                <div className="flex gap-0.5">
                  {Array.from({ length: 5 }).map((_, idx) => (
                    <Star 
                      key={idx}
                      className={`w-3 h-3 ${
                        idx < comment.rating ? 'fill-amber-400 text-amber-400' : 'text-gray-200'
                      }`}
                    />
                  ))}
                </div>
              </div>

              <p className="text-xs text-gray-600 leading-relaxed font-sans font-normal border-t border-dashed border-coquette-cream pt-2.5">
                {comment.content}
              </p>

              <div className="flex justify-between items-center text-[10px] text-gray-400 pt-1">
                <span className="text-emerald-600 flex items-center gap-0.5">
                  <ShieldCheck className="w-3 h-3" />
                  <span>Đã kiểm duyệt</span>
                </span>
                
                <button 
                  onClick={() => alert('Cảm ơn bạn đã yêu thích bình luận khảo sát này!')}
                  className="flex items-center gap-0.5 hover:text-coquette-accent transition-colors"
                >
                  <Heart className="w-3 h-3" />
                  <span>Thích</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
