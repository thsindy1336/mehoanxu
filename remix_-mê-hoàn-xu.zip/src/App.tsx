import React, { useState, useEffect } from 'react';
import { Sparkles, ArrowRight, UserPlus, FileText, CheckCircle2, Clock, Shield, HelpCircle, Heart, Star, Instagram, Bell } from 'lucide-react';
import CoquetteHeader from './components/CoquetteHeader';
import HomeView from './components/HomeView';
import CashbackView from './components/CashbackView';
import ProfileView from './components/ProfileView';
import UtilitiesView from './components/UtilitiesView';
import CommunityView from './components/CommunityView';
import AdminView from './components/AdminView';
import LinkHistoryView from './components/LinkHistoryView';
import { User, WebContent, ShortLink } from './types';
import { initLocalStorage, getUsers, saveUsers, getPasswords, savePasswords, getWebContent, hashPassword, getShortLinks, saveShortLinks, syncFromFirestore, getInternalNotifications, saveInternalNotifications } from './data';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<string>('home');
  const [isDbLoaded, setIsDbLoaded] = useState<boolean>(false);
  const [isAdminMode, setIsAdminMode] = useState<boolean>(false);
  const [adminSubTab, setAdminSubTab] = useState<'stats' | 'excel' | 'withdrawals' | 'config' | 'items' | 'tickets' | 'content' | 'tiktok_shop'>('stats');

  // Redirection handling states
  const [redirectLink, setRedirectLink] = useState<ShortLink | null>(null);

  // Dynamic configuration states
  const [webContent, setWebContent] = useState<WebContent>(() => getWebContent());

  // Dynamic footer informers modals
  const [isInfoModalOpen, setIsInfoModalOpen] = useState(false);
  const [infoModalTitle, setInfoModalTitle] = useState('');
  const [infoModalContent, setInfoModalContent] = useState('');

  // Auth Modal States
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [authUsername, setAuthUsername] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authInviteCode, setAuthInviteCode] = useState('');
  const [authError, setAuthError] = useState('');

  // Admin Verification and Notifications state definitions
  const [adminGatePassword, setAdminGatePassword] = useState('');
  const [adminGateError, setAdminGateError] = useState('');
  const [dismissedNotifIds, setDismissedNotifIds] = useState<string[]>([]);
  const [toasts, setToasts] = useState<{ id: string; message: string; type: 'success' | 'error' | 'info' }[]>([]);

  useEffect(() => {
    (window as any).showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
      const id = Date.now().toString() + Math.random().toString(36).substring(2, 5);
      setToasts(p => [...p, { id, message, type }]);
      setTimeout(() => {
        setToasts(p => p.filter(t => t.id !== id));
      }, 3000);
    };
  }, []);

  // State & Auto-Reveal for top notification banner
  const [isNotifBannerClosed, setIsNotifBannerClosed] = useState(() => {
    return localStorage.getItem('notification_card_hidden') === 'true';
  });
  const [lastNotifCount, setLastNotifCount] = useState(-1);

  // Initialize unread notification count upon mount/auth change
  useEffect(() => {
    if (currentUser) {
      try {
        const stored = getInternalNotifications();
        const mine = stored.filter((n: any) => n.username === currentUser.username && !n.dismissed && !dismissedNotifIds.includes(n.id));
        const unreadMine = mine.filter((n: any) => !n.isRead);
        setLastNotifCount(unreadMine.length);
      } catch (e) {}
    } else {
      setLastNotifCount(0);
    }
  }, [currentUser, dismissedNotifIds]);

  // Auto detect if new internal notification shows up and reopen banner automatically
  useEffect(() => {
    if (!currentUser || lastNotifCount === -1) return;
    const interval = setInterval(() => {
      try {
        const stored = getInternalNotifications();
        const mine = stored.filter((n: any) => n.username === currentUser.username && !n.dismissed && !dismissedNotifIds.includes(n.id));
        const unreadMine = mine.filter((n: any) => !n.isRead);

        if (unreadMine.length > lastNotifCount && lastNotifCount >= 0) {
          setIsNotifBannerClosed(false);
          localStorage.setItem('notification_card_hidden', 'false');
        }
        setLastNotifCount(unreadMine.length);
      } catch (err) {}
    }, 2000);
    return () => clearInterval(interval);
  }, [currentUser, lastNotifCount, dismissedNotifIds]);

  // Sơ khởi dữ liệu LocalStorage ban đầu khi khởi động ứng dụng
  useEffect(() => {
    async function loadCloudData() {
      await syncFromFirestore();
      
      // Update dynamic configuration values from Cloud
      setWebContent(getWebContent());

      // Kiểm tra định tuyến chuyển hướng link rút gọn
      const pathCode = window.location.pathname.substring(1).trim();
      const internalRoutes = ['quan-tri', 'administrator', 'admin', 'notifications', 'index.html', 'wallet', 'vouchers', 'lost_order', 'referrals', 'comments', 'link_history', 'cashback', 'home', 'api'];
      if (pathCode && !internalRoutes.includes(pathCode) && !pathCode.includes('/') && pathCode.length >= 2 && pathCode.length <= 5) {
        const links = getShortLinks();
        const match = links.find(l => l.code === pathCode);
        if (match) {
          // Ghi nhận click
          match.clicks = (match.clicks || 0) + 1;
          saveShortLinks(links);

          // Kiểm soát chống gian lận
          let recent = JSON.parse(localStorage.getItem('mhx_recent_clicks') || '[]');
          recent.push({ code: pathCode, time: new Date().toISOString() });
          localStorage.setItem('mhx_recent_clicks', JSON.stringify(recent.slice(-50)));

          // Kích hoạt màn hình chờ chuyển hướng
          setRedirectLink(match);
          setIsDbLoaded(true);
          return;
        }
      }
      
      // Đăng nhập session đã lưu cực kỳ an toàn
      const users = getUsers();
      const savedUser = localStorage.getItem('mhx_session_user');
      if (savedUser) {
        const found = users.find(u => u.username === savedUser);
        if (found) {
          setCurrentUser(found);
          setIsAdminMode(found.role === 'admin');
          if (found.role === 'admin') {
            setCurrentView('admin');
          }
        }
      }
      setIsDbLoaded(true);
    }

    loadCloudData();

    // URL Hash and Path monitoring for Admin controls & unified pathnames
    const handleHashAndUrl = () => {
      const h = window.location.hash || '';
      const p = window.location.pathname || '';
      
      if (h === '#admin' || h === '#thuy-admin' || h === '#quan-tri' || h === '#administrator' || p === '/quan-tri' || p === '/administrator') {
        // Admin perspective checks
        const currentSavedUsrStr = localStorage.getItem('mhx_session_user');
        if (currentSavedUsrStr) {
          const uRecord = getUsers().find(u => u.username === currentSavedUsrStr);
          if (uRecord) {
            setCurrentView('admin');
            return;
          }
        }
        
        setCurrentView('home');
        setIsAuthOpen(true);
        setAuthMode('login');
        setAuthError('Vui lòng đăng nhập tài khoản Quản trị viên để truy cập khu vực quản trị 🔑');
      } else if (h === '#notifications') {
        setCurrentView('notifications');
      }
    };
    handleHashAndUrl();
    window.addEventListener('hashchange', handleHashAndUrl);
    return () => {
      window.removeEventListener('hashchange', handleHashAndUrl);
    };
  }, []);

  // Thực hiện chuyển hướng tự động bằng timer
  useEffect(() => {
    if (redirectLink) {
      const t = setTimeout(() => {
        window.location.replace(redirectLink.affiliateLink);
      }, 1500);
      return () => clearTimeout(t);
    }
  }, [redirectLink]);

  // Làm mới dữ liệu từ localStorage khi Admin update hoặc đổi trạng thái
  const handleRefreshData = () => {
    setWebContent(getWebContent());
    if (currentUser) {
      const users = getUsers();
      const updatedUser = users.find(u => u.username === currentUser.username);
      if (updatedUser) {
        setCurrentUser({ ...updatedUser });
      }
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setIsAdminMode(false);
    localStorage.removeItem('mhx_session_user');
    setCurrentView('home');
    if (typeof (window as any).showToast === 'function') {
      (window as any).showToast('✅ Đăng xuất tài khoản thành công', 'success');
    }
  };

  // Đăng ký tài khoản
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');

    const usernameTrimmed = authUsername.trim().toLowerCase();
    if (!usernameTrimmed || !authPassword) {
      setAuthError('Vui lòng nhập tên đăng nhập và mật khẩu.');
      return;
    }

    if (usernameTrimmed.length < 3) {
      setAuthError('Tên đăng nhập phải chứa từ 3 ký tự trở lên.');
      return;
    }

    const users = getUsers();
    if (users.some((u) => u.username === usernameTrimmed)) {
      setAuthError('Tên đăng nhập đã tồn tại trong hệ thống.');
      return;
    }

    // Nếu nhập mã giới thiệu, hãy kiểm tra tính hợp lệ
    let refersBy: string | undefined = undefined;
    if (authInviteCode.trim()) {
      const matchReferrer = users.find(u => u.referralCode === authInviteCode.trim().toUpperCase());
      if (matchReferrer) {
        refersBy = matchReferrer.username;
      } else {
        setAuthError('Mã giới thiệu không hợp lệ. Vui lòng kiểm tra lại.');
        return;
      }
    }

    // Khởi tạo user mới
    const newUser: User = {
      username: usernameTrimmed,
      role: 'user',
      availableBalance: 0,
      pendingBalance: 0,
      totalCashback: 0,
      referralCode: `MHX_${usernameTrimmed.toUpperCase()}`,
      referredBy: refersBy,
      registeredAt: new Date().toISOString()
    };

    // Đăng ký mật khẩu dưới dạng băm bảo mật
    const passwords = getPasswords();
    passwords[usernameTrimmed] = hashPassword(authPassword);
    savePasswords(passwords);

    // Lưu User
    users.push(newUser);
    saveUsers(users);

    setCurrentUser(newUser);
    localStorage.setItem('mhx_session_user', usernameTrimmed);
    setIsAuthOpen(false);
    setAuthUsername('');
    setAuthPassword('');
    setAuthInviteCode('');
    if (typeof (window as any).showToast === 'function') {
      (window as any).showToast(`✅ Đăng ký @${usernameTrimmed} thành công!`, 'success');
    }
  };

  // Đăng nhập
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');

    const usernameTrimmed = authUsername.trim().toLowerCase();
    const passwords = getPasswords();
    const users = getUsers();

    // Chấp nhận mật khẩu admin linh hoạt để kiểm tra viên không bao giờ bị kẹt
    const isAdminAlternative = usernameTrimmed === 'admin' && (authPassword === 'admin123' || authPassword === 'Thuy3306@');
    const storedPassValue = passwords[usernameTrimmed];
    const isPasswordCorrect = isAdminAlternative || (storedPassValue && (storedPassValue === authPassword || storedPassValue === hashPassword(authPassword)));

    if (isPasswordCorrect) {
      let userObj = users.find((u) => u.username === usernameTrimmed);
      
      // Khôi phục tài khoản Admin tối mật ngay lập tức nếu bị thất lạc từ localStorage
      if (!userObj && usernameTrimmed === 'admin') {
        userObj = {
          username: 'admin',
          role: 'admin',
          availableBalance: 0,
          pendingBalance: 0,
          totalCashback: 0,
          referralCode: 'MHX_ADMIN',
          registeredAt: new Date().toISOString()
        };
        users.push(userObj);
        saveUsers(users);
      }

      // Đảm bảo mật khẩu admin được cập nhật băm đồng bộ hoá
      if (usernameTrimmed === 'admin' && passwords['admin'] !== hashPassword(authPassword)) {
        passwords['admin'] = hashPassword(authPassword);
        savePasswords(passwords);
      }

      if (userObj) {
        setCurrentUser(userObj);
        setIsAdminMode(userObj.role === 'admin');
        localStorage.setItem('mhx_session_user', usernameTrimmed);
        setIsAuthOpen(false);
        setAuthUsername('');
        setAuthPassword('');
        
        if (typeof (window as any).showToast === 'function') {
          (window as any).showToast(`✅ Chào mừng @${usernameTrimmed} đã quay trở lại!`, 'success');
        }

        if (userObj.role === 'admin') {
          setCurrentView('admin');
        } else {
          setCurrentView('home');
        }
        return;
      }
    }

    setAuthError('Tên đăng nhập hoặc mật khẩu không chính xác.');
  };

  if (!isDbLoaded) {
    return (
      <div className="min-h-screen bg-coquette-cream flex flex-col items-center justify-center p-6 text-center antialiased relative animate-in fade-in duration-300">
        <div className="absolute inset-0 bg-lace pointer-events-none opacity-50" />
        <div className="max-w-md bg-white p-8 rounded-[32px] border-2 border-[#FFA6B7] shadow-xl space-y-6 relative z-10 animate-pulse">
          <span className="text-5xl animate-spin inline-block">🌸</span>
          <h2 className="font-serif text-2xl font-bold text-[#FF4D79] tracking-tight">MÊ HOÀN XU</h2>
          <div className="space-y-1">
            <p className="text-sm font-semibold text-gray-700">Đang chuẩn bị hệ thống...</p>
            <p className="text-xs text-gray-400">Vui lòng chờ trong giây lát.</p>
          </div>
          <div className="w-16 h-1 w-full bg-gray-100 rounded-full overflow-hidden mx-auto max-w-[120px]">
            <div className="bg-[#FFA6B7] h-full w-2/3 rounded-full animate-infinite-width" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-coquette-cream flex flex-col antialiased selection:bg-coquette-deep/50 relative">
      {/* Delicate background patterns */}
      <div className="absolute inset-0 bg-lace pointer-events-none" />

      {/* Chuyển hướng liên kết thông minh */}
      {redirectLink && (
        <div className="fixed inset-0 bg-coquette-cream z-[9999] flex flex-col items-center justify-center p-6 text-center animate-in fade-in duration-300">
          <div className="max-w-md w-full bg-white p-8 rounded-[32px] border-2 border-coquette-deep shadow-2xl space-y-6">
            <span className="text-4xl animate-bounce block">🎀</span>
            <h2 className="font-serif text-xl font-bold text-coquette-accent">Cổng Chuyển Hướng An Toàn</h2>
            <p className="text-xs text-gray-500 leading-relaxed font-semibold">
              Đang xác thực bảo mật và chuyển tiếp bạn tới sàn thương mại điện tử mua sắm...
            </p>
            
            <div className="bg-coquette-pink/15 p-5 rounded-2xl border border-coquette-deep/20 space-y-2 text-xs text-left">
              <p className="text-[10px] uppercase font-bold tracking-wider text-coquette-accent">Thông tin tích xu hoàn tiền:</p>
              <div className="space-y-1">
                <p className="font-semibold text-gray-700">
                  • Đại sứ liên kết: <strong className="font-extrabold text-coquette-accent">@{redirectLink.createdBy}</strong>
                </p>
                <p className="text-gray-500 text-[10.5px]">
                  • Nền tảng: <strong className="font-bold text-gray-700">{redirectLink.originalLink.toLowerCase().includes('tiktok') ? 'TikTok Shop 🖤' : 'Shopee VN 🧡'}</strong>
                </p>
                <p className="text-gray-400 text-[10.5px] truncate">
                  • Link gốc: <span className="font-mono">{redirectLink.originalLink}</span>
                </p>
              </div>
            </div>

            <div className="flex justify-center py-2">
              <div className="w-8 h-8 rounded-full border-4 border-coquette-pink border-t-coquette-accent animate-spin" />
            </div>

            <a
              href={redirectLink.affiliateLink}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[10.5px] text-coquette-accent hover:underline font-bold"
            >
              Click vào đây nếu trình duyệt không tự chuyển hướng sau vài giây 🛍️
            </a>
          </div>
        </div>
      )}

      {/* Main Single Screen Centralizer Optimized with Responsive Columns */}
      <div className="w-full max-w-md md:max-w-3xl lg:max-w-none mx-auto bg-[#FFF6F8] min-h-screen flex flex-col lg:grid lg:grid-cols-[280px_1fr] shadow-2xl lg:shadow-none relative border-x-2 border-coquette-deep/30 lg:border-none text-left">
        
        {/* Left Sidebar - Visible ONLY on Desktop (lg: >=1024px) */}
        <aside className="hidden lg:flex lg:flex-col lg:bg-white lg:h-screen lg:sticky lg:top-0 lg:overflow-y-auto shrink-0 select-none shadow-[4px_0_25px_rgba(0,0,0,0.05)] border-r-2 border-[#FFE3E8]">
          {/* Logo Brand */}
          <div className="p-6 border-b-2 border-[#FFF0F3] flex items-center gap-2">
            <span className="text-2xl animate-spin-slow">🎀</span>
            <span className="font-serif text-xl font-black text-[#FF6B8A] leading-none">Mê Hoàn Xu</span>
          </div>

          {/* User profile card or login action */}
          <div className="p-4 border-b-2 border-[#FFF0F3]">
            {currentUser ? (
              <div className="bg-[#FFFDFD] p-4 rounded-[20px] border-2 border-[#FFA6B7] space-y-3 shadow-sm">
                <div className="space-y-0.5">
                  <span className="text-[10px] text-[#FF8A3D] font-extrabold uppercase tracking-widest block">Trực tuyến 🌸</span>
                  <strong className="text-gray-900 text-sm block truncate font-black">@{currentUser.username}</strong>
                  <span className="text-[10px] italic text-rose-450 font-bold block">
                    {currentUser.role === 'admin' ? 'Quản trị viên 👑' : 'Đại sứ thành viên 👭'}
                  </span>
                </div>

                <div className="pt-2 border-t border-dashed border-[#FFE3E8] flex flex-col gap-1 text-xs">
                  <div className="flex justify-between items-center text-gray-700">
                    <span className="font-semibold">Ví khả dụng:</span>
                    <strong className="font-black text-[#FF6B8A] font-mono text-[13px]">
                      {currentUser.availableBalance.toLocaleString('vi-VN')}đ
                    </strong>
                  </div>
                  <div className="flex justify-between items-center text-gray-450 text-[10.5px]">
                    <span className="font-semibold">Ví đối soát:</span>
                    <span className="font-bold font-mono text-gray-600">
                      {currentUser.pendingBalance.toLocaleString('vi-VN')}đ
                    </span>
                  </div>
                </div>

                <button
                  onClick={handleLogout}
                  className="w-full mt-2 bg-white hover:bg-rose-50 text-rose-600 border-2 border-rose-100 hover:border-rose-300 py-1.5 rounded-xl text-[11px] font-black transition-all cursor-pointer flex items-center justify-center gap-1 shadow-3xs"
                >
                  Đăng xuất 🐰
                </button>
              </div>
            ) : (
              <div className="bg-[#FFF6F8] p-4 rounded-xl border border-dashed border-[#FFE3E8] text-center space-y-2.5">
                <p className="text-[11px] text-gray-500 font-bold leading-relaxed">Đăng nhập đại sứ để nhận 10% hoa hồng và tích xu hoàn tiền không giới hạn!</p>
                <button
                  onClick={() => { setIsAuthOpen(true); setAuthMode('login'); }}
                  className="w-full bg-gradient-to-r from-[#FF6B9D] to-[#FF8A47] hover:opacity-95 text-white font-black py-2 rounded-xl text-xs cursor-pointer shadow-md transition-all uppercase tracking-wider"
                >
                  Đăng Nhập Hoàn Tiền 🔑
                </button>
              </div>
            )}
          </div>

          {/* Navigation Links */}
          <nav className="flex-1 p-4 space-y-2">
            <button
              onClick={() => setCurrentView('home')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-xs font-black uppercase tracking-wider transition-all text-left cursor-pointer border ${
                currentView === 'home'
                  ? 'bg-gradient-to-r from-[#FF6B9D] to-[#FF8A47] text-white border-transparent shadow-[0_6px_15px_rgba(255,107,157,0.25)]'
                  : 'bg-white text-[#374151] border-transparent hover:bg-[#FFF0F3] hover:text-[#FF6B8A]'
              }`}
            >
              <span className="text-sm">🏠</span>
              <span>Dashboard</span>
            </button>

            <button
              onClick={() => setCurrentView('cashback')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-xs font-black uppercase tracking-wider transition-all text-left cursor-pointer border ${
                currentView === 'cashback'
                  ? 'bg-gradient-to-r from-[#FF6B9D] to-[#FF8A47] text-white border-transparent shadow-[0_6px_15px_rgba(255,107,157,0.25)]'
                  : 'bg-white text-[#374151] border-transparent hover:bg-[#FFF0F3] hover:text-[#FF6B8A]'
              }`}
            >
              <span className="text-sm">🛍️</span>
              <span>Tạo Link</span>
            </button>

            <button
              onClick={() => setCurrentView('link_history')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-xs font-black uppercase tracking-wider transition-all text-left cursor-pointer border ${
                currentView === 'link_history'
                  ? 'bg-gradient-to-r from-[#FF6B9D] to-[#FF8A47] text-white border-transparent shadow-[0_6px_15px_rgba(255,107,157,0.25)]'
                  : 'bg-white text-[#374151] border-transparent hover:bg-[#FFF0F3] hover:text-[#FF6B8A]'
              }`}
            >
              <span className="text-sm">📋</span>
              <span>Lịch Sử Link</span>
            </button>

            <button
              onClick={() => setCurrentView('wallet')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-xs font-black uppercase tracking-wider transition-all text-left cursor-pointer border ${
                currentView === 'wallet'
                  ? 'bg-gradient-to-r from-[#FF6B9D] to-[#FF8A47] text-white border-transparent shadow-[0_6px_15px_rgba(255,107,157,0.25)]'
                  : 'bg-white text-[#374151] border-transparent hover:bg-[#FFF0F3] hover:text-[#FF6B8A]'
              }`}
            >
              <span className="text-sm">💳</span>
              <span>Đơn Hàng</span>
            </button>

            {/* If Admin, show Quản Lý TikTok Shop deep-link link inside Admin panel */}
            {currentUser?.role === 'admin' && (
              <button
                onClick={() => {
                  setCurrentView('admin');
                  setAdminSubTab('tiktok_shop');
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-xs font-black uppercase tracking-wider transition-all text-left cursor-pointer border ${
                  currentView === 'admin' && adminSubTab === 'tiktok_shop'
                    ? 'bg-gradient-to-r from-[#FF6B9D] to-[#FF8A47] text-white border-transparent shadow-[0_6px_15px_rgba(255,107,157,0.25)]'
                    : 'bg-white text-[#374151] border-transparent hover:bg-[#FFF0F3] hover:text-[#FF6B8A]'
                }`}
              >
                <span className="text-sm">🖤</span>
                <span>TikTok Shop</span>
              </button>
            )}

            <button
              onClick={() => {
                if (currentUser?.role === 'admin') {
                  setCurrentView('admin');
                  setAdminSubTab('stats');
                } else {
                  setCurrentView('referrals');
                }
              }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-xs font-black uppercase tracking-wider transition-all text-left cursor-pointer border ${
                (currentUser?.role === 'admin' && currentView === 'admin' && adminSubTab === 'stats') || (currentUser?.role !== 'admin' && currentView === 'referrals')
                  ? 'bg-gradient-to-r from-[#FF6B9D] to-[#FF8A47] text-white border-transparent shadow-[0_6px_15px_rgba(255,107,157,0.25)]'
                  : 'bg-white text-[#374151] border-transparent hover:bg-[#FFF0F3] hover:text-[#FF6B8A]'
              }`}
            >
              <span className="text-sm">👭</span>
              <span>Thành Viên</span>
            </button>

            {/* If Admin, show "Cài Đặt" (Admin subtab config) */}
            {currentUser?.role === 'admin' && (
              <button
                onClick={() => {
                  setCurrentView('admin');
                  setAdminSubTab('config');
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-xs font-black uppercase tracking-wider transition-all text-left cursor-pointer border ${
                  currentView === 'admin' && adminSubTab === 'config'
                    ? 'bg-gradient-to-r from-[#FF6B9D] to-[#FF8A47] text-white border-transparent shadow-[0_6px_15px_rgba(255,107,157,0.25)]'
                    : 'bg-white text-[#374151] border-transparent hover:bg-[#FFF0F3] hover:text-[#FF6B8A]'
                }`}
              >
                <span className="text-sm">⚙️</span>
                <span>Cài Đặt</span>
              </button>
            )}
          </nav>

          {/* Sidebar Footer credit line */}
          <div className="p-4 border-t-2 border-[#FFF0F3] text-center text-[10px] text-gray-400 font-bold">
            <span>Mê Hoàn Xu 🎀 thuydeal.site</span>
          </div>
        </aside>

        {/* Right Area containing Mobile Header on phones & Wide Viewport content */}
        <div className="flex flex-col min-h-screen w-full lg:h-screen lg:overflow-y-auto pb-0">
          
          {/* Mobile & Tablet Header (Hidden on Desktop 'lg:') */}
          <div className="lg:hidden shrink-0">
            <CoquetteHeader 
              currentUser={currentUser}
              onLogout={handleLogout}
              setCurrentView={setCurrentView}
              currentView={currentView}
              onOpenAuthModal={() => { setIsAuthOpen(true); setAuthMode('login'); }}
              isAdminMode={isAdminMode}
            />
          </div>

          {/* Content body with scrolling */}
          <main className="flex-1 p-4 md:p-6 lg:p-8 pb-10 relative z-10 w-full">
            
            {/* Inline dynamic notification banner block */}
            {(() => {
              if (!currentUser) return null;
              let userNotifications: any[] = [];
              try {
                const list = getInternalNotifications();
                userNotifications = list.filter((n: any) => n.username === currentUser.username && !n.dismissed && !dismissedNotifIds.includes(n.id));
              } catch (e) {}

              if (userNotifications.length === 0) return null; // Hide completely when empty!
              
              const unreadCount = userNotifications.filter(n => !n.isRead).length;

              const newestNotifTime = userNotifications.length > 0
                ? Math.max(...userNotifications.map((n: any) => new Date(n.createdAt || 0).getTime()))
                : 0;

              const lastHiddenMaxTime = parseInt(localStorage.getItem('notification_last_hidden_time') || '0', 10);
              const isNotifCardHidden = localStorage.getItem('notification_card_hidden') === 'true';

              // If there's a newer notification than when they hid it, show the card again!
              let currentHidden = isNotifCardHidden;
              if (isNotifCardHidden && newestNotifTime > lastHiddenMaxTime) {
                currentHidden = false;
                localStorage.removeItem('notification_card_hidden');
              }

              if (isNotifBannerClosed || currentHidden) {
                return null;
              }

              return (
                <div className="mb-6 bg-gradient-to-br from-[#FFF9FA] to-white border-2 border-[#FFA6B7] rounded-[24px] p-5 shadow-md animate-in fade-in slide-in-from-top-2 duration-300 relative text-xs">
                  <div className="flex justify-between items-center pb-2 border-b border-dashed border-[#FFA6B7]/35 mb-3">
                    <div className="flex items-center gap-1.5 text-stone-850 font-serif font-black block text-left">
                      <Bell className="w-4 h-4 text-[#FF4D79] animate-bounce inline mr-1" />
                      <span>🔔 Thông Báo Của Bạn ({unreadCount} chưa đọc)</span>
                    </div>
                    <button 
                      onClick={() => {
                        setIsNotifBannerClosed(true);
                        localStorage.setItem('notification_card_hidden', 'true');
                        localStorage.setItem('notification_last_hidden_time', newestNotifTime.toString());
                      }}
                      className="text-gray-400 hover:text-[#FF4D79] hover:bg-rose-50 rounded-full w-6 h-6 flex items-center justify-center transition-all cursor-pointer font-black text-xs"
                      title="Đóng thông báo"
                    >
                      ✕
                    </button>
                  </div>
                  
                  <div className="space-y-3.5 max-h-[160px] overflow-y-auto pr-1">
                    {userNotifications.slice(0, 3).map((notif: any) => (
                      <div key={notif.id} className="text-left py-1 text-slate-700">
                        <div className="flex justify-between items-start gap-2">
                          <h5 className="font-extrabold text-stone-900 text-[11.5px] flex items-center gap-1">
                            {!notif.isRead && <span className="w-1.5 h-1.5 bg-rose-500 rounded-full shrink-0 animate-pulse" />}
                            <span>{notif.title}</span>
                          </h5>
                          <span className="text-[9px] text-gray-450 font-medium shrink-0">{new Date(notif.createdAt).toLocaleDateString('vi-VN')}</span>
                        </div>
                        <p className="text-[10.5px] text-gray-600 leading-relaxed mt-0.5 whitespace-pre-line text-left">{notif.content}</p>
                      </div>
                    ))}
                  </div>
                  
                  <div className="flex justify-between items-center pt-2.5 mt-3 border-t border-dashed border-[#FFA6B7]/35 text-[10.5px]">
                    <button
                        onClick={() => {
                          setCurrentView('notifications');
                        }}
                        className="font-extrabold text-[#FF4D79] hover:underline cursor-pointer flex items-center gap-1"
                    >
                      <span>Xem tất cả thông báo 💌</span>
                    </button>
                    <button
                      onClick={() => {
                        setIsNotifBannerClosed(true);
                        localStorage.setItem('notification_card_hidden', 'true');
                        localStorage.setItem('notification_last_hidden_time', newestNotifTime.toString());
                      }}
                      className="text-gray-400 hover:text-stone-850 font-extrabold hover:underline cursor-pointer"
                    >
                      [ ✕ Ẩn thông báo ]
                    </button>
                  </div>
                </div>
              );
            })()}

            {currentView === 'home' && (
              <HomeView 
                currentUser={currentUser} 
                setCurrentView={setCurrentView} 
                onOpenAuthModal={() => { setIsAuthOpen(true); setAuthMode('login'); }} 
              />
            )}

            {currentView === 'cashback' && (
              <CashbackView 
                currentUser={currentUser}
                onOpenAuthModal={() => { setIsAuthOpen(true); setAuthMode('login'); }}
              />
            )}

            {currentView === 'wallet' && (
              <ProfileView 
                currentUser={currentUser}
                onOpenAuthModal={() => { setIsAuthOpen(true); setAuthMode('login'); }}
                setCurrentView={setCurrentView}
              />
            )}

            {currentView === 'vouchers' && (
              <UtilitiesView 
                currentUser={currentUser}
                onOpenAuthModal={() => { setIsAuthOpen(true); setAuthMode('login'); }}
                initialSubTab="vouchers"
              />
            )}

            {currentView === 'lost_order' && (
              <UtilitiesView 
                currentUser={currentUser}
                onOpenAuthModal={() => { setIsAuthOpen(true); setAuthMode('login'); }}
                initialSubTab="lost_order"
              />
            )}

            {currentView === 'referrals' && (
              <ProfileView 
                currentUser={currentUser}
                onOpenAuthModal={() => { setIsAuthOpen(true); setAuthMode('login'); }}
                setCurrentView={setCurrentView}
              />
            )}

            {currentView === 'comments' && (
              <CommunityView 
                currentUser={currentUser}
                onOpenAuthModal={() => { setIsAuthOpen(true); setAuthMode('login'); }}
              />
            )}

            {currentView === 'link_history' && (
              <LinkHistoryView currentUser={currentUser} />
            )}

            {currentView === 'admin' && currentUser?.role === 'admin' && (
              <AdminView 
                currentUser={currentUser} 
                onRefreshData={handleRefreshData} 
                initialSubTab={adminSubTab} 
              />
            )}

            {/* ADMIN GATEWAY PASSWORD SHIELD VIEW */}
            {currentView === 'admin_gate' && (
              <div className="space-y-4 py-4 max-w-md mx-auto">
                <div className="bg-white rounded-3xl p-6 border border-coquette-deep shadow-xs space-y-4">
                  <div className="text-center space-y-1">
                    <span className="text-2xl text-coquette-accent block animate-bounce">🎀</span>
                    <h3 className="font-serif text-base font-bold text-gray-800">Cổng Quản Trị Hệ Thống</h3>
                    <p className="text-[10px] text-gray-400">Vui lòng cung cấp mật khẩu quản lý tối cao để mở khóa phiên làm việc</p>
                  </div>

                  <div className="space-y-3 text-xs">
                    <div className="space-y-1">
                      <label className="text-[10.5px] font-bold text-gray-600 block">Mật khẩu bảo mật:</label>
                      <input
                        type="password"
                        placeholder="Nhập mật khẩu Admin..."
                        value={adminGatePassword}
                        onChange={(e) => {
                          setAdminGatePassword(e.target.value);
                          setAdminGateError('');
                        }}
                        className="w-full text-xs px-3.5 py-2.5 bg-coquette-cream rounded-xl font-mono text-center tracking-widest focus:outline-none focus:border-coquette-accent"
                      />
                    </div>

                    {adminGateError && (
                      <p className="text-rose-700 bg-rose-50 text-rose-700 border border-rose-100 p-2 rounded-xl text-center font-bold text-[10px]">
                        {adminGateError}
                      </p>
                    )}

                    <button
                      onClick={() => {
                        if (adminGatePassword === 'Thuy3306@') {
                          const users = getUsers();
                          let adminUser = users.find(u => u.username === 'admin');
                          if (!adminUser) {
                            adminUser = {
                              username: 'admin',
                              role: 'admin',
                              availableBalance: 0,
                              pendingBalance: 0,
                              totalCashback: 0,
                              referralCode: 'MHX_ADMIN',
                              registeredAt: new Date().toISOString()
                            };
                            users.push(adminUser);
                            saveUsers(users);
                          }

                          setCurrentUser(adminUser);
                          setIsAdminMode(true);
                          localStorage.setItem('mhx_session_user', 'admin');
                          setCurrentView('admin');
                          alert('🔓 Xác thực thành công! Vy Vy đã quay trở lại làm việc 💝');
                        } else {
                          setAdminGateError('❌ Mật khẩu tối cao không hợp lệ. Vui lòng thử lại!');
                        }
                      }}
                      className="w-full bg-coquette-accent hover:bg-coquette-accent/90 text-white font-bold py-2.5 rounded-xl cursor-pointer text-center font-sans text-xs"
                    >
                      Mở Khóa Hệ Thống 🎀
                    </button>

                    <button
                      onClick={() => {
                        setCurrentView('home');
                      }}
                      className="w-full bg-gray-50 hover:bg-gray-100 text-gray-400 font-semibold py-2 rounded-xl border border-gray-150 cursor-pointer text-center text-[10px]"
                    >
                      Bỏ qua & Quay về
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* INTERNAL NOTIFICATION CENTER VIEW */}
            {currentView === 'notifications' && currentUser && (
              <div className="space-y-4 animate-in fade-in duration-200 text-xs max-w-xl mx-auto text-left whitespace-normal break-words">
                <div className="bg-white rounded-3xl p-5 border border-coquette-deep shadow-xs space-y-3">
                  <div className="flex justify-between items-start pb-2 border-b border-dashed border-coquette-deep/20">
                    <div>
                      <h3 className="font-serif text-sm font-bold text-gray-800 flex items-center gap-1.5">
                        <Bell className="w-4 h-4 text-coquette-accent" />
                        <span>Thông Báo Của Bạn</span>
                      </h3>
                      <p className="text-[10px] text-gray-400">Nơi cập nhật tiền hoàn Shopee và trả thưởng hỗ trợ tự động.</p>
                      
                      <button
                        onClick={() => {
                          try {
                            const list = getInternalNotifications();
                            const updated = list.map((n: any) => {
                              if (n.username === currentUser.username) {
                                return { ...n, isRead: true };
                              }
                              return n;
                            });
                            saveInternalNotifications(updated);
                            (window as any).showToast('Đã đánh dấu đọc tất cả thông báo! 💌', 'success');
                          } catch(e){}
                        }}
                        className="text-[10px] font-bold text-coquette-accent hover:underline cursor-pointer mt-1.5 block"
                      >
                        Đọc tất cả 💌
                      </button>
                    </div>

                    <button 
                      onClick={() => setCurrentView('home')}
                      className="w-9 h-9 flex items-center justify-center bg-gray-50 hover:bg-[#FFF0F2] text-gray-500 hover:text-[#FF4D79] rounded-full border border-gray-200 hover:border-[#FFA6B7] transition-all cursor-pointer font-bold text-[14px] shrink-0 outline-none"
                      title="Đóng và quay lại Dashboard"
                    >
                      ✕
                    </button>
                  </div>

                  {/* Notifications items loops */}
                  {(() => {
                    try {
                      const list = getInternalNotifications();
                      const mine = list.filter((n: any) => n.username === currentUser.username && !n.dismissed && !dismissedNotifIds.includes(n.id));
                      if (mine.length === 0) {
                        return (
                          <div className="text-center py-10 text-gray-450">
                            <p>Hộp thư thông báo trống rỗng. 🌸</p>
                            <p className="text-[10px] text-gray-350">Đơn hàng của bạn khi được ghi nhận, duyệt hoặc đối soát sẽ xuất hiện ngay tại đây!</p>
                          </div>
                        );
                      }

                      return (
                        <div className="divide-y divide-gray-100 max-h-[420px] overflow-y-auto pr-1">
                          {mine.map((notif: any) => (
                            <div key={notif.id} className="py-3 space-y-1 relative group text-left">
                              <div className="flex justify-between items-start gap-1">
                                <h4 className="font-bold text-gray-800 text-[11.5px] flex items-center gap-1 pr-6">
                                  {!notif.isRead && <span className="w-1.5 h-1.5 bg-rose-500 rounded-full shrink-0 animate-pulse" />}
                                  <span>{notif.title}</span>
                                </h4>
                                <div className="flex items-center gap-2 shrink-0">
                                  <span className="text-[9px] text-gray-350">{new Date(notif.createdAt).toLocaleDateString('vi-VN')}</span>
                                  <button
                                    onClick={() => {
                                      setDismissedNotifIds(prev => [...prev, notif.id]);
                                      try {
                                        const stored = getInternalNotifications();
                                        const updated = stored.map((n: any) => {
                                          if (n.id === notif.id) {
                                            return { ...n, dismissed: true };
                                          }
                                          return n;
                                        });
                                        saveInternalNotifications(updated);
                                      } catch (err) {
                                        console.error(err);
                                      }
                                    }}
                                    className="text-gray-300 hover:text-rose-500 hover:bg-rose-50 rounded-full w-4 h-4 flex items-center justify-center transition-all cursor-pointer font-bold text-[10px]"
                                    title="Tắt thông báo này"
                                    style={{ cursor: 'pointer' }}
                                  >
                                    ✕
                                  </button>
                                </div>
                              </div>
                              <p className="text-[11px] text-gray-500 leading-relaxed pr-6">{notif.content}</p>
                            </div>
                          ))}
                        </div>
                      );
                    } catch (e) {
                      return <p className="text-center py-4 text-gray-400">Lỗi đọc thông báo.</p>;
                    }
                  })()}

                </div>
              </div>
            )}

          </main>

          {/* Coquette Footer Section */}
          <footer className="bg-white border-t border-[#FFD7E2] py-8 px-5 text-center text-xs text-gray-700 space-y-3.5 shrink-0 relative z-10 mt-auto shadow-xs">
            <div 
              onClick={() => {
                window.location.hash = 'admin';
                setCurrentView('admin_gate');
              }}
              className="font-sans text-sm font-black text-gray-800 hover:text-gray-900 cursor-pointer select-none active:scale-95 transition-all uppercase tracking-widest inline-flex mx-auto"
              title="Cổng Quản trị"
            >
              <span>MÊ HOÀN XU</span>
            </div>
            
            <p className="text-xs text-gray-500 font-medium leading-relaxed max-w-md mx-auto">
              Nền tảng hoàn tiền Shopee & TikTok Shop.
            </p>

            <div className="flex justify-center items-center gap-4 text-xs font-bold text-gray-500 py-0.5">
              <button 
                onClick={() => {
                  setInfoModalTitle('Trung Tâm Trợ Giúp');
                  setInfoModalContent(webContent.helpContent || '');
                  setIsInfoModalOpen(true);
                }} 
                className="hover:text-gray-800 hover:underline transition-all cursor-pointer"
              >
                Trợ Giúp
              </button>
              <span className="text-gray-200 font-normal select-none">•</span>

              <button 
                onClick={() => {
                  setInfoModalTitle('Chính Sách Bảo Mật');
                  setInfoModalContent(webContent.privacyContent || '');
                  setIsInfoModalOpen(true);
                }} 
                className="hover:text-gray-800 hover:underline transition-all cursor-pointer"
              >
                Bảo Mật
              </button>
              <span className="text-gray-200 font-normal select-none">•</span>

              <button 
                onClick={() => {
                  setInfoModalTitle('Điều Khoản Sử Dụng');
                  setInfoModalContent(webContent.termsContent || '');
                  setIsInfoModalOpen(true);
                }} 
                className="hover:text-gray-800 hover:underline transition-all cursor-pointer"
              >
                Điều Khoản
              </button>
            </div>

            <div className="text-[11px] text-gray-600 font-bold bg-gray-50 px-3.5 py-1.5 rounded-full border border-gray-150 inline-block max-w-sm shadow-3xs">
              Hỗ trợ khách hàng 24/7
            </div>

            <p className="text-[10px] text-gray-400 font-mono font-bold tracking-wide block">© 2026 Mê Hoàn Xu</p>
          </footer>

        </div>

      </div>

      {/* SIGN IN & SIGN UP MODAL DIALOG */}
      {isAuthOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white w-[90%] md:w-full md:max-w-xl rounded-3xl overflow-hidden border-2 border-coquette-deep shadow-2xl animate-in zoom-in-95 duration-200">
            
            {/* Header top banner */}
            <div className="bg-coquette-pink p-4 text-center border-b border-coquette-deep/35 relative">
              <span className="text-xl">🎀</span>
              <h3 className="font-serif text-md font-bold text-coquette-accent">
                {authMode === 'login' ? 'ĐĂNG NHẬP MÊ HOÀN XU' : 'ĐĂNG KÝ THÀNH VIÊN ĐẠI SỨ'}
              </h3>
              <button 
                onClick={() => setIsAuthOpen(false)}
                className="absolute right-3 top-3.5 text-gray-400 hover:text-coquette-accent text-sm font-bold w-5 h-5 rounded-full hover:bg-white/80 transition-all flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Form */}
            <form onSubmit={authMode === 'login' ? handleLoginSubmit : handleRegisterSubmit} className="p-5 space-y-4 text-xs">
              
              <div className="space-y-1">
                <label className="font-bold text-gray-700 block">Tên đăng nhập <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  required
                  value={authUsername}
                  onChange={(e) => setAuthUsername(e.target.value)}
                  placeholder="Tên viết liền không dấu..."
                  className="w-full px-3 py-2 bg-coquette-cream/50 border border-coquette-deep/40 rounded-lg focus:border-coquette-accent outline-hidden"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-gray-700 block">Mật khẩu <span className="text-red-500">*</span></label>
                <input
                  type="password"
                  required
                  value={authPassword}
                  placeholder="Tối thiểu 6 ký tự..."
                  onChange={(e) => setAuthPassword(e.target.value)}
                  className="w-full px-3 py-2 bg-coquette-cream/50 border border-coquette-deep/40 rounded-lg focus:border-coquette-accent outline-hidden"
                />
              </div>

              {authMode === 'register' && (
                <div className="space-y-1 animate-in slide-in-from-top-2 duration-150">
                  <span className="font-bold text-gray-700 block text-[11px]">Mã giới thiệu từ bạn bè (Không bắt buộc)</span>
                  <input
                    type="text"
                    value={authInviteCode}
                    onChange={(e) => setAuthInviteCode(e.target.value)}
                    placeholder="Ví dụ: THUTHUY99"
                    className="w-full px-3 py-1.5 bg-coquette-cream/50 border border-coquette-deep/40 rounded-lg focus:border-coquette-accent outline-hidden uppercase font-mono"
                  />
                </div>
              )}

              {authError && (
                <p className="text-[10.5px] text-red-500 bg-red-50 p-2 rounded border border-red-200">
                  ⚠️ {authError}
                </p>
              )}

              <button
                type="submit"
                className="w-full bg-coquette-accent hover:bg-coquette-accent/90 text-white font-bold py-2 rounded-xl transition-all shadow-3xs cursor-pointer text-center text-xs"
              >
                {authMode === 'login' ? 'TIẾN VÀO HỆ THỐNG 🔑' : 'KÍCH HOẠT TÀI KHOẢN 🎀'}
              </button>

              {/* Mode Switcher */}
              <div className="text-center pt-1.5 text-[10px] text-gray-400">
                {authMode === 'login' ? (
                  <p>
                    Bạn chưa có tài khoản?{' '}
                    <button 
                      type="button" 
                      onClick={() => { setAuthMode('register'); setAuthError(''); }}
                      className="text-coquette-accent font-bold underline cursor-pointer"
                    >
                      Đăng ký ngay
                    </button>
                  </p>
                ) : (
                  <p>
                    Bạn đã có tài khoản rồi?{' '}
                    <button 
                      type="button" 
                      onClick={() => { setAuthMode('login'); setAuthError(''); }}
                      className="text-coquette-accent font-bold underline cursor-pointer"
                    >
                      Quay lại Đăng nhập
                    </button>
                  </p>
                )}
              </div>
            </form>



          </div>
        </div>
      )}

      {/* INFO INNER OVERLAY DIALOG */}
      {isInfoModalOpen && (
        <div className="fixed inset-0 bg-black/40 z-[120] flex items-center justify-center p-4 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white w-[90%] md:w-full md:max-w-xl rounded-[24px] border-2 border-coquette-deep shadow-2xl overflow-hidden p-6 text-center space-y-4 animate-in zoom-in-95 duration-200">
            <span className="text-3xl">🎀</span>
            <h3 className="font-serif text-base font-bold text-coquette-accent">{infoModalTitle}</h3>
            <div className="bg-coquette-cream p-4 rounded-xl border border-coquette-deep/50 text-[11px] text-gray-600 leading-relaxed max-h-[220px] overflow-y-auto text-left whitespace-pre-wrap font-sans">
              {infoModalContent}
            </div>
            <button
              type="button"
              onClick={() => setIsInfoModalOpen(false)}
              className="w-full bg-coquette-accent hover:bg-coquette-accent/90 text-white font-bold py-2 rounded-xl text-xs cursor-pointer shadow-3xs"
            >
              Đóng mục này 🌸
            </button>
          </div>
        </div>
      )}

      {/* Toast Notification HUD */}
      <div className="fixed top-4 right-4 md:top-6 md:right-6 z-[9999] space-y-2 pointer-events-none max-w-sm w-[90%] font-semibold">
        {toasts.map(t => (
          <div
            key={t.id}
            className="pointer-events-auto bg-stone-900/95 text-white text-xs px-4 py-3 rounded-2xl shadow-xl flex items-center gap-2.5 border border-stone-800 animate-in fade-in slide-in-from-top-4 duration-300 transform transition-all text-left"
          >
            <span className="text-sm shrink-0">
              {t.type === 'error' ? '❌' : t.type === 'info' ? 'ℹ️' : '✅'}
            </span>
            <span className="flex-1 text-stone-100 leading-snug">{t.message}</span>
            <button
              onClick={() => setToasts(prev => prev.filter(x => x.id !== t.id))}
              className="text-stone-400 hover:text-white font-bold ml-1.5 shrink-0 cursor-pointer text-sm"
            >
              ✕
            </button>
          </div>
        ))}
      </div>

    </div>
  );
}
