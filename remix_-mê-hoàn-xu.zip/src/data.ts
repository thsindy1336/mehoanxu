import { User, ShortLink, Order, WithdrawRequest, Voucher, Comment, AffiliateConfig, DashboardStats, WalletTransaction, InternalNotification, SupportTicket, ExcelUploadLog, WebContent, AdminPasswordLog, TikTokOrder, TikTokSyncLog } from './types';
import { db } from './firebase';
import { collection, doc, getDoc, getDocs, setDoc } from 'firebase/firestore';

// Danh sách các ngân hàng phổ biến Việt Nam
export const SUPPORTED_BANKS = [
  'Vietcombank (VCB)',
  'MB Bank (Military Bank)',
  'Techcombank (TCB)',
  'VietinBank (CTG)',
  'BIDV',
  'Agribank',
  'TPBank (TPB)',
  'VPBank (VPB)',
  'MoMo Wallet',
  'ZaloPay Wallet'
];

// Dữ liệu ban đầu không có bất kỳ dữ liệu ảo/demo
const INITIAL_USERS: User[] = [
  {
    username: 'admin',
    role: 'admin',
    availableBalance: 0,
    pendingBalance: 0,
    totalCashback: 0,
    referralCode: 'MHX_ADMIN',
    registeredAt: '2026-06-08T14:00:00Z',
  },
  {
    username: 'thuy',
    role: 'user',
    availableBalance: 0,
    pendingBalance: 0,
    totalCashback: 0,
    referralCode: 'MHX_THUY',
    registeredAt: '2026-06-09T08:00:00Z',
  },
  {
    username: 'nam',
    role: 'user',
    availableBalance: 0,
    pendingBalance: 0,
    totalCashback: 0,
    referralCode: 'MHX_NAM',
    registeredAt: '2026-06-09T09:00:00Z',
  }
];

// Định nghĩa hàm băm mật khẩu bảo mật (DJB2 hash)
export function hashPassword(p: string): string {
  if (p.startsWith('mhx_hash_')) return p; // đã được băm
  let hash = 5381;
  for (let i = 0; i < p.length; i++) {
    hash = (hash * 33) ^ p.charCodeAt(i);
  }
  return 'mhx_hash_' + (hash >>> 0).toString(16);
}

// Khởi tạo danh sách mật khẩu dạng văn bản băm (mật khẩu admin mặc định: Thuy3306@)
const INITIAL_PASSWORDS: Record<string, string> = {
  'admin': hashPassword('Thuy3306@'),
  'thuy': hashPassword('123456'),
  'nam': hashPassword('123456')
};

const INITIAL_VOUCHERS: Voucher[] = [];

const INITIAL_COMMENTS: Comment[] = [];

const INITIAL_CONFIG: AffiliateConfig = {
  affiliateId: '17903619320',
  subId: 'shpee_tthuy3326',
  rebatePercent: 50, // Hoàn 50% hoa hồng Shopee trả mặc định
  tiktokCommissionRate: 60 // Tỷ lệ chia hoa hồng TikTok Shop mặc định (%)
};

const INITIAL_SHORT_LINKS: ShortLink[] = [];

const INITIAL_ORDERS: Order[] = [];

const INITIAL_WITHDRAW_REQUESTS: WithdrawRequest[] = [];

const INITIAL_TRANSACTIONS: WalletTransaction[] = [];

const INITIAL_NOTIFICATIONS: InternalNotification[] = [];

const INITIAL_TICKETS: SupportTicket[] = [];

const INITIAL_EXCEL_LOGS: ExcelUploadLog[] = [];

const INITIAL_WEBCONTENT: WebContent = {
  bannerTitle: 'Mua sắm Shopee, nhận lại tiền hoàn mỗi ngày 💖',
  bannerDesc: 'Nhận tiền hoàn khi mua sắm trên Shopee. An toàn, uy tín và thanh toán nhanh chóng qua ngân hàng.',
  bannerSub: 'MUA SẮM THẢ GA - HOÀN TIỀN CỰC ĐÃ',
  showPopup: true,
  popupContent: 'Chào mừng bạn đến với Mê Hoàn Xu - Hệ thống tự động dán link & đối soát hoàn tiền Shopee lớn nhất Việt Nam! 🌸',
  
  step1_title: 'Tìm sản phẩm',
  step1_desc: 'Mở ứng dụng hoặc trang Shopee, sao chép (copy) link của sản phẩm bạn yêu thích.',
  step2_title: 'Tạo link hoàn tiền',
  step2_desc: 'Dán link vào ô mua sắm của Mê Hoàn Xu để hệ thống tạo link tracking rút gọn đặc quyền.',
  step3_title: 'Đặt hàng cực nhanh',
  step3_desc: 'Nhấn "Mua Ngay", mua hàng bình thường trên Shopee (chú ý tránh xem Live/Video trước khi thanh toán).',
  step4_title: 'Nhận xu vào ví',
  step4_desc: 'Sau khi đơn được ghi nhận và duyệt hoa hồng, tiền hoàn tự động cộng vào ví của bạn để rút ra thẻ ngân hàng!',
  
  tabCorrectTitle: 'Quy trình đúng',
  tabCorrectContent: `• Bạn phải dán link sản phẩm và ấn Mua Ngay từ Mê Hoàn Xu.
• Bạn mua hàng trên điện thoại (App Shopee) để đạt tỉ lệ ghi nhận cao nhất.
• Đơn hàng sẽ được cập nhật tạm tính sau 24 - 48 giờ.
• Khi Shopee duyệt hoa hồng, tiền sẽ cộng trực tiếp vào Số Dư Ví dưới dạng tiền khả dụng có thể rút.`,
  
  tabPolicyTitle: 'Điều khoản cơ bản',
  tabPolicyContent: `• Đơn hàng không bị hủy, trả hàng, hoặc không thanh toán.
• Mua hàng đúng thời hạn (trong vòng 30 phút sau khi click qua link rút gọn).
• Không lạm dụng mã giảm giá bất thường hoặc đầu cơ số lượng lớn sản phẩm.
• Một người dùng dùng nhiều tài khoản ảo tự click chéo sẽ bị khóa ví vĩnh viễn.`,
  
  tabTipsTitle: 'Bí quyết tránh mất đơn',
  tabTipsContent: `• Không mua thông quang giỏ Live: Mua từ Live/Video, hoa hồng sẽ bị tính lỗi cho bên thứ ba.
• Tắt kịch bản mua chéo: Tránh click các liên kết của KOL khác trong vòng 30 phút trước khi thanh toán.
• Thêm hàng vào giỏ sau khi click qua link Mê Hoàn Xu. Tránh thêm hàng sẵn trong giỏ từ trước rồi mới thanh toán.`,
  
  footerName: 'MÊ HOÀN XU',
  footerDesc: 'Nền tảng hoàn tiền Shopee & TikTok Shop.',
  footerContact: 'Hỗ trợ khách hàng 24/7',
  footerCopyright: '© 2026 Mê Hoàn Xu',
  footerSocialLink: 'https://instagram.com/mehoanxu',

  showHelp: true,
  showPrivacy: true,
  showTerms: true,

  helpContent: `CHÀO MỪNG BẠN ĐẾN VỚI TRUNG TÂM TRỢ GIÚP MÊ HOÀN XU 💁‍♀️

1. Làm sao để nhận được tiền hoàn?
Rất đơn giản, hãy tìm sản phẩm trên Shopee -> Sao chép link -> Dán vào Mê Hoàn Xu để tạo link mua sắm -> Bấm "Mua Ngay" -> Chọn mua bình thường trên App Shopee.

2. Tiền hoàn được tính như thế nào?
Số tiền hoàn sẽ bằng Hoa hồng Shopee gốc thực nhận nhân với tỷ lệ hoàn tiền mà hệ thống cấu hình (thường là 50% đến 80%).

3. Khi nào tiền về ví khả dụng?
Shopee duyệt đơn và đối soát thanh toán định kỳ. Ngay khi Shopee chuyển trạng thái Đã Đối Soát (Approved), số tiền tương ứng sẽ cộng trực tiếp vào số dư khả dụng của bạn. Bạn có thể yêu cầu rút tiền về tài khoản ngân hàng bất cứ lúc nào khi đạt mức tối thiểu 10.000đ.`,

  privacyContent: `CHÍNH SÁCH BẢO MẬT AN TOÀN TÀI KHOẢN 🔒

Chào mừng bạn đến với Mê Hoàn Xu. Chúng tôi cam kết bảo mật 100% thông tin tài khoản của bạn:
- Mọi mật khẩu của bạn đều được mã hóa hoặc lưu trữ an toàn tuyệt đối.
- Chúng tôi không bao giờ chia sẻ thông tin tài khoản ngân hàng, số dư hoặc lịch sử giao dịch của bạn cho bất kỳ bên thứ ba nào.
- Quy trình đối soát mã đơn hàng tự động tuyệt đối bảo mật, không thu thập bất kỳ hành vi hoặc thông tin nhạy cảm nào vượt quá phạm vi mua sắm Shopee Affiliate.`,

  termsContent: `ĐIỀU KHOẢN SỬ DỤNG DỊCH VỤ MÊ HOÀN XU 📜

Bằng việc tham gia dán link kiếm tiền hoàn tại Mê Hoàn Xu, bạn cam kết chấp thuận các điều khoản sau:
- Không tạo nhiều tài khoản hoặc sử dụng công cụ ảo để cheat, lăng mạ hoặc trục lợi chính sách giới thiệu bạn bè (Tự sướng referral).
- Không được dùng link mua sắm để spam, lừa đảo hoặc vi phạm điều khoản chính sách cộng đồng của Shopee Việt Nam.
- Hệ thống có quyền từ chối thanh toán đối với các trường hợp cố tình lách luật, đầu cơ thương mại điện tử quy mô lớn làm ảnh hưởng đến tài khoản s.shopee.vn tổng của chúng tôi.`
};

// Helper để lấy & lưu dữ liệu từ localStorage
export function getStoredData<T>(key: string, initialValue: T): T {
  const data = localStorage.getItem(key);
  if (!data) {
    localStorage.setItem(key, JSON.stringify(initialValue));
    return initialValue;
  }
  try {
    return JSON.parse(data) as T;
  } catch (e) {
    return initialValue;
  }
}

export function saveStoredData<T>(key: string, value: T): void {
  localStorage.setItem(key, JSON.stringify(value));
}

// Memory database preloaded with local storage caches as initial values
export const MEMORY_DB = {
  users: getStoredData('mhx_users', INITIAL_USERS),
  passwords: getStoredData('mhx_passwords', INITIAL_PASSWORDS),
  vouchers: getStoredData('mhx_vouchers', INITIAL_VOUCHERS),
  comments: getStoredData('mhx_comments', INITIAL_COMMENTS),
  config: getStoredData('mhx_config', INITIAL_CONFIG),
  short_links: getStoredData('mhx_short_links', INITIAL_SHORT_LINKS),
  orders: getStoredData('mhx_orders', INITIAL_ORDERS),
  withdraw_requests: getStoredData('mhx_withdraw_requests', INITIAL_WITHDRAW_REQUESTS),
  transactions: getStoredData('mhx_transactions', INITIAL_TRANSACTIONS),
  notifications: getStoredData('mhx_notifications', INITIAL_NOTIFICATIONS),
  tickets: getStoredData('mhx_tickets', INITIAL_TICKETS),
  excel_logs: getStoredData('mhx_excel_logs', INITIAL_EXCEL_LOGS),
  web_content: getStoredData('mhx_web_content', INITIAL_WEBCONTENT),
  admin_password_logs: getStoredData('mhx_password_logs', [] as AdminPasswordLog[]),
  tiktok_sync_logs: getStoredData('mhx_tiktok_sync_logs', [] as TikTokSyncLog[])
};

// Asynchronous Firestore Sync function called exactly once at startup in App.tsx
export async function syncFromFirestore(): Promise<void> {
  try {
    console.log("Starting Firebase Firestore Synchronization...");
    const [
      usersSnap, passwordsSnap, vouchersSnap, commentsSnap, shortLinksSnap,
      ordersSnap, withdrawSnap, transSnap, notifsSnap, ticketsSnap,
      configDoc, webContentDoc, tiktokLogsSnap, excelLogsSnap
    ] = await Promise.all([
      getDocs(collection(db, 'users')),
      getDocs(collection(db, 'passwords')),
      getDocs(collection(db, 'vouchers')),
      getDocs(collection(db, 'comments')),
      getDocs(collection(db, 'short_links')),
      getDocs(collection(db, 'orders')),
      getDocs(collection(db, 'withdraw_requests')),
      getDocs(collection(db, 'transactions')),
      getDocs(collection(db, 'notifications')),
      getDocs(collection(db, 'tickets')),
      getDoc(doc(db, 'config', 'global')),
      getDoc(doc(db, 'web_content', 'global')),
      getDocs(collection(db, 'tiktok_sync_logs')),
      getDocs(collection(db, 'excel_logs'))
    ]);

    // Map user documents
    if (!usersSnap.empty) {
      const loadedUsers: User[] = [];
      usersSnap.forEach(snap => { loadedUsers.push(snap.data() as User); });
      MEMORY_DB.users = loadedUsers;
      saveStoredData('mhx_users', loadedUsers);
    } else {
      // Bootstrap with initial users
      for (const u of INITIAL_USERS) {
        await setDoc(doc(db, 'users', u.username), u);
      }
    }

    // Map passwords
    if (!passwordsSnap.empty) {
      const loadedPasswords: Record<string, string> = {};
      passwordsSnap.forEach(snap => {
        loadedPasswords[snap.id] = snap.data().hash;
      });
      MEMORY_DB.passwords = loadedPasswords;
      saveStoredData('mhx_passwords', loadedPasswords);
    } else {
      // Bootstrap passwords
      for (const [uname, hash] of Object.entries(INITIAL_PASSWORDS)) {
        await setDoc(doc(db, 'passwords', uname), { hash });
      }
    }

    // Map vouchers
    if (!vouchersSnap.empty) {
      const loadedVouchers: Voucher[] = [];
      vouchersSnap.forEach(snap => { loadedVouchers.push(snap.data() as Voucher); });
      MEMORY_DB.vouchers = loadedVouchers;
      saveStoredData('mhx_vouchers', loadedVouchers);
    }

    // Map comments
    if (!commentsSnap.empty) {
      const loadedComments: Comment[] = [];
      commentsSnap.forEach(snap => { loadedComments.push(snap.data() as Comment); });
      MEMORY_DB.comments = loadedComments;
      saveStoredData('mhx_comments', loadedComments);
    }

    // Map short links
    if (!shortLinksSnap.empty) {
      const loadedShortLinks: ShortLink[] = [];
      shortLinksSnap.forEach(snap => { loadedShortLinks.push(snap.data() as ShortLink); });
      MEMORY_DB.short_links = loadedShortLinks;
      saveStoredData('mhx_short_links', loadedShortLinks);
    }

    // Map orders
    if (!ordersSnap.empty) {
      const loadedOrders: Order[] = [];
      ordersSnap.forEach(snap => { loadedOrders.push(snap.data() as Order); });
      MEMORY_DB.orders = loadedOrders;
      saveStoredData('mhx_orders', loadedOrders);
    }

    // Map withdraw requests
    if (!withdrawSnap.empty) {
      const loadedWithdraws: WithdrawRequest[] = [];
      withdrawSnap.forEach(snap => { loadedWithdraws.push(snap.data() as WithdrawRequest); });
      MEMORY_DB.withdraw_requests = loadedWithdraws;
      saveStoredData('mhx_withdraw_requests', loadedWithdraws);
    }

    // Map transactions
    if (!transSnap.empty) {
      const loadedTrans: WalletTransaction[] = [];
      transSnap.forEach(snap => { loadedTrans.push(snap.data() as WalletTransaction); });
      MEMORY_DB.transactions = loadedTrans;
      saveStoredData('mhx_transactions', loadedTrans);
    }

    // Map notifications
    if (!notifsSnap.empty) {
      const loadedNotifs: InternalNotification[] = [];
      notifsSnap.forEach(snap => { loadedNotifs.push(snap.data() as InternalNotification); });
      MEMORY_DB.notifications = loadedNotifs;
      saveStoredData('mhx_notifications', loadedNotifs);
    }

    // Map tickets
    if (!ticketsSnap.empty) {
      const loadedTickets: SupportTicket[] = [];
      ticketsSnap.forEach(snap => { loadedTickets.push(snap.data() as SupportTicket); });
      MEMORY_DB.tickets = loadedTickets;
      saveStoredData('mhx_tickets', loadedTickets);
    }

    // Map global config
    if (configDoc.exists()) {
      MEMORY_DB.config = configDoc.data() as AffiliateConfig;
      saveStoredData('mhx_config', MEMORY_DB.config);
    } else {
      await setDoc(doc(db, 'config', 'global'), INITIAL_CONFIG);
    }

    // Map global web content
    if (webContentDoc.exists()) {
      MEMORY_DB.web_content = webContentDoc.data() as WebContent;
      saveStoredData('mhx_web_content', MEMORY_DB.web_content);
    } else {
      await setDoc(doc(db, 'web_content', 'global'), INITIAL_WEBCONTENT);
    }

    // Map tiktok sync logs
    if (!tiktokLogsSnap.empty) {
      const loadedTiktokLogs: TikTokSyncLog[] = [];
      tiktokLogsSnap.forEach(snap => { loadedTiktokLogs.push(snap.data() as TikTokSyncLog); });
      MEMORY_DB.tiktok_sync_logs = loadedTiktokLogs;
      saveStoredData('mhx_tiktok_sync_logs', loadedTiktokLogs);
    }

    // Map excel logs
    if (!excelLogsSnap.empty) {
      const loadedExcelLogs: ExcelUploadLog[] = [];
      excelLogsSnap.forEach(snap => { loadedExcelLogs.push(snap.data() as ExcelUploadLog); });
      MEMORY_DB.excel_logs = loadedExcelLogs;
      saveStoredData('mhx_excel_logs', loadedExcelLogs);
    }

    console.log("Firebase Firestore Synchronization completed successfully.");
  } catch (error) {
    console.error("Firestore sync failed, utilizing fallback local store caches. Error details:", error);
  }
}

// Deprecated empty shell initializer
export function initLocalStorage() {}

// All data manipulation functions now leverage memory and save in Firestore asynchronously
export function getUsers(): User[] {
  return MEMORY_DB.users;
}

export function saveUsers(users: User[]): void {
  MEMORY_DB.users = users;
  saveStoredData('mhx_users', users);
  for (const u of users) {
    setDoc(doc(db, 'users', u.username), u).catch(e => console.error("Error setting user:", u.username, e));
  }
}

export function getPasswords(): Record<string, string> {
  return MEMORY_DB.passwords;
}

export function savePasswords(passwords: Record<string, string>): void {
  MEMORY_DB.passwords = passwords;
  saveStoredData('mhx_passwords', passwords);
  for (const [uname, hash] of Object.entries(passwords)) {
    setDoc(doc(db, 'passwords', uname), { hash }).catch(e => console.error("Error setting password:", uname, e));
  }
}

export function getVouchers(): Voucher[] {
  return MEMORY_DB.vouchers;
}

export function saveVouchers(vouchers: Voucher[]): void {
  MEMORY_DB.vouchers = vouchers;
  saveStoredData('mhx_vouchers', vouchers);
  for (const v of vouchers) {
    setDoc(doc(db, 'vouchers', v.id), v).catch(e => console.error("Error setting voucher:", v.id, e));
  }
}

export function getComments(): Comment[] {
  return MEMORY_DB.comments;
}

export function saveComments(comments: Comment[]): void {
  MEMORY_DB.comments = comments;
  saveStoredData('mhx_comments', comments);
  for (const c of comments) {
    setDoc(doc(db, 'comments', c.id), c).catch(e => console.error("Error setting comment:", c.id, e));
  }
}

export function getConfig(): AffiliateConfig {
  return MEMORY_DB.config || INITIAL_CONFIG;
}

export function saveConfig(config: AffiliateConfig): void {
  MEMORY_DB.config = config;
  saveStoredData('mhx_config', config);
  setDoc(doc(db, 'config', 'global'), config).catch(e => console.error("Error setting global config:", e));
}

export function getShortLinks(): ShortLink[] {
  return MEMORY_DB.short_links;
}

export function saveShortLinks(links: ShortLink[]): void {
  MEMORY_DB.short_links = links;
  saveStoredData('mhx_short_links', links);
  for (const l of links) {
    setDoc(doc(db, 'short_links', l.code), l).catch(e => console.error("Error setting shortlink:", l.code, e));
  }
}

export function getOrders(): Order[] {
  return MEMORY_DB.orders;
}

export function saveOrders(orders: Order[]): void {
  MEMORY_DB.orders = orders;
  saveStoredData('mhx_orders', orders);
  for (const o of orders) {
    setDoc(doc(db, 'orders', o.orderId), o).catch(e => console.error("Error setting order:", o.orderId, e));
  }
}

export function getWithdrawRequests(): WithdrawRequest[] {
  return MEMORY_DB.withdraw_requests;
}

export function saveWithdrawRequests(requests: WithdrawRequest[]): void {
  MEMORY_DB.withdraw_requests = requests;
  saveStoredData('mhx_withdraw_requests', requests);
  for (const r of requests) {
    setDoc(doc(db, 'withdraw_requests', r.id), r).catch(e => console.error("Error setting withdraw request:", r.id, e));
  }
}

export function getWalletTransactions(): WalletTransaction[] {
  return MEMORY_DB.transactions;
}

export function saveWalletTransactions(txs: WalletTransaction[]): void {
  MEMORY_DB.transactions = txs;
  saveStoredData('mhx_transactions', txs);
  for (const t of txs) {
    setDoc(doc(db, 'transactions', t.id), t).catch(e => console.error("Error setting transaction:", t.id, e));
  }
}

export function getInternalNotifications(): InternalNotification[] {
  return MEMORY_DB.notifications;
}

export function saveInternalNotifications(notifs: InternalNotification[]): void {
  MEMORY_DB.notifications = notifs;
  saveStoredData('mhx_notifications', notifs);
  for (const n of notifs) {
    setDoc(doc(db, 'notifications', n.id), n).catch(e => console.error("Error setting notification:", n.id, e));
  }
}

export function getSupportTickets(): SupportTicket[] {
  return MEMORY_DB.tickets;
}

export function saveSupportTickets(tickets: SupportTicket[]): void {
  MEMORY_DB.tickets = tickets;
  saveStoredData('mhx_tickets', tickets);
  for (const t of tickets) {
    setDoc(doc(db, 'tickets', t.id), t).catch(e => console.error("Error setting ticket:", t.id, e));
  }
}

export function getExcelUploadLogs(): ExcelUploadLog[] {
  return MEMORY_DB.excel_logs;
}

export function saveExcelUploadLogs(logs: ExcelUploadLog[]): void {
  MEMORY_DB.excel_logs = logs;
  saveStoredData('mhx_excel_logs', logs);
  for (const l of logs) {
    setDoc(doc(db, 'excel_logs', l.id), l).catch(e => console.error("Error setting excel upload log:", l.id, e));
  }
}

export function getWebContent(): WebContent {
  return MEMORY_DB.web_content || INITIAL_WEBCONTENT;
}

export function saveWebContent(content: WebContent): void {
  MEMORY_DB.web_content = content;
  saveStoredData('mhx_web_content', content);
  setDoc(doc(db, 'web_content', 'global'), content).catch(e => console.error("Error setting web content:", e));
}

export function getAdminPasswordLogs(): AdminPasswordLog[] {
  return MEMORY_DB.admin_password_logs;
}

export function saveAdminPasswordLogs(logs: AdminPasswordLog[]): void {
  MEMORY_DB.admin_password_logs = logs;
  saveStoredData('mhx_password_logs', logs);
}

// Trả về thống kê hệ thống dành cho Admin
export function getDashboardStats(): DashboardStats {
  const links = getShortLinks();
  const orders = getOrders();
  
  const totalClicks = links.reduce((sum, link) => sum + link.clicks, 0);
  const approvedOrders = orders.filter(o => o.status === 'approved');
  
  const totalSyncedRevenue = orders.reduce((sum, o) => sum + o.rawCommission, 0);
  const totalCashbackPaid = approvedOrders.reduce((sum, o) => sum + o.rebateAmount, 0);

  return {
    totalLinksCreated: links.length,
    totalClicks,
    totalOrders: orders.length,
    totalSyncedRevenue,
    totalCashbackPaid
  };
}

export function getTikTokSyncLogs(): TikTokSyncLog[] {
  return MEMORY_DB.tiktok_sync_logs;
}

export function saveTikTokSyncLogs(logs: TikTokSyncLog[]): void {
  MEMORY_DB.tiktok_sync_logs = logs;
  saveStoredData('mhx_tiktok_sync_logs', logs);
  for (const l of logs) {
    setDoc(doc(db, 'tiktok_sync_logs', l.id), l).catch(e => console.error("Error setting tiktok sync log:", l.id, e));
  }
}

export async function syncTikTokOrders(): Promise<{ 
  success: boolean; 
  newOrders: number; 
  updatedOrders: number; 
  error?: string; 
  status?: number; 
  body?: string; 
  responseBodyJson?: any;
  debugInfo?: {
    creatorUsernameFromSettings: string;
    creatorUsernameSentToApi: string;
    finalApiUrl: string;
  };
}> {
  let creatorUser = '';
  let finalApiUrl = '';
  try {
    const config = getConfig();
    const tiktokRate = (config.rebatePercent || 60) / 100;
    
    // 1. Đọc Creator Username từ phần Cài đặt TikTok Shop (config/admin)
    const configRes = await fetch('/api/tiktok/config/admin');
    if (configRes.ok) {
      const configData = await configRes.json();
      creatorUser = configData.creator_username || '';
    }

    if (!creatorUser || !creatorUser.trim()) {
      const dbWarning = 'Chưa cấu hình Creator Username trong TikTok Shop Settings';
      return {
        success: false,
        newOrders: 0,
        updatedOrders: 0,
        error: dbWarning,
        debugInfo: {
          creatorUsernameFromSettings: 'Trống (Chưa cấu hình)',
          creatorUsernameSentToApi: 'Trống',
          finalApiUrl: '/api/v1/partner/tiktok/affiliate/orders?creator_username=&page=1&page_size=100'
        }
      };
    }

    creatorUser = creatorUser.trim();
    // 2. Tạo URL cuối cùng theo yêu cầu của RioHub
    finalApiUrl = `/api/v1/partner/tiktok/affiliate/orders?creator_username=${encodeURIComponent(creatorUser)}&page=1&page_size=100`;

    // 5. Thêm Debug Console Log
    console.log("Creator Username đọc từ Settings: " + creatorUser);
    console.log("Creator Username gửi lên API: " + creatorUser);
    console.log("URL cuối cùng: " + finalApiUrl);

    // 3. Gọi API của chúng ta (không lấy username tài khoản đăng nhập hiện tại)
    const response = await fetch(finalApiUrl);
    if (!response.ok) {
      let errPayload: any = {};
      try {
        errPayload = await response.json();
      } catch (_) {}
      
      const errorObj = new Error(errPayload.message || `Server returned HTTP ${response.status}`);
      (errorObj as any).status = response.status;
      (errorObj as any).body = errPayload.body || '';
      (errorObj as any).responseBodyJson = errPayload;
      throw errorObj;
    }
    const data = await response.json();
    if (data.error) {
      const errorObj = new Error(data.message || 'Lỗi từ dịch vụ kết nối.');
      (errorObj as any).status = data.status || response.status;
      (errorObj as any).body = data.body || '';
      (errorObj as any).responseBodyJson = data;
      throw errorObj;
    }
    
    const tiktokOrders: TikTokOrder[] = data.orders || [];
    
    const dbOrders = getOrders();
    const dbUsers = getUsers();
    const dbTransactions = getWalletTransactions();
    const dbNotifications = getInternalNotifications();
    
    let newOrdersCount = 0;
    let updatedOrdersCount = 0;
    
    for (const order of tiktokOrders) {
      const orderId = order.order_id || (order as any).orderId;
      const subId = order.sub_id || (order as any).subId; // Đây chính là username của người dùng đã dán link tracking
      const rawComm = order.commission !== undefined ? order.commission : ((order as any).est_commission !== undefined ? Number((order as any).est_commission) : 0);
      const prodName = order.product_name || 'Sản phẩm TikTok Shop 🛍️';
      const orderTime = order.time || new Date().toISOString();
      const rebateAmount = Math.round(rawComm * tiktokRate);
      
      // Ánh xạ trạng thái TikTok sang hệ thống
      let sysStatus: 'pending_approve' | 'approved' | 'cancelled' = 'pending_approve';
      if (order.status === 'completed') {
        sysStatus = 'approved';
      } else if (order.status === 'cancelled') {
        sysStatus = 'cancelled';
      }
      
      const matchIdx = dbOrders.findIndex(o => o.orderId === orderId);
      
      if (matchIdx < 0) {
        // 1. Tạo mới đơn hàng chưa từng tồn tại
        const newOrder: Order = {
          orderId,
          username: subId,
          time: orderTime,
          rebateAmount,
          rawCommission: rawComm,
          status: sysStatus,
          productName: prodName,
          platform: 'tiktok',
          syncedAt: new Date().toISOString()
        };
        
        // Cộng/trừ tiền ví của user
        const userIdx = dbUsers.findIndex(u => u.username === subId);
        if (userIdx >= 0) {
          const targetUser = dbUsers[userIdx];
          if (sysStatus === 'approved') {
            targetUser.availableBalance += rebateAmount;
            targetUser.totalCashback += rebateAmount;
            
            dbTransactions.unshift({
              id: 'tx_tt_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
              username: subId,
              amount: rebateAmount,
              type: 'cashback',
              description: `+${rebateAmount.toLocaleString('vi-VN')}đ Hoàn tiền đơn TikTok Shop #${orderId}`,
              createdAt: new Date().toISOString()
            });
            
            dbNotifications.unshift({
              id: 'nt_tt_new_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
              username: subId,
              title: 'Đơn hàng đã được duyệt 🟢',
              content: `Đơn hàng #${orderId} đã được duyệt thành công.`,
              isRead: false,
              createdAt: new Date().toISOString()
            });

            dbNotifications.unshift({
              id: 'nt_tt_new_ds_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
              username: subId,
              title: 'Đơn hàng đã được đối soát 💰',
              content: `Đơn hàng #${orderId} đã được đối soát. Tiền hoàn đã được cộng vào số dư khả dụng.`,
              isRead: false,
              createdAt: new Date().toISOString()
            });
          } else if (sysStatus === 'pending_approve') {
            targetUser.pendingBalance += rebateAmount;
            
            dbNotifications.unshift({
              id: 'nt_tt_new_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
              username: subId,
              title: 'Đơn hàng đang chờ duyệt 🟡',
              content: `Đơn hàng #${orderId} của bạn đã được ghi nhận và đang chờ duyệt.`,
              isRead: false,
              createdAt: new Date().toISOString()
            });
          }
        }
        
        dbOrders.unshift(newOrder);
        newOrdersCount++;
      } else {
        // 2. Cập nhật trạng thái đơn hàng đã tồn tại
        const matchedOrder = dbOrders[matchIdx];
        const oldStatus = matchedOrder.status;
        
        if (sysStatus !== oldStatus) {
          const userIdx = dbUsers.findIndex(u => u.username === matchedOrder.username);
          if (userIdx >= 0) {
            const targetUser = dbUsers[userIdx];
            
            // Xử lý các kịch bản chuyển đổi trạng thái ví
            if (oldStatus === 'pending_approve' && sysStatus === 'approved') {
              // Từ Chờ duyệt -> Được duyệt
              targetUser.pendingBalance = Math.max(0, targetUser.pendingBalance - matchedOrder.rebateAmount);
              targetUser.availableBalance += rebateAmount;
              targetUser.totalCashback += rebateAmount;
              
              dbTransactions.unshift({
                id: 'tx_tt_up_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
                username: matchedOrder.username,
                amount: rebateAmount,
                type: 'cashback',
                description: `+${rebateAmount.toLocaleString('vi-VN')}đ Hoàn tiền đơn TikTok Shop #${orderId}`,
                createdAt: new Date().toISOString()
              });
              
              dbNotifications.unshift({
                id: 'nt_tt_up_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
                username: matchedOrder.username,
                title: 'Đơn hàng đã được duyệt 🟢',
                content: `Đơn hàng #${orderId} đã được duyệt thành công.`,
                isRead: false,
                createdAt: new Date().toISOString()
              });

              dbNotifications.unshift({
                id: 'nt_tt_up_ds_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
                username: matchedOrder.username,
                title: 'Đơn hàng đã được đối soát 💰',
                content: `Đơn hàng #${orderId} đã được đối soát. Tiền hoàn đã được cộng vào số dư khả dụng.`,
                isRead: false,
                createdAt: new Date().toISOString()
              });
            } else if (oldStatus === 'pending_approve' && sysStatus === 'cancelled') {
              // Từ Chờ duyệt -> Huỷ bỏ
              targetUser.pendingBalance = Math.max(0, targetUser.pendingBalance - matchedOrder.rebateAmount);
              
              dbNotifications.unshift({
                id: 'nt_tt_up_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
                username: matchedOrder.username,
                title: 'Đơn hàng TikTok Shop đã thu hồi 😢',
                content: `Hóa đơn #${orderId} bị huỷ bởi người mua. Số tiền tạm tính +${matchedOrder.rebateAmount.toLocaleString('vi-VN')}đ đã được gỡ khỏi số dư chờ duyệt.`,
                isRead: false,
                createdAt: new Date().toISOString()
              });
            } else if (oldStatus !== 'approved' && sysStatus === 'approved') {
              // Từ trạng thái khác trực tiếp sang Được duyệt (nếu có nhảy cóc)
              targetUser.availableBalance += rebateAmount;
              targetUser.totalCashback += rebateAmount;
              
              dbTransactions.unshift({
                id: 'tx_tt_up_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
                username: matchedOrder.username,
                amount: rebateAmount,
                type: 'cashback',
                description: `+${rebateAmount.toLocaleString('vi-VN')}đ Hoàn tiền đơn TikTok Shop #${orderId}`,
                createdAt: new Date().toISOString()
              });

              dbNotifications.unshift({
                id: 'nt_tt_fallback_app_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
                username: matchedOrder.username,
                title: 'Đơn hàng đã được duyệt 🟢',
                content: `Đơn hàng #${orderId} đã được duyệt thành công.`,
                isRead: false,
                createdAt: new Date().toISOString()
              });

              dbNotifications.unshift({
                id: 'nt_tt_fallback_ds_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
                username: matchedOrder.username,
                title: 'Đơn hàng đã được đối soát 💰',
                content: `Đơn hàng #${orderId} đã được đối soát. Tiền hoàn đã được cộng vào số dư khả dụng.`,
                isRead: false,
                createdAt: new Date().toISOString()
              });
            } else if (oldStatus === 'approved' && sysStatus === 'cancelled') {
              // Đơn đã duyệt nhưng bất ngờ bị cancel hoàn trả
              targetUser.availableBalance = Math.max(0, targetUser.availableBalance - matchedOrder.rebateAmount);
              targetUser.totalCashback = Math.max(0, targetUser.totalCashback - matchedOrder.rebateAmount);
              
              dbNotifications.unshift({
                id: 'nt_tt_up_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
                username: matchedOrder.username,
                title: 'Khấu trừ hoàn trả TikTok Shop ⚠️',
                content: `Hóa đơn #${orderId} phát sinh hoàn trả hàng thành công. Hệ thống khấu trừ -${matchedOrder.rebateAmount.toLocaleString('vi-VN')}đ khỏi Số dư khả dụng của bạn.`,
                isRead: false,
                createdAt: new Date().toISOString()
              });
            }
          }
          
          matchedOrder.status = sysStatus;
          matchedOrder.rawCommission = rawComm;
          matchedOrder.rebateAmount = rebateAmount;
          matchedOrder.platform = 'tiktok';
          matchedOrder.syncedAt = new Date().toISOString();
          updatedOrdersCount++;
        }
      }
    }
    
    // Lưu lại toàn bộ dữ liệu vào localStorage
    saveOrders(dbOrders);
    saveUsers(dbUsers);
    saveWalletTransactions(dbTransactions);
    saveInternalNotifications(dbNotifications);
    
    // Lưu nhật ký đồng bộ thành công
    const logs = getTikTokSyncLogs();
    logs.unshift({
      id: 'ts_' + Date.now(),
      syncedAt: new Date().toISOString(),
      newOrdersCount,
      updatedOrdersCount
    });
    saveTikTokSyncLogs(logs.slice(0, 50));
    
    return { 
      success: true, 
      newOrders: newOrdersCount, 
      updatedOrders: updatedOrdersCount,
      debugInfo: {
        creatorUsernameFromSettings: creatorUser,
        creatorUsernameSentToApi: creatorUser,
        finalApiUrl: finalApiUrl
      }
    };
  } catch (err: any) {
    const errMsg = err.message || 'Lỗi kết nối hoặc xử lý đồng bộ';
    
    const logs = getTikTokSyncLogs();
    logs.unshift({
      id: 'ts_' + Date.now(),
      syncedAt: new Date().toISOString(),
      newOrdersCount: 0,
      updatedOrdersCount: 0,
      error: errMsg
    });
    saveTikTokSyncLogs(logs.slice(0, 50));
    
    return { 
      success: false, 
      newOrders: 0, 
      updatedOrders: 0, 
      error: errMsg,
      status: err.status,
      body: err.body || '',
      responseBodyJson: err.responseBodyJson,
      debugInfo: {
        creatorUsernameFromSettings: creatorUser || 'Chưa tìm thấy',
        creatorUsernameSentToApi: creatorUser || 'Trống',
        finalApiUrl: finalApiUrl || '/api/v1/partner/tiktok/affiliate/orders?creator_username='
      }
    };
  }
}

